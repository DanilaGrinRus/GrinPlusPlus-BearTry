#include <catch.hpp>

#include <Consensus.h>

using namespace Consensus;

TEST_CASE("Consensus::GetHeaderVersion")
{
	REQUIRE(GetHeaderVersion(Environment::MAINNET, 0) == 1);
	REQUIRE(GetHeaderVersion(Environment::MAINNET, 10) == 1);
	REQUIRE(GetHeaderVersion(Environment::MAINNET, YEAR_HEIGHT / 2 - 1) == 1);
	REQUIRE(GetHeaderVersion(Environment::MAINNET, YEAR_HEIGHT / 2) == 2);
	REQUIRE(GetHeaderVersion(Environment::MAINNET, YEAR_HEIGHT / 2 + 1) == 2);
	REQUIRE(GetHeaderVersion(Environment::MAINNET, YEAR_HEIGHT - 1) == 2);
	REQUIRE(GetHeaderVersion(Environment::MAINNET, YEAR_HEIGHT) == 3);
	REQUIRE(GetHeaderVersion(Environment::MAINNET, ((YEAR_HEIGHT * 3) / 2) - 1) == 3);
	REQUIRE(GetHeaderVersion(Environment::MAINNET, (YEAR_HEIGHT * 3) / 2) == 4);
	REQUIRE(GetHeaderVersion(Environment::MAINNET, (YEAR_HEIGHT * 2) - 1) == 4);
	REQUIRE(GetHeaderVersion(Environment::MAINNET, (YEAR_HEIGHT * 2)) == 5);
}

TEST_CASE("NRD pre-HF3 test seam is explicitly scoped")
{
	REQUIRE(!IsNrdBeforeHf3OverrideForTesting());
	SetNrdBeforeHf3OverrideForTesting(true);
	REQUIRE(IsNrdBeforeHf3OverrideForTesting());
	SetNrdBeforeHf3OverrideForTesting(false);
	REQUIRE(!IsNrdBeforeHf3OverrideForTesting());
}