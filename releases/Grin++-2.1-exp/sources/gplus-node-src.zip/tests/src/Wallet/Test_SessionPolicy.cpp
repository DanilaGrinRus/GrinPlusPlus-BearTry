#include <catch.hpp>

#include "Wallet/SessionManager.h"
#include "API/Wallet/Owner/Handlers/GetWalletSeedHandler.h"
#include "API/Wallet/Owner/Handlers/LoginHandler.h"
#include "API/Wallet/Owner/Handlers/LogoutAllHandler.h"

#include <API/Wallet/Owner/Models/Errors.h>
#include <Core/Exceptions/APIException.h>
#include <Net/Clients/RPC/RPC.h>
#include <Wallet/Exceptions/KeyChainException.h>

#include <chrono>
#include <cstddef>
#include <memory>
#include <optional>
#include <stdexcept>
#include <string>
#include <vector>

namespace
{
	using Seconds = std::chrono::seconds;
	using SafeTimePoint = SessionPolicy::TimePoint;

	//
	// F-13 unit-test double: implements the whole IWalletManager surface, but only
	// the login/seed lookups used by LoginHandler and GetWalletSeedHandler have
	// behaviour. Everything else is unreachable in these tests.
	//
	class MockWalletManager : public IWalletManager
	{
	public:
		bool m_seedSucceeds{ false };
		std::vector<GrinStr> m_accounts;
		std::size_t m_loginAttempts{ 0 };
		std::size_t m_seedAttempts{ 0 };
		std::size_t m_logoutAllCalls{ 0 };

		bool ShouldReuseAddresses() final { return true; }

		Locked<Wallet> GetWallet(const SessionToken&) final
		{
			throw std::runtime_error("MockWalletManager::GetWallet is not implemented");
		}

		CreateWalletResponse InitializeNewWallet(const CreateWalletCriteria&, const TorProcess::Ptr&) final
		{
			throw std::runtime_error("MockWalletManager::InitializeNewWallet is not implemented");
		}

		LoginResponse RestoreFromSeed(const RestoreWalletCriteria&, const TorProcess::Ptr&) final
		{
			throw std::runtime_error("MockWalletManager::RestoreFromSeed is not implemented");
		}

		SecureString GetSeedWords(const GetSeedPhraseCriteria&) final
		{
			++m_seedAttempts;
			if (!m_seedSucceeds) {
				throw KEYCHAIN_EXCEPTION("Failed to decrypt seed.");
			}

			const std::string words =
				"abandon ability able about above absent absorb abstract absurd abuse access accident";
			return SecureString(words.begin(), words.end());
		}

		void CheckForOutputs(const SessionToken&, const bool) final
		{
			throw std::runtime_error("MockWalletManager::CheckForOutputs is not implemented");
		}

		std::vector<GrinStr> GetAllAccounts() const final { return m_accounts; }

		std::optional<TorAddress> AddTorListener(
			const SessionToken&,
			const KeyChainPath&,
			const TorProcess::Ptr&) final
		{
			throw std::runtime_error("MockWalletManager::AddTorListener is not implemented");
		}

		bool RemoveCurrentTorListener(const SessionToken&, const TorProcess::Ptr&) final
		{
			throw std::runtime_error("MockWalletManager::RemoveCurrentTorListener is not implemented");
		}

		KeyChainPath IncreaseAddressKeyChainPathIndex(const SessionToken&) final
		{
			throw std::runtime_error("MockWalletManager::IncreaseAddressKeyChainPathIndex is not implemented");
		}

		LoginResponse Login(const LoginCriteria&, const TorProcess::Ptr&) final
		{
			++m_loginAttempts;
			throw KEYCHAIN_EXCEPTION("Failed to decrypt seed.");
		}

		void Logout(const SessionToken&) final { }
		void LogoutAll(const SessionToken&) final { ++m_logoutAllCalls; }
		void DeleteWallet(const GrinStr&, const SecureString&) final { }
		void ChangePassword(const GrinStr&, const SecureString&, const SecureString&) final { }

		Slate Send(const SendCriteria&) final
		{
			throw std::runtime_error("MockWalletManager::Send is not implemented");
		}

		Slate Receive(const ReceiveCriteria&) final
		{
			throw std::runtime_error("MockWalletManager::Receive is not implemented");
		}

		Slate Finalize(const FinalizeCriteria&, const TorProcess::Ptr&) final
		{
			throw std::runtime_error("MockWalletManager::Finalize is not implemented");
		}

		bool PostTransaction(const Transaction&, const PostMethodDTO&, const TorProcess::Ptr&) final
		{
			throw std::runtime_error("MockWalletManager::PostTransaction is not implemented");
		}

		bool RepostTx(const RepostTxCriteria&, const TorProcess::Ptr&) final
		{
			throw std::runtime_error("MockWalletManager::RepostTx is not implemented");
		}
	};

	struct FakeClock
	{
		LoginThrottle::TimePoint now{ Seconds(0) };

		LoginThrottle::NowFunction AsFunction()
		{
			return [this]() { return now; };
		}
	};

	// Keeps LoginThrottle::Instance() clean even when a REQUIRE fails early.
	struct ThrottleResetGuard
	{
		ThrottleResetGuard() { LoginThrottle::Instance().Reset(); }
		~ThrottleResetGuard() { LoginThrottle::Instance().Reset(); }
	};

	// Installs a deterministic clock for LoginThrottle::Instance() and restores
	// the real clock on scope exit (including failures).
	struct ThrottleClockGuard
	{
		explicit ThrottleClockGuard(FakeClock& clock)
		{
			LoginThrottle::Instance().OverrideClockForTesting(clock.AsFunction());
			LoginThrottle::Instance().Reset();
		}

		~ThrottleClockGuard()
		{
			LoginThrottle::Instance().OverrideClockForTesting(LoginThrottle::NowFunction());
			LoginThrottle::Instance().Reset();
		}
	};

	RPC::Request MakeLoginRequest(const std::string& username)
	{
		Json::Value params(Json::objectValue);
		params["username"] = username;
		params["password"] = "wrong-password";
		return RPC::Request::BuildRequest("login", params);
	}

	RPC::Request MakeSeedRequest(const std::string& username)
	{
		Json::Value params(Json::objectValue);
		params["username"] = username;
		params["password"] = "wrong-password";
		return RPC::Request::BuildRequest("get_wallet_seed", params);
	}

	RPC::Request MakeLogoutAllRequest(const std::string& tokenBase64)
	{
		Json::Value params(Json::objectValue);
		params["session_token"] = tokenBase64;
		return RPC::Request::BuildRequest("logout_all", params);
	}

	APIException CatchApiException(const RPC::Request& request, const RPCMethod& handler)
	{
		try {
			handler.Handle(request);
		}
		catch (const APIException& e) {
			return e;
		}
		catch (...) {
			throw std::runtime_error("Expected an APIException, got another exception type");
		}

		throw std::runtime_error("Expected an APIException, but the handler returned a response");
	}
}

TEST_CASE("SessionPolicy: idle and absolute TTL boundaries")
{
	const SessionPolicy::Limits limits{ Seconds(100), Seconds(10), 5 };
	SafeTimePoint now = SafeTimePoint(Seconds(0));
	const SessionPolicy policy(limits, [&now]() { return now; });
	const SafeTimePoint createdAt = SafeTimePoint(Seconds(0));

	now = createdAt + Seconds(9);
	REQUIRE(policy.CheckExpiry(createdAt, createdAt, now) == SessionPolicy::EExpiry::VALID);

	// The idle timeout is inclusive (>=).
	now = createdAt + Seconds(10);
	REQUIRE(policy.CheckExpiry(createdAt, createdAt, now) == SessionPolicy::EExpiry::IDLE_EXPIRED);

	// Activity extends the idle window...
	const SafeTimePoint activeAt = createdAt + Seconds(50);
	now = activeAt + Seconds(9);
	REQUIRE(policy.CheckExpiry(createdAt, activeAt, now) == SessionPolicy::EExpiry::VALID);

	// ...but never the absolute lifetime, which wins over idleness.
	now = activeAt + Seconds(10);
	REQUIRE(policy.CheckExpiry(createdAt, activeAt, now) == SessionPolicy::EExpiry::IDLE_EXPIRED);

	now = createdAt + Seconds(100);
	REQUIRE(policy.CheckExpiry(createdAt, activeAt, now) == SessionPolicy::EExpiry::ABSOLUTE_EXPIRED);

	// Default limits: 12h absolute / 60min idle.
	const SessionPolicy defaults;
	REQUIRE(defaults.GetLimits().absoluteTtl == std::chrono::hours(12));
	REQUIRE(defaults.GetLimits().idleTtl == std::chrono::minutes(60));
	REQUIRE(defaults.GetLimits().maxSessionsPerUser == 5);
}

TEST_CASE("SessionPolicy: LRU victim selection for the per-user session limit")
{
	std::vector<std::pair<uint64_t, SafeTimePoint>> sessions;
	sessions.emplace_back(1, SafeTimePoint(Seconds(100)));
	sessions.emplace_back(2, SafeTimePoint(Seconds(200)));
	sessions.emplace_back(3, SafeTimePoint(Seconds(300)));
	sessions.emplace_back(4, SafeTimePoint(Seconds(50)));
	sessions.emplace_back(5, SafeTimePoint(Seconds(400)));

	const std::optional<uint64_t> victim = SessionPolicy::SelectLruVictim(sessions);
	REQUIRE(victim.has_value());
	REQUIRE(victim.value() == 4);

	// Ties are broken deterministically by the smallest session id.
	std::vector<std::pair<uint64_t, SafeTimePoint>> tied;
	tied.emplace_back(7, SafeTimePoint(Seconds(10)));
	tied.emplace_back(3, SafeTimePoint(Seconds(10)));
	tied.emplace_back(5, SafeTimePoint(Seconds(20)));
	const std::optional<uint64_t> tiedVictim = SessionPolicy::SelectLruVictim(tied);
	REQUIRE(tiedVictim.has_value());
	REQUIRE(tiedVictim.value() == 3);

	REQUIRE_FALSE(SessionPolicy::SelectLruVictim(std::vector<std::pair<uint64_t, SafeTimePoint>>()).has_value());
}

TEST_CASE("LoginThrottle: exponential backoff with a 15 minute cap")
{
	FakeClock clock;
	LoginThrottle throttle(clock.AsFunction());
	const std::string username = "alice";

	const uint32_t failuresBeforeLockout = LoginThrottle::FAILURES_BEFORE_LOCKOUT;
	for (uint32_t i = 0; i + 1 < failuresBeforeLockout; ++i) {
		throttle.RecordFailure(username);
		REQUIRE_FALSE(throttle.GetLockoutRemaining(username).has_value());
	}

	throttle.RecordFailure(username); // 5th consecutive failure
	REQUIRE(throttle.GetLockoutRemaining(username).has_value());
	REQUIRE(throttle.GetLockoutRemaining(username).value() == Seconds(30));

	clock.now += Seconds(30);
	REQUIRE_FALSE(throttle.GetLockoutRemaining(username).has_value());

	// Further failures double the lockout: 60s, 120s, 240s, 480s, then 900s cap.
	const std::chrono::seconds expected[] = {
		Seconds(60), Seconds(120), Seconds(240), Seconds(480), Seconds(900), Seconds(900)
	};
	for (const std::chrono::seconds& expectedLockout : expected) {
		throttle.RecordFailure(username);
		REQUIRE(throttle.GetLockoutRemaining(username).has_value());
		REQUIRE(throttle.GetLockoutRemaining(username).value() == expectedLockout);
		clock.now += expectedLockout;
	}
}

TEST_CASE("LoginThrottle: a success resets the failure counter and the lockout")
{
	FakeClock clock;
	LoginThrottle throttle(clock.AsFunction());
	const std::string username = "bob";

	for (uint32_t i = 0; i < LoginThrottle::FAILURES_BEFORE_LOCKOUT; ++i) {
		throttle.RecordFailure(username);
	}
	REQUIRE(throttle.GetLockoutRemaining(username).value() == Seconds(30));

	throttle.RecordSuccess(username);
	REQUIRE_FALSE(throttle.GetLockoutRemaining(username).has_value());

	// After a success the next failure starts a fresh sequence: 4 failures do
	// not lock the user out.
	for (uint32_t i = 0; i < LoginThrottle::FAILURES_BEFORE_LOCKOUT - 1; ++i) {
		throttle.RecordFailure(username);
	}
	REQUIRE_FALSE(throttle.GetLockoutRemaining(username).has_value());
}

TEST_CASE("LoginThrottle: seed requests are rate limited per user")
{
	FakeClock clock;
	LoginThrottle throttle(clock.AsFunction());

	REQUIRE(throttle.TryAcquireSeedRequest("alice"));
	REQUIRE_FALSE(throttle.TryAcquireSeedRequest("alice"));

	// A different user has an independent budget.
	REQUIRE(throttle.TryAcquireSeedRequest("bob"));

	clock.now += std::chrono::milliseconds(1999);
	REQUIRE_FALSE(throttle.TryAcquireSeedRequest("alice"));

	clock.now += std::chrono::milliseconds(1);
	REQUIRE(throttle.TryAcquireSeedRequest("alice"));
}

TEST_CASE("F-02: login does not reveal whether the username exists")
{
	const ThrottleResetGuard guard;
	(void)guard;

	LoginThrottle& throttle = LoginThrottle::Instance();
	throttle.Reset();

	auto pWalletManager = std::make_shared<MockWalletManager>();
	pWalletManager->m_accounts = { GrinStr("alice") };
	const LoginHandler handler(pWalletManager, nullptr);

	const APIException existingUser = CatchApiException(MakeLoginRequest("alice"), handler);
	REQUIRE(existingUser.GetErrorCode() == RPC::Errors::INVALID_PASSWORD.GetCode());
	REQUIRE(existingUser.GetMsg() == "Invalid username or password");
	REQUIRE(pWalletManager->m_loginAttempts == 1);

	throttle.Reset();
	const APIException unknownUser = CatchApiException(MakeLoginRequest("nobody"), handler);
	REQUIRE(unknownUser.GetErrorCode() == existingUser.GetErrorCode());
	REQUIRE(unknownUser.GetMsg() == existingUser.GetMsg());
	// The unknown username never reaches the wallet manager.
	REQUIRE(pWalletManager->m_loginAttempts == 1);
}

TEST_CASE("F-02: login lockout blocks requests and is symmetric for unknown users")
{
	FakeClock clock;
	const ThrottleClockGuard clockGuard(clock);
	(void)clockGuard;

	auto pWalletManager = std::make_shared<MockWalletManager>();
	pWalletManager->m_accounts = { GrinStr("alice") };
	const LoginHandler handler(pWalletManager, nullptr);

	const uint32_t failuresBeforeLockout = LoginThrottle::FAILURES_BEFORE_LOCKOUT;
	for (uint32_t i = 0; i < failuresBeforeLockout; ++i) {
		const APIException e = CatchApiException(MakeLoginRequest("alice"), handler);
		REQUIRE(e.GetErrorCode() == RPC::Errors::INVALID_PASSWORD.GetCode());
	}
	REQUIRE(pWalletManager->m_loginAttempts == failuresBeforeLockout);

	// The next attempt is rejected before the wallet manager is called.
	const APIException lockedOut = CatchApiException(MakeLoginRequest("alice"), handler);
	REQUIRE(lockedOut.GetErrorCode() == RPC::Errors::INVALID_PASSWORD.GetCode());
	REQUIRE(lockedOut.GetMsg().find("Too many failed login attempts") != std::string::npos);
	REQUIRE(pWalletManager->m_loginAttempts == failuresBeforeLockout);

	// A non-existent username is throttled identically, so lockout cannot be
	// used to enumerate accounts.
	for (uint32_t i = 0; i < failuresBeforeLockout; ++i) {
		CatchApiException(MakeLoginRequest("nobody"), handler);
	}
	const APIException unknownLockedOut = CatchApiException(MakeLoginRequest("nobody"), handler);
	REQUIRE(unknownLockedOut.GetMsg() == lockedOut.GetMsg());

	// The lockout expires after the configured backoff.
	clock.now += Seconds(30);
	CatchApiException(MakeLoginRequest("alice"), handler);
	REQUIRE(pWalletManager->m_loginAttempts == failuresBeforeLockout + 1);
}

TEST_CASE("F-02: get_wallet_seed is rate limited and shares the login lockout")
{
	FakeClock clock;
	const ThrottleClockGuard clockGuard(clock);
	(void)clockGuard;

	auto pWalletManager = std::make_shared<MockWalletManager>();
	pWalletManager->m_accounts = { GrinStr("alice") };
	pWalletManager->m_seedSucceeds = true;
	const GetWalletSeedHandler handler(pWalletManager);

	const Json::Value success = handler.Handle(MakeSeedRequest("alice")).ToJSON();
	REQUIRE(success["result"]["wallet_seed"].isString());
	REQUIRE(
		success["result"]["wallet_seed"].asString() ==
		"abandon ability able about above absent absorb abstract absurd abuse access accident"
	);
	REQUIRE(pWalletManager->m_seedAttempts == 1);

	// The second request inside the 2 second window is refused before the
	// wallet manager is touched.
	const APIException rateLimited = CatchApiException(MakeSeedRequest("alice"), handler);
	REQUIRE(rateLimited.GetErrorCode() == RPC::Errors::INVALID_PASSWORD.GetCode());
	REQUIRE(rateLimited.GetMsg().find("Too many seed phrase requests") != std::string::npos);
	REQUIRE(pWalletManager->m_seedAttempts == 1);

	clock.now += std::chrono::milliseconds(2000);
	REQUIRE(handler.Handle(MakeSeedRequest("alice")).ToJSON()["result"]["wallet_seed"].isString());
	REQUIRE(pWalletManager->m_seedAttempts == 2);

	// Wrong passwords feed the shared failure counter; after 5 consecutive
	// failures the lockout takes effect (checked before the rate limit).
	pWalletManager->m_seedSucceeds = false;
	for (uint32_t i = 0; i < LoginThrottle::FAILURES_BEFORE_LOCKOUT; ++i) {
		// Stay outside the 2s seed-rate-limit window so the assertion targets the
		// password failure path, not the (also correct) rate-limit refusal.
		clock.now += std::chrono::milliseconds(2000);
		const APIException e = CatchApiException(MakeSeedRequest("alice"), handler);
		REQUIRE(e.GetErrorCode() == RPC::Errors::INVALID_PASSWORD.GetCode());
		REQUIRE(e.GetMsg() == "Invalid username or password");
	}
	const APIException lockedOut = CatchApiException(MakeSeedRequest("alice"), handler);
	REQUIRE(lockedOut.GetMsg().find("Too many failed attempts") != std::string::npos);
}

TEST_CASE("F-02: get_wallet_seed hides unknown usernames")
{
	const ThrottleResetGuard guard;
	(void)guard;

	auto pWalletManager = std::make_shared<MockWalletManager>();
	pWalletManager->m_accounts = { GrinStr("alice") };
	pWalletManager->m_seedSucceeds = false;
	const GetWalletSeedHandler handler(pWalletManager);

	const APIException unknownUser = CatchApiException(MakeSeedRequest("nobody"), handler);
	REQUIRE(unknownUser.GetErrorCode() == RPC::Errors::INVALID_PASSWORD.GetCode());
	REQUIRE(unknownUser.GetMsg() == "Invalid username or password");
	REQUIRE(pWalletManager->m_seedAttempts == 0);

	const APIException wrongPassword = CatchApiException(MakeSeedRequest("alice"), handler);
	REQUIRE(wrongPassword.GetErrorCode() == unknownUser.GetErrorCode());
	REQUIRE(wrongPassword.GetMsg() == unknownUser.GetMsg());
	REQUIRE(pWalletManager->m_seedAttempts == 1);
}

TEST_CASE("F-03: logout_all forwards the token to the wallet manager")
{
	const ThrottleResetGuard guard;
	(void)guard;

	auto pWalletManager = std::make_shared<MockWalletManager>();
	const LogoutAllHandler handler(pWalletManager);

	// SessionToken::ToBase64()/FromBase64() round-trips (u64 id + byte vector).
	const SessionToken token(7, std::vector<unsigned char>{ 1, 2, 3 });
	const RPC::Response response = handler.Handle(MakeLogoutAllRequest(token.ToBase64()));
	const Json::Value json = response.ToJSON();
	// BuildResult(Json::Value()) serializes an empty result; the important part is
	// that no error was produced and the manager was asked to drop the sessions.
	REQUIRE(json["error"].isNull());
	REQUIRE(pWalletManager->m_logoutAllCalls == 1);
}
