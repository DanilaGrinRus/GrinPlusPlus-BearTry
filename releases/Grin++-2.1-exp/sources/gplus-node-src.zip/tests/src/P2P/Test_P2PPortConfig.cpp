#include <catch.hpp>

#include <Core/Config/P2PConfig.h>
#include <Core/Enums/Environment.h>

namespace
{
	P2PConfig WithPort(const Json::Value& portValue)
	{
		Json::Value json;
		json[ConfigProps::P2P::P2P] = Json::Value();
		json[ConfigProps::P2P::P2P][ConfigProps::P2P::P2P_PORT] = portValue;
		return P2PConfig(Environment::FLOONET, json);
	}
}

TEST_CASE("P2PConfig::ReadsConfiguredP2PPort")
{
	Json::Value json;
	json[ConfigProps::P2P::P2P] = Json::Value();
	json[ConfigProps::P2P::P2P][ConfigProps::P2P::P2P_PORT] = 44556;

	const P2PConfig config(Environment::FLOONET, json);
	REQUIRE(config.GetP2PPort() == 44556);
}

TEST_CASE("P2PConfig::UsesNetworkDefaultPortWithoutOverride")
{
	const Json::Value json;
	const P2PConfig mainnet(Environment::MAINNET, json);
	const P2PConfig floonet(Environment::FLOONET, json);

	REQUIRE(mainnet.GetP2PPort() == 3414);
	REQUIRE(floonet.GetP2PPort() == 13414);
}

TEST_CASE("P2PConfig::AcceptsPortRangeBoundaries")
{
	REQUIRE(WithPort(1).GetP2PPort() == 1);
	REQUIRE(WithPort(44100).GetP2PPort() == 44100);
	REQUIRE(WithPort(65535).GetP2PPort() == 65535);
}

TEST_CASE("P2PConfig::RejectsInvalidPortWithoutWrapping")
{
	const uint16_t floonetDefault = 13414;

	// Zero and negative values must not wrap; >65535 must not truncate to 0.
	REQUIRE(WithPort(0).GetP2PPort() == floonetDefault);
	REQUIRE(WithPort(-1).GetP2PPort() == floonetDefault);
	REQUIRE(WithPort(65536).GetP2PPort() == floonetDefault);
	REQUIRE(WithPort(1000000).GetP2PPort() == floonetDefault);

	// Wrong JSON type is ignored rather than coerced.
	REQUIRE(WithPort("44556").GetP2PPort() == floonetDefault);
	REQUIRE(WithPort(44556.5).GetP2PPort() == floonetDefault);
}

//
// G-09: archive-serving opt-in is read from server_config.json and is OFF by
// default on every network. Mainnet needs a second, mainnet-only confirmation.
//
namespace
{
	P2PConfig WithArchiveServing(const Json::Value& serving, const Json::Value& mainnet)
	{
		Json::Value json;
		json[ConfigProps::P2P::P2P] = Json::Value();
		json[ConfigProps::P2P::P2P][ConfigProps::P2P::PIBD_ARCHIVE_SERVING] = serving;
		json[ConfigProps::P2P::P2P][ConfigProps::P2P::PIBD_ARCHIVE_SERVING_MAINNET] = mainnet;
		return P2PConfig(Environment::FLOONET, json);
	}
}

TEST_CASE("P2PConfig::PibdArchiveServingDefaultsOff")
{
	const Json::Value empty;
	const P2PConfig config(Environment::FLOONET, empty);
	REQUIRE_FALSE(config.IsPibdArchiveServingEnabled());
	REQUIRE_FALSE(config.IsPibdArchiveServingMainnetEnabled());
}

TEST_CASE("P2PConfig::PibdArchiveServingIsParsedExplicitly")
{
	const P2PConfig off = WithArchiveServing(false, false);
	REQUIRE_FALSE(off.IsPibdArchiveServingEnabled());

	const P2PConfig on = WithArchiveServing(true, false);
	REQUIRE(on.IsPibdArchiveServingEnabled());
	REQUIRE_FALSE(on.IsPibdArchiveServingMainnetEnabled());

	const P2PConfig mainnet = WithArchiveServing(true, true);
	REQUIRE(mainnet.IsPibdArchiveServingEnabled());
	REQUIRE(mainnet.IsPibdArchiveServingMainnetEnabled());
}

TEST_CASE("P2PConfig::PibdArchiveServingIgnoresWrongJsonType")
{
	// Strings are not booleans; 0/1 integers are accepted (server_config.json may
	// store either form).
	const P2PConfig config = WithArchiveServing("yes", 1);
	REQUIRE_FALSE(config.IsPibdArchiveServingEnabled());
	REQUIRE(config.IsPibdArchiveServingMainnetEnabled());

	const P2PConfig wrong = WithArchiveServing("yes", "no");
	REQUIRE_FALSE(wrong.IsPibdArchiveServingMainnetEnabled());
}

namespace
{
	P2PConfig WithArchivePolicy(const Json::Value& retention, const Json::Value& maxRequests)
	{
		Json::Value json;
		json[ConfigProps::P2P::P2P] = Json::Value();
		json[ConfigProps::P2P::P2P][ConfigProps::P2P::PIBD_ARCHIVE_RETENTION] = retention;
		json[ConfigProps::P2P::P2P][ConfigProps::P2P::PIBD_ARCHIVE_MAX_REQUESTS_PER_MINUTE] = maxRequests;
		return P2PConfig(Environment::FLOONET, json);
	}
}

TEST_CASE("P2PConfig::PibdArchivePolicyDefaults")
{
	const Json::Value empty;
	const P2PConfig config(Environment::FLOONET, empty);
	REQUIRE(config.GetPibdArchiveRetention() == 1);
	REQUIRE(config.GetPibdArchiveMaxRequestsPerMinute() == 2000);
}

TEST_CASE("P2PConfig::PibdArchivePolicyIsParsedWithBounds")
{
	REQUIRE(WithArchivePolicy(2, 500).GetPibdArchiveRetention() == 2);
	REQUIRE(WithArchivePolicy(2, 500).GetPibdArchiveMaxRequestsPerMinute() == 500);
	REQUIRE(WithArchivePolicy(8, 100000).GetPibdArchiveRetention() == 8);

	// Out-of-range/wrong-type values fall back to the safe defaults.
	REQUIRE(WithArchivePolicy(0, 0).GetPibdArchiveRetention() == 1);
	REQUIRE(WithArchivePolicy(0, 0).GetPibdArchiveMaxRequestsPerMinute() == 2000);
	REQUIRE(WithArchivePolicy(9, 100001).GetPibdArchiveRetention() == 1);
	REQUIRE(WithArchivePolicy(-1, "many").GetPibdArchiveRetention() == 1);
}
