#include <catch.hpp>

#include <Core/Enums/ProtocolVersion.h>
#include <Core/Models/BlockHeader.h>
#include <Core/Serialization/ByteBuffer.h>
#include <Core/Serialization/Serializer.h>
#include <Core/Exceptions/DeserializationException.h>
#include <Crypto/Models/BlindingFactor.h>
#include <Crypto/Models/Hash.h>
#include <P2P/Capabilities.h>
#include <P2P/Common.h>
#include <P2P/HeaderProof.h>
#include <P2P/Messages/GetHeaderProofsMessage.h>
#include <P2P/Messages/HeaderProofsMessage.h>
#include <P2P/Messages/MessageTypes.h>
#include <PMMR/Common/Index.h>
#include <PMMR/Common/MMRHashUtil.h>
#include <PMMR/Common/MMRUtil.h>

#include <cstdint>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace
{
	Hash MakeHash(const uint8_t tag)
	{
		return Hash(std::vector<unsigned char>(32, tag));
	}

	// Arbitrary but serialization-stable header. The header hash commits only to
	// the packed PoW cycle, so distinct powTag values give distinct hashes.
	BlockHeader MakeHeader(
		const uint64_t height,
		const uint64_t powTag,
		const uint64_t totalDifficulty,
		const int64_t timestamp,
		const Hash& previousHash,
		const Hash& previousRoot,
		const uint16_t version = 5)
	{
		std::vector<uint64_t> nonces(Consensus::PROOFSIZE);
		for (size_t i = 0; i < nonces.size(); ++i) {
			nonces[i] = powTag * 100 + i;
		}

		ProofOfWork proofOfWork(Consensus::SECOND_POW_EDGE_BITS, std::move(nonces));
		return BlockHeader(
			version,
			height,
			timestamp,
			Hash(previousHash),
			Hash(previousRoot),
			Hash(HASH::ZERO),
			Hash(HASH::ZERO),
			Hash(HASH::ZERO),
			BlindingFactor(),
			1,
			1,
			totalDifficulty,
			0,
			powTag,
			std::move(proofOfWork));
	}

	// In-memory header MMR, built exactly like HeaderMMR::AddHeader (leaf hash
	// over the PoW cycle, parent hashes over child positions).
	struct SyntheticMmr
	{
		std::vector<BlockHeader> headers;
		std::vector<Hash> nodes;
	};

	SyntheticMmr BuildMmr(const uint64_t leafCount, const uint16_t headerVersion = 5)
	{
		SyntheticMmr mmr;
		mmr.headers.reserve(leafCount);
		for (uint64_t height = 0; height < leafCount; ++height) {
			mmr.headers.push_back(MakeHeader(
				height,
				height + 1,
				100 + height,
				1'600'000'000 + (int64_t)height,
				HASH::ZERO,
				HASH::ZERO,
				headerVersion));
		}

		for (uint64_t height = 0; height < leafCount; ++height) {
			const uint64_t position = MMRUtil::InsertionToPmmrIndex(height);
			REQUIRE(position == mmr.nodes.size());
			mmr.nodes.push_back(HeaderProof::ComputeLeafHash(mmr.headers[height], position));

			for (Index index = Index::At(mmr.nodes.size()); !index.IsLeaf(); ++index) {
				mmr.nodes.push_back(MMRHashUtil::HashParentWithIndex(
					mmr.nodes[index.GetLeftChild().GetPosition()],
					mmr.nodes[index.GetRightChild().GetPosition()],
					index.Get()));
			}
		}

		return mmr;
	}

	HeaderProof::HashReader ReaderFor(const SyntheticMmr& mmr)
	{
		return [&mmr](const uint64_t position) -> std::optional<Hash> {
			if (position >= mmr.nodes.size()) {
				return std::nullopt;
			}

			return mmr.nodes[position];
		};
	}

	HeaderProofsMessage BuildProofs(
		const SyntheticMmr& mmr,
		const BlockHeader& anchor,
		const std::vector<uint64_t>& heights)
	{
		const HeaderProof::HashReader reader = ReaderFor(mmr);
		const uint64_t mmrSize = MMRUtil::InsertionToPmmrIndex(anchor.GetHeight());

		std::vector<HeaderProofsMessage::Item> items;
		items.reserve(heights.size());
		for (const uint64_t height : heights) {
			const uint64_t position = MMRUtil::InsertionToPmmrIndex(height);
			items.emplace_back(
				mmr.headers[height],
				HeaderProof::BuildProof(reader, mmrSize, position));
		}

		return HeaderProofsMessage(anchor.GetHash(), mmrSize, std::move(items));
	}

	std::vector<uint8_t> MessageBody(const IMessage& message)
	{
		const std::vector<uint8_t> frame = message.Serialize(EProtocolVersion::V1);
		REQUIRE(frame.size() > 11);
		return std::vector<uint8_t>(frame.cbegin() + 11, frame.cend());
	}
}

TEST_CASE("HeaderProof::CapabilityBit")
{
	REQUIRE((uint32_t)Capabilities::HEADER_PROOF_HIST == 0x100u);
	REQUIRE(((uint32_t)Capabilities::ADVERTISED & 0x100u) == 0x100u);
	REQUIRE(Capabilities::Advertised(false).HasCapability(Capabilities::HEADER_PROOF_HIST));

	// Existing bits must be untouched.
	REQUIRE((uint32_t)Capabilities::TX_KERNEL_HASH == 0x08u);
	REQUIRE((uint32_t)Capabilities::PIBD_HIST == 0x10u);
	REQUIRE((uint32_t)Capabilities::BLOCK_HIST == 0x20u);
	REQUIRE((uint32_t)Capabilities::PIBD_HIST_1 == 0x40u);
	REQUIRE((uint32_t)Capabilities::PIHD_HIST == 0x80u);
}

TEST_CASE("HeaderProof::MessageTypesAndLimits")
{
	REQUIRE(MessageTypes::GetHeaderProofs == 31);
	REQUIRE(MessageTypes::HeaderProofs == 32);
	REQUIRE(MessageTypes::GetMaximumSize(MessageTypes::GetHeaderProofs) == 546u);
	REQUIRE(MessageTypes::GetMaximumSize(MessageTypes::HeaderProofs) == 168170u);
	REQUIRE(P2P::MAX_HEADER_PROOF_ITEMS == 64u);
	REQUIRE(P2P::MAX_HEADER_PROOF_PATH == 64u);
}

TEST_CASE("HeaderProof::GetHeaderProofsWireRoundtrip")
{
	const Hash anchor = MakeHash(0x11);
	const std::vector<uint64_t> heights = { 0, 1, 7, 42 };
	const GetHeaderProofsMessage request(anchor, heights);

	const std::vector<uint8_t> body = MessageBody(request);
	REQUIRE(body.size() == 32u + 2u + heights.size() * 8u);

	ByteBuffer buffer(body, EProtocolVersion::V1);
	const GetHeaderProofsMessage decoded = GetHeaderProofsMessage::Deserialize(buffer);
	REQUIRE(decoded.GetAnchor() == anchor);
	REQUIRE(decoded.GetHeights() == heights);
}

TEST_CASE("HeaderProof::GetHeaderProofsWireBounds")
{
	// count = 65 is a wire bound violation.
	{
		std::vector<uint8_t> body(32, 0);
		body.push_back(0);
		body.push_back(65);
		ByteBuffer buffer(body, EProtocolVersion::V1);
		REQUIRE_THROWS_AS(
			GetHeaderProofsMessage::Deserialize(buffer),
			DeserializationException);
	}

	// Truncated heights array is a wire error.
	{
		const GetHeaderProofsMessage request(MakeHash(0x12), { 1, 2, 3 });
		std::vector<uint8_t> body = MessageBody(request);
		body.resize(body.size() - 3);
		ByteBuffer buffer(body, EProtocolVersion::V1);
		REQUIRE_THROWS_AS(
			GetHeaderProofsMessage::Deserialize(buffer),
			DeserializationException);
	}

	// Zero count and unsorted heights are accepted by the parser: those are
	// semantic checks for the handler, not wire errors.
	{
		std::vector<uint8_t> body(32, 0);
		body.push_back(0);
		body.push_back(0);
		ByteBuffer buffer(body, EProtocolVersion::V1);
		const GetHeaderProofsMessage decoded = GetHeaderProofsMessage::Deserialize(buffer);
		REQUIRE(decoded.GetHeights().empty());
	}

	{
		const GetHeaderProofsMessage request(MakeHash(0x13), { 5, 2 });
		ByteBuffer buffer(MessageBody(request), EProtocolVersion::V1);
		const GetHeaderProofsMessage decoded = GetHeaderProofsMessage::Deserialize(buffer);
		REQUIRE(decoded.GetHeights() == std::vector<uint64_t>{ 5, 2 });
	}
}

TEST_CASE("HeaderProof::HeaderProofsWireRoundtrip")
{
	const Hash anchor = MakeHash(0x22);
	const BlockHeader header0 = MakeHeader(0, 7, 100, 1'600'000'000, HASH::ZERO, HASH::ZERO);
	const BlockHeader header1 = MakeHeader(1, 8, 200, 1'600'000'001, header0.GetHash(), HASH::ZERO);

	std::vector<HeaderProofsMessage::Item> items;
	items.emplace_back(header0, std::vector<Hash>{ MakeHash(0x33) });
	items.emplace_back(header1, std::vector<Hash>{ MakeHash(0x44), MakeHash(0x55) });

	const HeaderProofsMessage proofs(anchor, 9, std::move(items));
	const std::vector<uint8_t> body = MessageBody(proofs);

	ByteBuffer buffer(body, EProtocolVersion::V1);
	const HeaderProofsMessage decoded = HeaderProofsMessage::Deserialize(buffer);
	REQUIRE(decoded.GetAnchor() == anchor);
	REQUIRE(decoded.GetMmrSize() == 9u);
	REQUIRE(decoded.GetItems().size() == 2u);
	REQUIRE(decoded.GetItems()[0].header.GetHeight() == 0u);
	REQUIRE(decoded.GetItems()[0].header.GetHash() == header0.GetHash());
	REQUIRE(decoded.GetItems()[0].path.size() == 1u);
	REQUIRE(decoded.GetItems()[1].header.GetHeight() == 1u);
	REQUIRE(decoded.GetItems()[1].path.size() == 2u);
	REQUIRE(decoded.GetItems()[1].path[1] == MakeHash(0x55));
}

TEST_CASE("HeaderProof::HeaderProofsWireBounds")
{
	const BlockHeader header = MakeHeader(0, 11, 100, 1'600'000'000, HASH::ZERO, HASH::ZERO);

	Serializer headerSerializer;
	header.Serialize(headerSerializer);

	// path_len = 64 is accepted.
	{
		std::vector<uint8_t> body(40, 0);
		body.push_back(0);
		body.push_back(1);
		body.insert(body.end(), headerSerializer.GetBytes().cbegin(), headerSerializer.GetBytes().cend());
		body.push_back((uint8_t)P2P::MAX_HEADER_PROOF_PATH);
		body.insert(body.end(), (size_t)P2P::MAX_HEADER_PROOF_PATH * 32u, 0);

		ByteBuffer buffer(body, EProtocolVersion::V1);
		const HeaderProofsMessage decoded = HeaderProofsMessage::Deserialize(buffer);
		REQUIRE(decoded.GetItems().size() == 1u);
		REQUIRE(decoded.GetItems()[0].path.size() == P2P::MAX_HEADER_PROOF_PATH);
	}

	// path_len = 65 is a wire bound violation.
	{
		std::vector<uint8_t> body(40, 0);
		body.push_back(0);
		body.push_back(1);
		body.insert(body.end(), headerSerializer.GetBytes().cbegin(), headerSerializer.GetBytes().cend());
		body.push_back((uint8_t)(P2P::MAX_HEADER_PROOF_PATH + 1));

		ByteBuffer buffer(body, EProtocolVersion::V1);
		REQUIRE_THROWS_AS(
			HeaderProofsMessage::Deserialize(buffer),
			DeserializationException);
	}

	// count = 65 is a wire bound violation.
	{
		std::vector<uint8_t> body(40, 0);
		body.push_back(0);
		body.push_back(65);

		ByteBuffer buffer(body, EProtocolVersion::V1);
		REQUIRE_THROWS_AS(
			HeaderProofsMessage::Deserialize(buffer),
			DeserializationException);
	}

	// Truncated path is a wire error.
	{
		std::vector<uint8_t> body(40, 0);
		body.push_back(0);
		body.push_back(1);
		body.insert(body.end(), headerSerializer.GetBytes().cbegin(), headerSerializer.GetBytes().cend());
		body.push_back(2);
		body.insert(body.end(), (size_t)2 * 32u, 0);
		body.resize(body.size() - 5);

		ByteBuffer buffer(body, EProtocolVersion::V1);
		REQUIRE_THROWS_AS(
			HeaderProofsMessage::Deserialize(buffer),
			DeserializationException);
	}

	// Zero count is accepted by the parser (semantic rejection is the client's).
	{
		std::vector<uint8_t> body(40, 0);
		body.push_back(0);
		body.push_back(0);

		ByteBuffer buffer(body, EProtocolVersion::V1);
		const HeaderProofsMessage decoded = HeaderProofsMessage::Deserialize(buffer);
		REQUIRE(decoded.GetItems().empty());
	}
}

TEST_CASE("HeaderProof::PureMmrProofs")
{
	const SyntheticMmr mmr = BuildMmr(16);
	const HeaderProof::HashReader reader = ReaderFor(mmr);
	const uint64_t mmrSize = mmr.nodes.size();
	REQUIRE(mmrSize == 31u);

	const Hash root = HeaderProof::ComputeRoot(reader, mmrSize);
	REQUIRE(root == mmr.nodes.back());

	for (uint64_t height = 0; height < 16; ++height) {
		const uint64_t position = MMRUtil::InsertionToPmmrIndex(height);
		const Hash leaf = HeaderProof::ComputeLeafHash(mmr.headers[height], position);
		const std::vector<Hash> path = HeaderProof::BuildProof(reader, mmrSize, position);
		REQUIRE(path.size() <= P2P::MAX_HEADER_PROOF_PATH);
		REQUIRE(HeaderProof::VerifyProof(root, mmrSize, position, leaf, path));

		// Tampered path.
		std::vector<Hash> badPath = path;
		REQUIRE(!badPath.empty());
		badPath[0][0] = (unsigned char)(badPath[0][0] ^ 0xFF);
		REQUIRE_FALSE(HeaderProof::VerifyProof(root, mmrSize, position, leaf, badPath));

		// Wrong root.
		REQUIRE_FALSE(HeaderProof::VerifyProof(MakeHash(0xEE), mmrSize, position, leaf, path));

		// Wrong leaf.
		REQUIRE_FALSE(HeaderProof::VerifyProof(
			root, mmrSize, position, HeaderProof::ComputeLeafHash(mmr.headers[(height + 1) % 16], position), path));

		// Wrong position (another leaf's path cannot verify this leaf).
		if (height > 0) {
			const uint64_t otherPosition = MMRUtil::InsertionToPmmrIndex(height - 1);
			REQUIRE_FALSE(HeaderProof::VerifyProof(root, mmrSize, otherPosition, leaf, path));
		}
	}

	// A non-leaf position, an invalid MMR size and a missing hash are errors.
	REQUIRE_THROWS(HeaderProof::BuildProof(reader, mmrSize, 2));
	REQUIRE_THROWS(HeaderProof::BuildProof(reader, mmrSize - 1, 0));
	REQUIRE_THROWS(HeaderProof::BuildProof(reader, mmrSize, 30));

	const HeaderProof::HashReader emptyReader = [](const uint64_t) -> std::optional<Hash> {
		return std::nullopt;
	};
	REQUIRE_THROWS(HeaderProof::BuildProof(emptyReader, mmrSize, 0));
	REQUIRE_FALSE(HeaderProof::VerifyProof(root, 0, 0, HASH::ZERO, {}));
}

TEST_CASE("HeaderProof::MembershipPositive")
{
	const SyntheticMmr mmr = BuildMmr(16);
	const HeaderProof::HashReader reader = ReaderFor(mmr);
	const uint64_t mmrSize = mmr.nodes.size();
	const Hash root = HeaderProof::ComputeRoot(reader, mmrSize);

	const BlockHeader anchor = MakeHeader(
		16, 999, 10'000, 1'600'000'100, MakeHash(0x77), root);
	REQUIRE(anchor.GetPreviousRoot() == root);

	const std::vector<uint64_t> heights = { 0, 1, 2, 7, 8, 15 };
	const HeaderProofsMessage proofs = BuildProofs(mmr, anchor, heights);
	REQUIRE(proofs.GetMmrSize() == MMRUtil::InsertionToPmmrIndex(16));
	REQUIRE(HeaderProof::VerifyMemberships(anchor, proofs));

	// Wrong anchor header (different hash).
	const BlockHeader otherAnchor = MakeHeader(
		16, 1000, 10'000, 1'600'000'100, MakeHash(0x77), root);
	REQUIRE_FALSE(HeaderProof::VerifyMemberships(otherAnchor, proofs));

	// Wrong mmr_size.
	const HeaderProofsMessage wrongSize(anchor.GetHash(), proofs.GetMmrSize() + 1,
		std::vector<HeaderProofsMessage::Item>(proofs.GetItems()));
	REQUIRE_FALSE(HeaderProof::VerifyMemberships(anchor, wrongSize));

	// Wrong anchor echo in the message.
	const HeaderProofsMessage wrongEcho(MakeHash(0xAB), proofs.GetMmrSize(),
		std::vector<HeaderProofsMessage::Item>(proofs.GetItems()));
	REQUIRE_FALSE(HeaderProof::VerifyMemberships(anchor, wrongEcho));

	// Unsorted heights.
	const HeaderProofsMessage unsorted(anchor.GetHash(), proofs.GetMmrSize(),
		std::vector<HeaderProofsMessage::Item>{ proofs.GetItems()[1], proofs.GetItems()[0] });
	REQUIRE_FALSE(HeaderProof::VerifyMemberships(anchor, unsorted));

	// Corrupted path.
	std::vector<HeaderProofsMessage::Item> badItems(proofs.GetItems());
	REQUIRE(!badItems[0].path.empty());
	badItems[0].path[0][0] = (unsigned char)(badItems[0].path[0][0] ^ 0xFF);
	const HeaderProofsMessage badPath(anchor.GetHash(), proofs.GetMmrSize(), std::move(badItems));
	REQUIRE_FALSE(HeaderProof::VerifyMemberships(anchor, badPath));

	// Header height does not match its requested height.
	std::vector<HeaderProofsMessage::Item> wrongHeightItems(proofs.GetItems());
	wrongHeightItems[0].header = mmr.headers[3];
	const HeaderProofsMessage wrongHeight(anchor.GetHash(), proofs.GetMmrSize(), std::move(wrongHeightItems));
	REQUIRE_FALSE(HeaderProof::VerifyMemberships(anchor, wrongHeight));

	// Empty item list.
	const HeaderProofsMessage empty(anchor.GetHash(), proofs.GetMmrSize(), {});
	REQUIRE_FALSE(HeaderProof::VerifyMemberships(anchor, empty));

	// Height at or above the anchor is rejected.
	const HeaderProofsMessage aboveAnchor(anchor.GetHash(), proofs.GetMmrSize(),
		std::vector<HeaderProofsMessage::Item>{ proofs.GetItems()[0], proofs.GetItems()[1] });
	REQUIRE_FALSE(HeaderProof::VerifyMemberships(
		MakeHeader(1, 42, 1, 1'600'000'000, HASH::ZERO, root), aboveAnchor));
}

TEST_CASE("HeaderProof::StrictVerifierRejectsPreHf4")
{
	const SyntheticMmr mmr = BuildMmr(16, 1);
	const HeaderProof::HashReader reader = ReaderFor(mmr);
	const uint64_t mmrSize = mmr.nodes.size();
	const Hash root = HeaderProof::ComputeRoot(reader, mmrSize);

	const BlockHeader anchor = MakeHeader(
		16, 999, 10'000, 1'600'000'100, MakeHash(0x77), root);
	const HeaderProofsMessage proofs = BuildProofs(mmr, anchor, { 0, 1, 2 });
	REQUIRE(HeaderProof::VerifyMemberships(anchor, proofs));

	// Version 1 is what the chain expects at these low heights, so the verifier
	// reaches the explicit pre-HF4 rejection (DMA/dual-PoW is out of scope).
	std::string error;
	REQUIRE_FALSE(HeaderProof::VerifyHeaderProofsWithPoW(anchor, proofs, {}, &error));
	REQUIRE(error.find("pre-HF4") != std::string::npos);

	// Wrong anchor / broken membership is still rejected first.
	const BlockHeader otherAnchor = MakeHeader(
		16, 1001, 10'000, 1'600'000'100, MakeHash(0x78), root);
	REQUIRE_FALSE(HeaderProof::VerifyHeaderProofsWithPoW(otherAnchor, proofs, {}, &error));
	REQUIRE(error.find("membership") != std::string::npos);
}

TEST_CASE("HeaderProof::MultiPeakMembership")
{
	// Regression: peak bagging must hash with the historical MMR size as the
	// virtual parent index (ComputeRoot / bag_the_rhs semantics). Using the live
	// parent position broke every multi-peak anchor, i.e. almost all mainnet
	// anchors, while perfect-size MMRs (single peak) happened to pass.
	const std::vector<uint64_t> leafCounts = { 3, 5, 7, 11, 13, 19 };
	for (const uint64_t leafCount : leafCounts)
	{
		const SyntheticMmr mmr = BuildMmr(leafCount);
		const HeaderProof::HashReader reader = ReaderFor(mmr);
		const uint64_t mmrSize = mmr.nodes.size();
		REQUIRE(mmrSize == MMRUtil::InsertionToPmmrIndex(leafCount));
		REQUIRE(MMRUtil::GetPeakIndices(mmrSize).size() > 1);

		const Hash root = HeaderProof::ComputeRoot(reader, mmrSize);
		const BlockHeader anchor = MakeHeader(
			leafCount, 900 + leafCount, 10'000, 1'600'000'100,
			MakeHash((uint8_t)(0x40 + leafCount)), root);

		const std::vector<uint64_t> heights = { 0, leafCount / 2, leafCount - 1 };
		const HeaderProofsMessage proofs = BuildProofs(mmr, anchor, heights);
		REQUIRE(HeaderProof::VerifyMemberships(anchor, proofs));

		// Every individual pure path must verify too.
		for (const uint64_t height : heights)
		{
			const uint64_t position = MMRUtil::InsertionToPmmrIndex(height);
			const std::vector<Hash> path = HeaderProof::BuildProof(reader, mmrSize, position);
			REQUIRE(HeaderProof::VerifyProof(
				root, mmrSize, position, mmr.nodes[position], path));
		}

		// A corrupted path must still be rejected.
		std::vector<HeaderProofsMessage::Item> badItems(proofs.GetItems());
		REQUIRE(!badItems[0].path.empty());
		badItems[0].path[0][0] = (unsigned char)(badItems[0].path[0][0] ^ 0xFF);
		const HeaderProofsMessage badPath(
			anchor.GetHash(), proofs.GetMmrSize(), std::move(badItems));
		REQUIRE_FALSE(HeaderProof::VerifyMemberships(anchor, badPath));
	}
}
