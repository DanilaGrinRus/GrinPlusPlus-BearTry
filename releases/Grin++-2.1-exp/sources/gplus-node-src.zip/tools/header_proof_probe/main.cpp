// Live probe for the experimental HEADER_PROOF_HIST capability
// (Grin PR #3963 port, P2P messages 31 GetHeaderProofs / 32 HeaderProofs).
//
// The probe behaves like an ordinary outbound Grin++ peer for the handshake
// (Hand -> Shake), then acts as a header-proof client:
//   1. GET /v1/status        -> tip height / total difficulty
//   2. GET /v1/headers/<h>   -> anchor header (h = tip.height - lag)
//   3. send GetHeaderProofs   for heights {anchor-3, anchor-2, anchor-1}
//   4. verify the HeaderProofs reply with the feature's own verifier
//      (HeaderProof::VerifyProof / VerifyHeaderProofItem / VerifyMemberships)
//   5. optionally bind the header fields through VerifyHeaderProofsWithPoW
//
// The wire framing mirrors src/P2P/Messages/Message.h and exactly matches the
// client: [magic:u8][magic:u8][type:u8][length:u64 BE][body]. Message bodies are
// built with the project's Serializer, and replies are parsed with the
// project's message classes, so the probe cannot drift from the real wire
// format by construction.

#include <Consensus.h>
#include <Core/Genesis.h>
#include <Core/Models/BlockHeader.h>
#include <Core/Models/ProofOfWork.h>
#include <Core/Serialization/ByteBuffer.h>
#include <Core/Serialization/Serializer.h>
#include <Crypto/Models/BlindingFactor.h>
#include <Crypto/Models/Hash.h>
#include <Net/IPAddress.h>
#include <Net/SocketAddress.h>
#include <P2P/Capabilities.h>
#include <P2P/Common.h>
#include <P2P/HeaderProof.h>
#include <P2P/Messages/HeaderProofsMessage.h>
#include <P2P/Messages/MessageTypes.h>
#include <P2P/Messages/ShakeMessage.h>
#include <PMMR/Common/Index.h>
#include <PMMR/Common/LeafIndex.h>

#include <asio.hpp>
#include <json/json.h>

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>
#include <thread>
#include <utility>
#include <vector>

namespace
{
	const char* const DEFAULT_HOST = "127.0.0.1";
	const uint16_t DEFAULT_P2P_PORT = 13418;
	const uint16_t DEFAULT_REST_PORT = 19118;
	const uint64_t DEFAULT_ANCHOR_LAG = 10;
	const int DEFAULT_TIMEOUT_MS = 8000;

	// Mainnet magic bytes, from P2PConfig (src/Core/Config/P2PConfig.h).
	// Hardcoded on purpose: IMessage::Serialize reads Global::GetConfig(), and
	// the probe must not construct a node Context (that would start Tor and
	// touch node data directories).
	const uint8_t MAGIC_BYTE_0 = 97;
	const uint8_t MAGIC_BYTE_1 = 61;

	const size_t MAX_FRAME_BYTES = 4 * 1024 * 1024;
	const size_t MAX_HTTP_BYTES = 8 * 1024 * 1024;

	using TimePoint = std::chrono::steady_clock::time_point;

	TimePoint DeadlineAfter(const int milliseconds)
	{
		return std::chrono::steady_clock::now() + std::chrono::milliseconds(milliseconds);
	}

	std::string HexMask(const uint32_t value)
	{
		std::ostringstream stream;
		stream << "0x" << std::uppercase << std::hex << value;
		return stream.str();
	}

	std::string ShortHash(const Hash& hash)
	{
		const std::string hex = hash.ToHex();
		if (hex.size() <= 16) {
			return hex;
		}

		return hex.substr(0, 16) + "..";
	}

	std::string CapabilityNames(const uint32_t mask)
	{
		struct Bit
		{
			uint32_t value;
			const char* name;
		};

		static const Bit BITS[] = {
			{ 0x01, "HEADER_HIST" },
			{ 0x02, "TXHASHSET_HIST" },
			{ 0x04, "PEER_LIST" },
			{ 0x08, "TX_KERNEL_HASH" },
			{ 0x10, "PIBD_HIST" },
			{ 0x20, "BLOCK_HIST" },
			{ 0x40, "PIBD_HIST_1" },
			{ 0x80, "PIHD_HIST" },
			{ 0x100, "HEADER_PROOF_HIST" },
		};

		std::string names;
		uint32_t known = 0;
		for (const Bit& bit : BITS) {
			known |= bit.value;
			if ((mask & bit.value) != 0) {
				if (!names.empty()) {
					names += "|";
				}
				names += bit.name;
			}
		}

		const uint32_t unknown = mask & ~known;
		if (unknown != 0) {
			if (!names.empty()) {
				names += "|";
			}
			names += "UNKNOWN(" + HexMask(unknown) + ")";
		}

		return names.empty() ? std::string("none") : names;
	}

	// Capabilities advertised by this probe. Grin++ only requires a peer to speak
	// the protocol; the mask is what a Grin++ node would send (0x10F before the
	// PIBD archive is ready, 0x15F with PIBD bits).
	uint32_t ProbeCapabilities()
	{
		return (uint32_t)(
			Capabilities::HEADER_HIST |
			Capabilities::TXHASHET_HIST |
			Capabilities::PEER_LIST |
			Capabilities::TX_KERNEL_HASH |
			Capabilities::HEADER_PROOF_HIST);
	}

	const char* MessageTypeName(const uint8_t type)
	{
		switch (type) {
			case MessageTypes::Error: return "Error";
			case MessageTypes::Hand: return "Hand";
			case MessageTypes::Shake: return "Shake";
			case MessageTypes::Ping: return "Ping";
			case MessageTypes::Pong: return "Pong";
			case MessageTypes::GetPeerAddrs: return "GetPeerAddrs";
			case MessageTypes::PeerAddrs: return "PeerAddrs";
			case MessageTypes::GetHeaders: return "GetHeaders";
			case MessageTypes::Header: return "Header";
			case MessageTypes::Headers: return "Headers";
			case MessageTypes::GetBlock: return "GetBlock";
			case MessageTypes::Block: return "Block";
			case MessageTypes::GetCompactBlock: return "GetCompactBlock";
			case MessageTypes::CompactBlockMsg: return "CompactBlock";
			case MessageTypes::StemTransaction: return "StemTransaction";
			case MessageTypes::TransactionMsg: return "Transaction";
			case MessageTypes::TxHashSetRequest: return "TxHashSetRequest";
			case MessageTypes::TxHashSetArchive: return "TxHashSetArchive";
			case MessageTypes::BanReasonMsg: return "BanReason";
			case MessageTypes::GetTransactionMsg: return "GetTransaction";
			case MessageTypes::TransactionKernelMsg: return "TransactionKernel";
			case MessageTypes::GetOutputBitmapSegment: return "GetOutputBitmapSegment";
			case MessageTypes::OutputBitmapSegment: return "OutputBitmapSegment";
			case MessageTypes::GetOutputSegment: return "GetOutputSegment";
			case MessageTypes::OutputSegment: return "OutputSegment";
			case MessageTypes::GetRangeProofSegment: return "GetRangeProofSegment";
			case MessageTypes::RangeProofSegment: return "RangeProofSegment";
			case MessageTypes::GetKernelSegment: return "GetKernelSegment";
			case MessageTypes::KernelSegment: return "KernelSegment";
			case MessageTypes::GetHeaderSegment: return "GetHeaderSegment";
			case MessageTypes::HeaderSegment: return "HeaderSegment";
			case MessageTypes::GetHeaderProofs: return "GetHeaderProofs(31)";
			case MessageTypes::HeaderProofs: return "HeaderProofs(32)";
			default: return "unknown";
		}
	}

	//
	// Command line
	//

	struct Options
	{
		std::string host = DEFAULT_HOST;
		std::string bindAddress = DEFAULT_HOST;
		uint16_t p2pPort = DEFAULT_P2P_PORT;
		uint16_t restPort = DEFAULT_REST_PORT;
		uint64_t anchorLag = DEFAULT_ANCHOR_LAG;
		uint64_t anchorHeight = 0;
		bool hasAnchorHeight = false;
		int timeoutMs = DEFAULT_TIMEOUT_MS;
		bool descending = false;
		bool powCheck = true;
	};

	void PrintUsage(const char* argv0)
	{
		std::cout
			<< "Usage: " << argv0 << " [options]\n"
			<< "  --host <ip>          node address (default " << DEFAULT_HOST << ")\n"
			<< "  --p2p-port <port>    P2P port (default " << DEFAULT_P2P_PORT << ")\n"
			<< "  --rest-port <port>   REST port (default " << DEFAULT_REST_PORT << ")\n"
			<< "  --bind <ip>          local source address (default " << DEFAULT_HOST
			<< "; use 127.0.0.2 if the node already has a peer from 127.0.0.1)\n"
			<< "  --anchor-lag <n>     anchor height = tip.height - n (default " << DEFAULT_ANCHOR_LAG << ")\n"
			<< "  --anchor-height <n>  use an explicit anchor height instead of tip - lag\n"
			<< "  --timeout-ms <n>     per-step network timeout (default " << DEFAULT_TIMEOUT_MS << ")\n"
			<< "  --descending         request heights in descending order (anchor-1,-2,-3) instead\n"
			<< "                       of the ascending order the server contract requires\n"
			<< "  --no-pow-check       skip the optional VerifyHeaderProofsWithPoW binding step\n"
			<< "  --help               show this text\n";
	}

	bool ParseUnsigned(const std::string& text, uint64_t& out)
	{
		if (text.empty()) {
			return false;
		}

		uint64_t value = 0;
		for (const char c : text) {
			if (c < '0' || c > '9') {
				return false;
			}
			const uint64_t digit = (uint64_t)(c - '0');
			if (value > (UINT64_MAX - digit) / 10) {
				return false;
			}
			value = value * 10 + digit;
		}

		out = value;
		return true;
	}

	bool ParseArgs(const int argc, char* argv[], Options& options, std::string& error)
	{
		for (int i = 1; i < argc; ++i) {
			const std::string arg = argv[i];
			if (arg == "--help") {
				return false;
			}

			const auto nextValue = [&](std::string& value) -> bool {
				if (i + 1 >= argc) {
					error = "missing value for " + arg;
					return false;
				}
				value = argv[++i];
				return true;
			};

			if (arg == "--host") {
				if (!nextValue(options.host)) return false;
			} else if (arg == "--bind") {
				if (!nextValue(options.bindAddress)) return false;
			} else if (arg == "--p2p-port") {
				std::string value;
				if (!nextValue(value)) return false;
				uint64_t parsed = 0;
				if (!ParseUnsigned(value, parsed) || parsed == 0 || parsed > 65535) {
					error = "invalid --p2p-port: " + value;
					return false;
				}
				options.p2pPort = (uint16_t)parsed;
			} else if (arg == "--rest-port") {
				std::string value;
				if (!nextValue(value)) return false;
				uint64_t parsed = 0;
				if (!ParseUnsigned(value, parsed) || parsed == 0 || parsed > 65535) {
					error = "invalid --rest-port: " + value;
					return false;
				}
				options.restPort = (uint16_t)parsed;
			} else if (arg == "--anchor-lag") {
				std::string value;
				if (!nextValue(value)) return false;
				if (!ParseUnsigned(value, options.anchorLag)) {
					error = "invalid --anchor-lag: " + value;
					return false;
				}
			} else if (arg == "--anchor-height") {
				std::string value;
				if (!nextValue(value)) return false;
				if (!ParseUnsigned(value, options.anchorHeight)) {
					error = "invalid --anchor-height: " + value;
					return false;
				}
				options.hasAnchorHeight = true;
			} else if (arg == "--timeout-ms") {
				std::string value;
				if (!nextValue(value)) return false;
				uint64_t parsed = 0;
				if (!ParseUnsigned(value, parsed) || parsed < 100 || parsed > 120000) {
					error = "invalid --timeout-ms: " + value;
					return false;
				}
				options.timeoutMs = (int)parsed;
			} else if (arg == "--descending") {
				options.descending = true;
			} else if (arg == "--no-pow-check") {
				options.powCheck = false;
			} else {
				error = "unknown argument: " + arg;
				return false;
			}
		}

		return true;
	}

	//
	// HTTP (REST) client: plain HTTP/1.x GET against the local node.
	//

	std::string ToLowerAscii(const std::string& text)
	{
		std::string out = text;
		for (char& c : out) {
			if (c >= 'A' && c <= 'Z') {
				c = (char)(c - 'A' + 'a');
			}
		}
		return out;
	}

	std::string TrimAscii(const std::string& text)
	{
		size_t begin = 0;
		while (begin < text.size() && (text[begin] == ' ' || text[begin] == '\t' || text[begin] == '\r' || text[begin] == '\n')) {
			++begin;
		}

		size_t end = text.size();
		while (end > begin && (text[end - 1] == ' ' || text[end - 1] == '\t' || text[end - 1] == '\r' || text[end - 1] == '\n')) {
			--end;
		}

		return text.substr(begin, end - begin);
	}

	bool DecodeChunkedBody(const std::string& raw, std::string& out, std::string& error)
	{
		size_t index = 0;
		out.clear();
		while (index < raw.size()) {
			const size_t lineEnd = raw.find("\r\n", index);
			if (lineEnd == std::string::npos) {
				error = "truncated chunk header";
				return false;
			}

			const std::string sizeLine = TrimAscii(raw.substr(index, lineEnd - index));
			uint64_t chunkSize = 0;
			if (sizeLine.empty()) {
				error = "empty chunk header";
				return false;
			}

			for (const char c : sizeLine) {
				uint64_t digit = 0;
				if (c >= '0' && c <= '9') {
					digit = (uint64_t)(c - '0');
				} else if (c >= 'a' && c <= 'f') {
					digit = (uint64_t)(c - 'a' + 10);
				} else if (c >= 'A' && c <= 'F') {
					digit = (uint64_t)(c - 'A' + 10);
				} else {
					error = "invalid chunk size line: " + sizeLine;
					return false;
				}
				chunkSize = (chunkSize << 4) | digit;
			}

			index = lineEnd + 2;
			if (chunkSize == 0) {
				return true;
			}

			if (index + (size_t)chunkSize > raw.size()) {
				error = "truncated chunk body";
				return false;
			}

			out.append(raw, index, (size_t)chunkSize);
			index += (size_t)chunkSize + 2;
		}

		return true;
	}

	struct HttpResponse
	{
		int status = 0;
		std::string body;
	};

	class HttpClient
	{
	public:
		static bool Get(
			const std::string& host,
			const uint16_t port,
			const std::string& path,
			const int timeoutMs,
			HttpResponse& response,
			std::string& error)
		{
			asio::io_context ioContext;
			asio::ip::tcp::socket socket(ioContext);

			asio::error_code ec;
			const asio::ip::address address = asio::ip::make_address(host, ec);
			if (ec) {
				error = "invalid host address " + host;
				return false;
			}

			socket.open(asio::ip::tcp::v4(), ec);
			if (ec) {
				error = "failed to open REST socket: " + ec.message();
				return false;
			}

			const asio::ip::tcp::endpoint endpoint(address, port);
			socket.connect(endpoint, ec);
			if (ec) {
				error = "cannot connect to http://" + host + ":" + std::to_string(port) + " (" + ec.message() + ")";
				return false;
			}

			std::string request;
			request += "GET " + path + " HTTP/1.1\r\n";
			request += "Host: " + host + ":" + std::to_string(port) + "\r\n";
			request += "Connection: close\r\n";
			request += "Accept: application/json\r\n";
			request += "\r\n";

			asio::write(socket, asio::buffer(request), ec);
			if (ec) {
				error = "failed to send HTTP request: " + ec.message();
				return false;
			}

			socket.non_blocking(true, ec);
			if (ec) {
				error = "failed to switch REST socket to non-blocking: " + ec.message();
				return false;
			}

			std::string raw;
			if (!ReadRaw(socket, DeadlineAfter(timeoutMs), raw, error)) {
				return false;
			}

			return ParseResponse(raw, response, error);
		}

	private:
		static bool ReadRaw(
			asio::ip::tcp::socket& socket,
			const TimePoint deadline,
			std::string& raw,
			std::string& error)
		{
			size_t headerEnd = std::string::npos;
			size_t expectedTotal = std::string::npos;
			bool chunked = false;

			for (;;) {
				if (headerEnd == std::string::npos) {
					headerEnd = raw.find("\r\n\r\n");
					if (headerEnd != std::string::npos) {
						const std::string headerBlock = ToLowerAscii(raw.substr(0, headerEnd));
						chunked = headerBlock.find("transfer-encoding: chunked") != std::string::npos;
						const size_t lengthPos = headerBlock.find("content-length:");
						if (!chunked && lengthPos != std::string::npos) {
							const size_t valueBegin = lengthPos + std::strlen("content-length:");
							const size_t valueEnd = headerBlock.find("\r\n", valueBegin);
							const std::string value = TrimAscii(
								headerBlock.substr(valueBegin, valueEnd == std::string::npos ? std::string::npos : valueEnd - valueBegin));
							uint64_t declared = 0;
							if (ParseUnsigned(value, declared)) {
								expectedTotal = headerEnd + 4 + (size_t)declared;
							}
						}
					}
				}

				if (headerEnd != std::string::npos && !chunked && expectedTotal != std::string::npos &&
					raw.size() >= expectedTotal) {
					return true;
				}

				asio::error_code ec;
				const size_t available = socket.available(ec);
				if (ec) {
					error = "REST read failed: " + ec.message();
					return false;
				}

				if (available == 0) {
					if (std::chrono::steady_clock::now() >= deadline) {
						error = "REST response timed out";
						return false;
					}
					std::this_thread::sleep_for(std::chrono::milliseconds(5));
					continue;
				}

				char buffer[8192];
				const size_t want = (std::min)(available, sizeof(buffer));
				const size_t received = socket.read_some(asio::buffer(buffer, want), ec);
				if (ec == asio::error::would_block || ec == asio::error::try_again) {
					continue;
				}
				if (ec == asio::error::eof) {
					// Connection closed; the body is whatever we collected.
					return headerEnd != std::string::npos;
				}
				if (ec) {
					error = "REST read failed: " + ec.message();
					return false;
				}
				if (received == 0) {
					return headerEnd != std::string::npos;
				}

				raw.append(buffer, received);
				if (raw.size() > MAX_HTTP_BYTES) {
					error = "REST response is too large";
					return false;
				}
			}
		}

		static bool ParseResponse(const std::string& raw, HttpResponse& response, std::string& error)
		{
			const size_t headerEnd = raw.find("\r\n\r\n");
			if (headerEnd == std::string::npos) {
				error = "malformed HTTP response (no header terminator)";
				return false;
			}

			const std::string headerBlock = raw.substr(0, headerEnd);
			const size_t statusLineEnd = headerBlock.find("\r\n");
			const std::string statusLine =
				statusLineEnd == std::string::npos ? headerBlock : headerBlock.substr(0, statusLineEnd);

			std::istringstream statusStream(statusLine);
			std::string httpVersion;
			int status = 0;
			statusStream >> httpVersion >> status;
			if (status <= 0) {
				error = "malformed HTTP status line: " + statusLine;
				return false;
			}

			std::string body = raw.substr(headerEnd + 4);
			const std::string lowerHeaders = ToLowerAscii(headerBlock);
			if (lowerHeaders.find("transfer-encoding: chunked") != std::string::npos) {
				std::string decoded;
				if (!DecodeChunkedBody(body, decoded, error)) {
					return false;
				}
				body = std::move(decoded);
			} else {
				const size_t lengthPos = lowerHeaders.find("content-length:");
				if (lengthPos != std::string::npos) {
					const size_t valueBegin = lengthPos + std::strlen("content-length:");
					const size_t valueEnd = lowerHeaders.find("\r\n", valueBegin);
					const std::string value = TrimAscii(
						lowerHeaders.substr(valueBegin, valueEnd == std::string::npos ? std::string::npos : valueEnd - valueBegin));
					uint64_t declared = 0;
					if (ParseUnsigned(value, declared)) {
						if (body.size() > (size_t)declared) {
							body.resize((size_t)declared);
						} else if (body.size() < (size_t)declared) {
							error = "truncated HTTP body";
							return false;
						}
					}
				}
			}

			response.status = status;
			response.body = std::move(body);
			return true;
		}
	};

	bool ParseJson(const std::string& text, Json::Value& json, std::string& error)
	{
		Json::CharReaderBuilder builder;
		std::string parseErrors;
		std::istringstream stream(text);
		if (!Json::parseFromStream(builder, stream, &json, &parseErrors)) {
			error = "invalid JSON: " + TrimAscii(parseErrors);
			return false;
		}
		return true;
	}

	const Json::Value* FindField(const Json::Value& node, const char* name)
	{
		if (!node.isObject() || !node.isMember(name)) {
			return nullptr;
		}
		return &node[name];
	}

	bool ReadUInt64(const Json::Value& node, const char* name, uint64_t& value, std::string& error)
	{
		const Json::Value* field = FindField(node, name);
		if (field == nullptr || !((*field).isUInt64() || (*field).isInt64() || (*field).isUInt() || (*field).isInt())) {
			error = std::string("missing or non-numeric field '") + name + "'";
			return false;
		}
		value = (*field).asUInt64();
		return true;
	}

	std::string ReadString(const Json::Value& node, const char* name)
	{
		const Json::Value* field = FindField(node, name);
		if (field == nullptr || !(*field).isString()) {
			return std::string();
		}
		return (*field).asString();
	}

	// Builds a BlockHeader from the node's /v1/headers/<height> JSON. The
	// timestamp is taken from 'timestamp_raw' because TimeUtil::FromString()
	// parses the human-readable 'timestamp' as local time, which would shift the
	// PoW pre-image for non-UTC hosts.
	bool BuildBlockHeader(const Json::Value& json, BlockHeaderPtr& header, std::string& error)
	{
		if (!json.isObject()) {
			error = "header response is not a JSON object";
			return false;
		}

		uint64_t version = 0;
		uint64_t height = 0;
		uint64_t timestamp = 0;
		uint64_t outputMmrSize = 0;
		uint64_t kernelMmrSize = 0;
		uint64_t totalDifficulty = 0;
		uint64_t scaling = 0;
		uint64_t nonce = 0;
		uint64_t edgeBits = 0;

		if (!ReadUInt64(json, "version", version, error) ||
			!ReadUInt64(json, "height", height, error) ||
			!ReadUInt64(json, "timestamp_raw", timestamp, error) ||
			!ReadUInt64(json, "output_mmr_size", outputMmrSize, error) ||
			!ReadUInt64(json, "kernel_mmr_size", kernelMmrSize, error) ||
			!ReadUInt64(json, "total_difficulty", totalDifficulty, error) ||
			!ReadUInt64(json, "secondary_scaling", scaling, error) ||
			!ReadUInt64(json, "nonce", nonce, error) ||
			!ReadUInt64(json, "edge_bits", edgeBits, error)) {
			return false;
		}

		const std::string previous = ReadString(json, "previous");
		const std::string prevRoot = ReadString(json, "prev_root");
		const std::string outputRoot = ReadString(json, "output_root");
		const std::string rangeProofRoot = ReadString(json, "range_proof_root");
		const std::string kernelRoot = ReadString(json, "kernel_root");
		const std::string kernelOffset = ReadString(json, "total_kernel_offset");
		if (previous.size() != 64 || prevRoot.size() != 64 || outputRoot.size() != 64 ||
			rangeProofRoot.size() != 64 || kernelRoot.size() != 64 || kernelOffset.size() != 64) {
			error = "header response is missing a 32-byte hash field";
			return false;
		}

		const Json::Value* solution = FindField(json, "cuckoo_solution");
		if (solution == nullptr || !(*solution).isArray() || (*solution).size() != Consensus::PROOFSIZE) {
			error = "header response has an invalid cuckoo_solution";
			return false;
		}

		if (edgeBits == 0 || edgeBits > 63) {
			error = "header response has an invalid edge_bits value";
			return false;
		}

		std::vector<uint64_t> nonces;
		nonces.reserve((*solution).size());
		for (const Json::Value& value : *solution) {
			if (!value.isUInt64() && !value.isInt64() && !value.isUInt()) {
				error = "header response has a non-numeric cuckoo nonce";
				return false;
			}
			nonces.push_back(value.asUInt64());
		}

		try {
			std::shared_ptr<BlockHeader> built = std::make_shared<BlockHeader>(
				(uint16_t)version,
				height,
				(int64_t)timestamp,
				Hash::FromHex(previous),
				Hash::FromHex(prevRoot),
				Hash::FromHex(outputRoot),
				Hash::FromHex(rangeProofRoot),
				Hash::FromHex(kernelRoot),
				BlindingFactor::FromHex(kernelOffset),
				outputMmrSize,
				kernelMmrSize,
				totalDifficulty,
				(uint32_t)scaling,
				nonce,
				ProofOfWork((uint8_t)edgeBits, std::move(nonces)));
			header = BlockHeaderPtr(std::move(built));
		} catch (const std::exception& e) {
			error = std::string("failed to build BlockHeader from REST JSON: ") + e.what();
			return false;
		}

		return true;
	}

	//
	// P2P client (Hand/Shake handshake + message 31/32)
	//

	class P2PClient
	{
	public:
		explicit P2PClient(asio::io_context& ioContext)
			: m_socket(ioContext), m_localPort(0)
		{
		}

		bool Connect(
			const std::string& bindAddress,
			const std::string& host,
			const uint16_t port,
			std::string& error)
		{
			asio::error_code ec;
			const asio::ip::address bindIp = asio::ip::make_address(bindAddress, ec);
			if (ec || !bindIp.is_v4()) {
				error = "invalid IPv4 bind address: " + bindAddress;
				return false;
			}

			const asio::ip::address peerIp = asio::ip::make_address(host, ec);
			if (ec || !peerIp.is_v4()) {
				error = "invalid IPv4 peer address: " + host;
				return false;
			}

			m_socket.open(asio::ip::tcp::v4(), ec);
			if (ec) {
				error = "failed to open P2P socket: " + ec.message();
				return false;
			}

			m_socket.bind(asio::ip::tcp::endpoint(bindIp, 0), ec);
			if (ec) {
				error = "failed to bind P2P socket to " + bindAddress + ": " + ec.message();
				return false;
			}

			m_socket.connect(asio::ip::tcp::endpoint(peerIp, port), ec);
			if (ec) {
				error = "cannot connect to P2P " + host + ":" + std::to_string(port) + " (" + ec.message() + ")";
				return false;
			}

			m_localIp = bindIp.to_string();
			m_localPort = m_socket.local_endpoint(ec).port();
			return true;
		}

		uint16_t GetLocalPort() const noexcept { return m_localPort; }
		const std::string& GetLocalAddress() const noexcept { return m_localIp; }

		bool Send(const uint8_t type, const std::vector<uint8_t>& body, std::string& error)
		{
			std::vector<uint8_t> frame;
			frame.reserve(11 + body.size());
			frame.push_back(MAGIC_BYTE_0);
			frame.push_back(MAGIC_BYTE_1);
			frame.push_back(type);
			for (int shift = 56; shift >= 0; shift -= 8) {
				frame.push_back((uint8_t)((body.size() >> shift) & 0xFF));
			}
			frame.insert(frame.end(), body.cbegin(), body.cend());

			asio::error_code ec;
			m_socket.non_blocking(false, ec);
			asio::write(m_socket, asio::buffer(frame), ec);
			m_socket.non_blocking(true, ec);
			if (ec) {
				error = "failed to send P2P message: " + ec.message();
				return false;
			}

			return true;
		}

		bool Receive(const TimePoint deadline, uint8_t& type, std::vector<uint8_t>& payload, std::string& error)
		{
			uint8_t header[11];
			if (!ReadExact(header, sizeof(header), deadline, error)) {
				return false;
			}

			if (header[0] != MAGIC_BYTE_0 || header[1] != MAGIC_BYTE_1) {
				error = "peer sent a message with unexpected magic bytes";
				return false;
			}

			type = header[2];
			uint64_t length = 0;
			for (size_t i = 0; i < 8; ++i) {
				length = (length << 8) | header[3 + i];
			}

			if (length > MAX_FRAME_BYTES) {
				error = "peer declared an oversized message (" + std::to_string(length) + " bytes)";
				return false;
			}

			payload.assign((size_t)length, 0);
			if (length > 0 && !ReadExact(payload.data(), (size_t)length, deadline, error)) {
				return false;
			}

			return true;
		}

	private:
		bool ReadExact(uint8_t* data, const size_t length, const TimePoint deadline, std::string& error)
		{
			size_t offset = 0;
			while (offset < length) {
				asio::error_code ec;
				const size_t available = m_socket.available(ec);
				if (ec) {
					error = "P2P socket error: " + ec.message();
					return false;
				}

				if (available == 0) {
					if (std::chrono::steady_clock::now() >= deadline) {
						error = "timed out waiting for the peer";
						return false;
					}
					std::this_thread::sleep_for(std::chrono::milliseconds(5));
					continue;
				}

				const size_t want = (std::min)(available, length - offset);
				const size_t received = m_socket.read_some(asio::buffer(data + offset, want), ec);
				if (ec == asio::error::would_block || ec == asio::error::try_again) {
					continue;
				}
				if (ec == asio::error::eof) {
					error = "peer closed the connection";
					return false;
				}
				if (ec) {
					error = "P2P read failed: " + ec.message();
					return false;
				}
				if (received == 0) {
					error = "peer closed the connection";
					return false;
				}

				offset += received;
			}

			return true;
		}

		asio::ip::tcp::socket m_socket;
		std::string m_localIp;
		uint16_t m_localPort;
	};

	struct StatusInfo
	{
		uint64_t tipHeight = 0;
		uint64_t tipDifficulty = 0;
		uint64_t networkHeight = 0;
		std::string syncStatus;
		std::string userAgent;
	};

	std::vector<uint8_t> BuildGetHeaderProofsBody(const Hash& anchor, const std::vector<uint64_t>& heights)
	{
		Serializer serializer;
		serializer.AppendBigInteger<32>(anchor);
		serializer.Append<uint16_t>((uint16_t)heights.size());
		for (const uint64_t height : heights) {
			serializer.Append<uint64_t>(height);
		}
		return serializer.GetBytes();
	}

	const char* PassFail(const bool ok)
	{
		return ok ? "PASS" : "FAIL";
	}
}

int main(int argc, char* argv[])
{
	std::cout << "=== HEADER_PROOF_HIST live probe (P2P messages 31/32) ===\n";

	Options options;
	std::string error;
	if (!ParseArgs(argc, argv, options, error)) {
		if (!error.empty()) {
			std::cout << "argument error: " << error << "\n";
		}
		PrintUsage(argv[0]);
		return 1;
	}

	const auto failProbe = [](const std::string& reason) {
		std::cout << "ERROR: " << reason << "\n";
		std::cout << "LIVE HEADER-PROOF: FAIL\n";
		return 1;
	};

	try {
		std::cout << "p2p target : " << options.host << ":" << options.p2pPort
			<< " (source " << options.bindAddress << ")\n";
		std::cout << "rest target: http://" << options.host << ":" << options.restPort << "\n\n";

		//
		// [1] REST status: tip height + total difficulty
		//
		HttpResponse statusResponse;
		if (!HttpClient::Get(options.host, options.restPort, "/v1/status", options.timeoutMs, statusResponse, error)) {
			return failProbe("[1] REST /v1/status: " + error);
		}
		if (statusResponse.status != 200) {
			return failProbe("[1] REST /v1/status returned HTTP " + std::to_string(statusResponse.status));
		}

		Json::Value statusJson;
		if (!ParseJson(statusResponse.body, statusJson, error)) {
			return failProbe("[1] REST /v1/status: " + error);
		}

		StatusInfo status;
		status.syncStatus = ReadString(statusJson, "sync_status");
		status.userAgent = ReadString(statusJson, "user_agent");
		if (const Json::Value* network = FindField(statusJson, "network")) {
			(void)ReadUInt64(*network, "height", status.networkHeight, error);
		}

		bool haveTip = false;
		if (const Json::Value* tip = FindField(statusJson, "tip")) {
			const bool heightOk = ReadUInt64(*tip, "height", status.tipHeight, error);
			const bool difficultyOk = ReadUInt64(*tip, "total_difficulty", status.tipDifficulty, error);
			haveTip = heightOk && difficultyOk;
		}
		if (!haveTip) {
			if (const Json::Value* chain = FindField(statusJson, "chain")) {
				const bool heightOk = ReadUInt64(*chain, "height", status.tipHeight, error);
				const bool difficultyOk = ReadUInt64(*chain, "total_difficulty", status.tipDifficulty, error);
				haveTip = heightOk && difficultyOk;
			}
		}
		if (!haveTip) {
			return failProbe("[1] REST /v1/status: no tip height/total_difficulty in the reply");
		}

		std::cout << "[1] REST /v1/status\n"
			<< "    user_agent      : " << status.userAgent << "\n"
			<< "    sync_status     : " << status.syncStatus << "\n"
			<< "    tip.height      : " << status.tipHeight << "\n"
			<< "    tip.difficulty  : " << status.tipDifficulty << "\n"
			<< "    network.height  : " << status.networkHeight << "\n";

		if (status.tipHeight < 4) {
			return failProbe("[1] tip height is too low");
		}

		uint64_t anchorHeight = 0;
		if (options.hasAnchorHeight) {
			anchorHeight = options.anchorHeight;
			if (anchorHeight < 4 || anchorHeight >= status.tipHeight) {
				return failProbe("[1] --anchor-height must be in [4, tip.height)");
			}
		} else {
			if (status.tipHeight < options.anchorLag + 4) {
				return failProbe("[1] tip height is too low for the requested anchor lag");
			}
			anchorHeight = status.tipHeight - options.anchorLag;
		}

		//
		// [2] REST anchor header
		//
		HttpResponse headerResponse;
		if (!HttpClient::Get(
				options.host,
				options.restPort,
				"/v1/headers/" + std::to_string(anchorHeight),
				options.timeoutMs,
				headerResponse,
				error)) {
			return failProbe("[2] REST /v1/headers/" + std::to_string(anchorHeight) + ": " + error);
		}
		if (headerResponse.status != 200) {
			return failProbe("[2] REST /v1/headers/" + std::to_string(anchorHeight) +
				" returned HTTP " + std::to_string(headerResponse.status));
		}

		Json::Value anchorJson;
		if (!ParseJson(headerResponse.body, anchorJson, error)) {
			return failProbe("[2] REST anchor header: " + error);
		}

		BlockHeaderPtr pAnchor;
		if (!BuildBlockHeader(anchorJson, pAnchor, error)) {
			return failProbe("[2] REST anchor header: " + error);
		}

		const std::string restAnchorHash = ReadString(anchorJson, "hash");
		if (pAnchor->GetHeight() != anchorHeight) {
			return failProbe("[2] REST anchor header height mismatch");
		}
		if (pAnchor->GetHash().ToHex() != restAnchorHash) {
			return failProbe(
				"[2] locally computed anchor hash " + pAnchor->GetHash().ToHex() +
				" differs from the REST 'hash' field " + restAnchorHash +
				" (PoW cycle parse mismatch)");
		}

		const Hash& anchorHash = pAnchor->GetHash();
		const uint64_t expectedMmrSize = LeafIndex::At(anchorHeight).GetPosition();

		std::cout << "\n[2] REST anchor header at height " << anchorHeight << "\n"
			<< "    hash            : " << anchorHash.ToHex() << "\n"
			<< "    prev_root       : " << pAnchor->GetPreviousRoot().ToHex() << "\n"
			<< "    version         : " << pAnchor->GetVersion() << "\n"
			<< "    total_difficulty: " << pAnchor->GetTotalDifficulty() << "\n"
			<< "    expected mmr_size (LeafIndex::At(height).GetPosition()): " << expectedMmrSize << "\n";

		//
		// [3] P2P handshake (Hand -> Shake)
		//
		asio::io_context ioContext;
		P2PClient client(ioContext);

		if (!client.Connect(options.bindAddress, options.host, options.p2pPort, error)) {
			return failProbe("[3] P2P connect: " + error);
		}

		const Hash genesisHash = Genesis::MAINNET_GENESIS.GetHash();
		const uint32_t localCapabilities = ProbeCapabilities();
		const uint64_t localNonce =
			((uint64_t)std::chrono::high_resolution_clock::now().time_since_epoch().count()) ^
			((uint64_t)(uintptr_t)&ioContext);

		{
			Serializer body;
			body.Append<uint32_t>(P2P::PROTOCOL_VERSION);
			body.Append<uint32_t>(localCapabilities);
			body.Append<uint64_t>(localNonce);
			body.Append<uint64_t>(status.tipDifficulty);

			const IPAddress bindIp = IPAddress::Parse(client.GetLocalAddress());
			const IPAddress peerIp = IPAddress::Parse(options.host);
			SocketAddress(bindIp, client.GetLocalPort()).Serialize(body);
			SocketAddress(peerIp, options.p2pPort).Serialize(body);

			body.AppendVarStr(P2P::USER_AGENT);
			body.AppendBigInteger<32>(genesisHash);

			if (!client.Send(MessageTypes::Hand, body.GetBytes(), error)) {
				return failProbe("[3] sending Hand(1): " + error);
			}
		}

		std::cout << "\n[3] P2P handshake with " << options.host << ":" << options.p2pPort << "\n"
			<< "    sent Hand(1): version=" << P2P::PROTOCOL_VERSION
			<< " caps=" << HexMask(localCapabilities) << " [" << CapabilityNames(localCapabilities) << "]"
			<< " ua=\"" << P2P::USER_AGENT << "\""
			<< " genesis=" << ShortHash(genesisHash) << "\n";

		uint8_t replyType = 0;
		std::vector<uint8_t> replyPayload;
		if (!client.Receive(DeadlineAfter(options.timeoutMs), replyType, replyPayload, error)) {
			std::cout << "    Hand sent, but no reply: " << error << "\n";
			std::cout << "    hint: the node may be restarting, may be at its inbound limit, or may\n"
				<< "          already have an active peer from " << options.bindAddress
				<< " ('Already connected'); retry with --bind 127.0.0.2\n";
			return failProbe("[3] P2P handshake: no Shake reply");
		}

		if (replyType == MessageTypes::Error || replyType == MessageTypes::BanReasonMsg) {
			return failProbe(
				std::string("[3] node replied to Hand with ") + MessageTypeName(replyType) +
				" (payload " + std::to_string(replyPayload.size()) + " bytes)");
		}
		if (replyType != MessageTypes::Shake) {
			return failProbe(
				std::string("[3] expected Shake(2), received ") + MessageTypeName(replyType) +
				" (" + std::to_string(replyType) + ")");
		}

		ByteBuffer shakeBuffer(replyPayload);
		ShakeMessage shake = ShakeMessage::Deserialize(shakeBuffer);
		const uint32_t shakeCapabilities = (uint32_t)shake.GetCapabilities().GetCapability();
		const bool genesisOk = shake.GetHash() == genesisHash;
		const bool proofCapabilityOk = shake.GetCapabilities().HasCapability(Capabilities::HEADER_PROOF_HIST);

		std::cout << "    got Shake(2): version=" << shake.GetVersion()
			<< " caps=" << HexMask(shakeCapabilities) << " [" << CapabilityNames(shakeCapabilities) << "]\n"
			<< "    user_agent      : " << shake.GetUserAgent() << "\n"
			<< "    total_difficulty: " << shake.GetTotalDifficulty() << "\n"
			<< "    genesis match   : " << PassFail(genesisOk)
			<< " (" << shake.GetHash().ToHex() << ")\n"
			<< "    HEADER_PROOF_HIST (0x100): " << PassFail(proofCapabilityOk) << "\n";

		if (!genesisOk) {
			return failProbe("[3] Shake genesis hash does not match the mainnet genesis block");
		}
		if (!proofCapabilityOk) {
			return failProbe("[3] the node does not advertise HEADER_PROOF_HIST (0x100)");
		}

		//
		// [4] GetHeaderProofs(31)
		//
		std::vector<uint64_t> heights;
		heights.push_back(anchorHeight - 3);
		heights.push_back(anchorHeight - 2);
		heights.push_back(anchorHeight - 1);
		if (options.descending) {
			std::reverse(heights.begin(), heights.end());
		}

		if (!client.Send(
				MessageTypes::GetHeaderProofs,
				BuildGetHeaderProofsBody(anchorHash, heights),
				error)) {
			return failProbe("[4] sending GetHeaderProofs(31): " + error);
		}

		std::cout << "\n[4] sent GetHeaderProofs(31): anchor=" << anchorHash.ToHex()
			<< " heights={";
		for (size_t i = 0; i < heights.size(); ++i) {
			std::cout << (i == 0 ? "" : ",") << heights[i];
		}
		std::cout << "}\n";

		//
		// [5] HeaderProofs(32)
		//
		const TimePoint proofDeadline = DeadlineAfter(options.timeoutMs);
		std::unique_ptr<HeaderProofsMessage> pProofs;
		for (;;) {
			if (!client.Receive(proofDeadline, replyType, replyPayload, error)) {
				std::cout << "    no HeaderProofs(32): " << error << "\n";
				if (options.descending) {
					std::cout << "    note: the server contract (HeaderProof::BuildResponse) rejects\n"
						<< "          heights that are not strictly increasing, so a descending\n"
						<< "          request is ignored without a reply and without a ban\n";
				} else {
					std::cout << "    hint: a silent ignore (no Error/BanReason) means the server's\n"
						<< "          HeaderProof::BuildResponse returned nullptr. The node log\n"
						<< "          (debug level) names the failing check, e.g.\n"
						<< "          'Header proofs unavailable: ...'. Known issue in this build:\n"
						<< "          HeaderProof::VerifyProof rejects valid proofs when the header-MMR\n"
						<< "          prefix has more than one peak, so only anchors whose\n"
						<< "          2*h - popcount(h) is a perfect MMR size (2^k - 1) are served\n"
						<< "          (e.g. --anchor-height 2097152 or 1048576).\n";
				}
				return failProbe("[5] HeaderProofs(32) not received");
			}

			if (replyType == MessageTypes::HeaderProofs) {
				break;
			}

			if (replyType == MessageTypes::Error) {
				return failProbe("[5] node replied with Error(0) instead of HeaderProofs(32)");
			}
			if (replyType == MessageTypes::BanReasonMsg) {
				return failProbe("[5] node replied with BanReason(18) instead of HeaderProofs(32)");
			}

			std::cout << "    (ignoring unrelated " << MessageTypeName(replyType) << ")\n";
		}

		try {
			ByteBuffer proofsBuffer(replyPayload);
			pProofs = std::make_unique<HeaderProofsMessage>(HeaderProofsMessage::Deserialize(proofsBuffer));
		} catch (const std::exception& e) {
			return failProbe(std::string("[5] HeaderProofs(32) deserialization failed: ") + e.what());
		}

		const uint64_t mmrSize = pProofs->GetMmrSize();
		const bool anchorEchoOk = pProofs->GetAnchor() == anchorHash;
		const bool mmrSizeOk = mmrSize == expectedMmrSize;
		const bool mmrSizeValid = HeaderProof::IsValidHistoricalMmrSize(mmrSize);

		std::cout << "\n[5] got HeaderProofs(32): " << replyPayload.size() << " body bytes\n"
			<< "    anchor echo     : " << PassFail(anchorEchoOk) << "\n"
			<< "    mmr_size        : " << mmrSize << " (expected " << expectedMmrSize << ") "
			<< PassFail(mmrSizeOk) << "\n"
			<< "    mmr_size valid  : " << PassFail(mmrSizeValid) << "\n"
			<< "    items           : " << pProofs->GetItems().size() << " (requested " << heights.size() << ")\n";

		bool ok = anchorEchoOk && mmrSizeOk && mmrSizeValid;

		//
		// [6] Per-item membership checks
		//
		std::cout << "\n[6] item verification against anchor.prev_root\n";

		const std::vector<HeaderProofsMessage::Item>& items = pProofs->GetItems();
		bool itemsOk = items.size() == heights.size();
		uint64_t previousHeight = 0;
		bool havePrevious = false;

		for (size_t i = 0; i < items.size(); ++i) {
			const HeaderProofsMessage::Item& item = items[i];
			const uint64_t height = item.header.GetHeight();
			const uint64_t position = LeafIndex::At(height).GetPosition();
			const bool heightMatches = i < heights.size() && height == heights[i];
			const bool pathLengthOk = item.path.size() <= P2P::MAX_HEADER_PROOF_PATH;
			const bool increasing = !havePrevious || height > previousHeight;

			bool rootOk = false;
			std::string verifyError;
			try {
				const Hash leafHash = HeaderProof::ComputeLeafHash(item.header, position);
				rootOk = HeaderProof::VerifyProof(
					pAnchor->GetPreviousRoot(), mmrSize, position, leafHash, item.path);
				rootOk = rootOk && HeaderProof::VerifyHeaderProofItem(
					pAnchor->GetPreviousRoot(), mmrSize, height, item.header, item.path);
			} catch (const std::exception& e) {
				verifyError = e.what();
			}

			const bool itemOk = heightMatches && pathLengthOk && increasing && rootOk;
			itemsOk = itemsOk && itemOk;

			std::cout << "    item[" << i << "] height=" << height
				<< " pos=" << position
				<< " path_len=" << item.path.size()
				<< " requested=" << (i < heights.size() ? std::to_string(heights[i]) : "n/a")
				<< " height_match=" << PassFail(heightMatches)
				<< " root=" << PassFail(rootOk);
			if (!verifyError.empty()) {
				std::cout << " error=\"" << verifyError << "\"";
			}
			std::cout << "\n";

			previousHeight = height;
			havePrevious = true;
		}

		ok = ok && itemsOk;

		//
		// [7] Feature verifier
		//
		bool membershipsOk = false;
		try {
			membershipsOk = HeaderProof::VerifyMemberships(*pAnchor, *pProofs);
		} catch (const std::exception& e) {
			std::cout << "    VerifyMemberships threw: " << e.what() << "\n";
		}

		std::cout << "\n[7] HeaderProof::VerifyMemberships: " << PassFail(membershipsOk) << "\n";
		ok = ok && membershipsOk;

		//
		// [8] Optional: bind header fields via PoW (VerifyHeaderProofsWithPoW)
		//
		std::cout << "\n[8] PoW binding (VerifyHeaderProofsWithPoW): ";
		if (!options.powCheck) {
			std::cout << "SKIPPED (--no-pow-check)\n";
		} else if (anchorHeight < 6) {
			std::cout << "SKIPPED (anchor height too low)\n";
		} else {
			// The verifier needs h-1 and h-2 for every sampled height; the lowest
			// sample is anchor-3, so the trusted tail must reach anchor-5.
			std::vector<BlockHeader> trustedTail;
			bool tailOk = true;
			std::string tailError;
			for (uint64_t height = anchorHeight - 5; height <= anchorHeight; ++height) {
				if (height == anchorHeight) {
					trustedTail.push_back(*pAnchor);
					continue;
				}

				HttpResponse tailResponse;
				if (!HttpClient::Get(
						options.host,
						options.restPort,
						"/v1/headers/" + std::to_string(height),
						options.timeoutMs,
						tailResponse,
						tailError) ||
					tailResponse.status != 200) {
					tailOk = false;
					break;
				}

				Json::Value tailJson;
				if (!ParseJson(tailResponse.body, tailJson, tailError)) {
					tailOk = false;
					break;
				}

				BlockHeaderPtr pTail;
				if (!BuildBlockHeader(tailJson, pTail, tailError)) {
					tailOk = false;
					break;
				}

				trustedTail.push_back(*pTail);
			}

			if (!tailOk) {
				std::cout << "SKIPPED (could not build the trusted tail: " << tailError << ")\n";
			} else {
				std::string powError;
				bool powOk = false;
				try {
					powOk = HeaderProof::VerifyHeaderProofsWithPoW(*pAnchor, *pProofs, trustedTail, &powError);
				} catch (const std::exception& e) {
					powError = e.what();
				}

				// PoWValidator/Consensus read Global::GetConfig(); this probe
				// deliberately runs without a node Context (no Tor, no data dirs),
				// so a "global context" failure is a probe limitation, not a node
				// verdict.
				if (!powOk && powError.find("global context") != std::string::npos) {
					std::cout << "SKIPPED (needs a live node Context in-process: " << powError << ")\n";
				} else {
					std::cout << PassFail(powOk) << " (advisory, not part of the membership verdict)\n";
					if (!powOk && !powError.empty()) {
						std::cout << "    reason: " << powError << "\n";
					}
				}
			}
		}

		//
		// Verdict
		//
		std::cout << "\n--- summary ---\n"
			<< "caps 0x100 (HEADER_PROOF_HIST) : " << PassFail(proofCapabilityOk) << "\n"
			<< "sha... genesis match           : " << PassFail(genesisOk) << "\n"
			<< "anchor height/hash             : " << anchorHeight << " / " << anchorHash.ToHex() << "\n"
			<< "mmr_size                       : " << mmrSize << " (expected " << expectedMmrSize << ")\n"
			<< "items verified                 : " << items.size() << "\n"
			<< "membership                     : " << PassFail(membershipsOk) << "\n"
			<< "LIVE HEADER-PROOF: " << PassFail(ok) << "\n";

		return ok ? 0 : 1;
	} catch (const std::exception& e) {
		return failProbe(std::string("unhandled exception: ") + e.what());
	} catch (...) {
		return failProbe("unhandled non-standard exception");
	}
}
