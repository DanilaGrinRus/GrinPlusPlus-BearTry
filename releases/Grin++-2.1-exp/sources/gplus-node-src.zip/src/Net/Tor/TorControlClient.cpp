#include "TorControlClient.h"

#include <Common/Util/ThreadUtil.h>
#include <Common/Util/HexUtil.h>
#include <Core/Global.h>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <regex>

namespace
{
	// Hard cap on reply lines for a single command. Tor never sends more than a
	// few lines; the limit turns a broken/desynchronized stream into an error
	// instead of an unbounded read loop.
	constexpr size_t MAX_REPLY_LINES = 1024;

	bool IsFinalOk(const std::string& line)
	{
		return line == "250 OK";
	}
}

TorControlClient::UPtr TorControlClient::Connect(const uint16_t control_port, const std::string& password)
{
	auto pClient = std::make_unique<TorControlClient>();
	bool connected = false;
	auto timeout = std::chrono::system_clock::now() + TOR_STARTUP_TIMEOUT;
	while (Global::IsRunning() && !connected && std::chrono::system_clock::now() < timeout) {
		// Open control socket
		connected = pClient->Connect(SocketAddress{ "127.0.0.1", control_port });

		ThreadUtil::SleepFor(std::chrono::milliseconds(1000));
	}

	if (!connected) {
		LOG_WARNING_F("Failed to connect to control_port {}", control_port);
		return nullptr;
	}

	// Authenticate
	std::string auth_command = StringUtil::Format("AUTHENTICATE \"{}\"\n", password);

	try {
		pClient->Invoke(auth_command);

		for (int i = 0; i < 30; i++) {
			ThreadUtil::SleepFor(std::chrono::seconds(4));
			if (pClient->IsBootstrapped()) {
				return pClient;
			}
		}
	}
	catch (std::exception&) {
		return nullptr;
	}

	return nullptr;
}

TorControlClient::UPtr TorControlClient::ConnectCookie(const uint16_t control_port, const std::filesystem::path& cookieFile)
{
	auto pClient = std::make_unique<TorControlClient>();
	bool connected = false;
	auto timeout = std::chrono::system_clock::now() + TOR_STARTUP_TIMEOUT;
	while (Global::IsRunning() && !connected && std::chrono::system_clock::now() < timeout) {
		connected = pClient->Connect(SocketAddress{ "127.0.0.1", control_port });
		if (!connected) {
			ThreadUtil::SleepFor(std::chrono::milliseconds(500));
		}
	}

	if (!connected) {
		LOG_WARNING_F("Failed to connect to control_port {} (cookie auth)", control_port);
		return nullptr;
	}

	// Tor writes the 32-byte cookie once the control port is up. Wait briefly.
	std::vector<uint8_t> cookie;
	auto cookieDeadline = std::chrono::system_clock::now() + TOR_STARTUP_TIMEOUT;
	while (Global::IsRunning() && std::chrono::system_clock::now() < cookieDeadline) {
		std::ifstream cookieStream(cookieFile, std::ios::binary);
		if (cookieStream) {
			cookie.assign(std::istreambuf_iterator<char>(cookieStream), std::istreambuf_iterator<char>());
			if (cookie.size() == 32) {
				break;
			}
		}
		ThreadUtil::SleepFor(std::chrono::milliseconds(250));
	}

	if (cookie.size() != 32) {
		LOG_WARNING_F("Tor cookie file not ready: {}", cookieFile.u8string());
		return nullptr;
	}

	try {
		const std::string authCommand = "AUTHENTICATE " + HexUtil::ConvertToHex(cookie) + "\n";
		pClient->Invoke(authCommand);
		LOG_INFO("Tor control cookie authentication succeeded");

		for (int i = 0; i < 30; i++) {
			ThreadUtil::SleepFor(std::chrono::seconds(1));
			if (pClient->IsBootstrapped()) {
				return pClient;
			}
		}
	}
	catch (std::exception&) {
		return nullptr;
	}

	return nullptr;
}

bool TorControlClient::IsBootstrapped()
{
	const std::regex base_regex(".*PROGRESS=([0-9]+).*");
	std::smatch base_match;

	std::vector<std::string> response = Invoke("GETINFO status/bootstrap-phase\n");
	for (std::string& line : response) {
		if (std::regex_match(line, base_match, base_regex)) {
			// The first sub_match is the whole string; the next
			// sub_match is the first parenthesized expression.
			if (base_match.size() == 2) {
				int percentage = std::stoi(base_match[1].str());
				if (percentage == 100) {
					return true;
				}
			}
		}
	}

	return false;
}

std::vector<std::string> TorControlClient::Invoke(const std::string& request)
{
	assert(!request.empty());

	// One control socket is shared by the Tor init thread and the API threads.
	// Serialize the whole command/reply transaction: a half-consumed reply would
	// desynchronize every following command on this socket.
	std::lock_guard<std::mutex> transactionLock(m_transactionMutex);

	std::vector<std::string> response;

	try {
		Write(request.back() == '\n' ? request : request + "\n", TOR_CONTROL_TIMEOUT);

		size_t lineCount = 0;
		bool done = false;
		while (!done) {
			const std::string line = ReadLine(TOR_CONTROL_TIMEOUT).Trim();
			if (++lineCount > MAX_REPLY_LINES) {
				throw TOR_EXCEPTION("Tor control reply exceeded the line limit");
			}

			if (IsFinalOk(line)) {
				done = true;
				break;
			}

			if (line.size() < 4) {
				throw TOR_EXCEPTION("Malformed Tor control reply: " + line);
			}

			// Asynchronous event lines ("650 ...") can be interleaved with a
			// reply; they are not part of the command result.
			if (line[0] == '6') {
				LOG_DEBUG_F("Tor control event while awaiting a reply: {}", line);
				continue;
			}

			if (line.compare(0, 3, "250") == 0) {
				const char separator = line[3];
				if (separator == '+') {
					// "250+<keyword>=" opens a data block that is terminated by a
					// single "." line and followed by the "250 OK" terminator.
					response.push_back(line);
					while (true) {
						const std::string dataLine = ReadLine(TOR_CONTROL_TIMEOUT).Trim();
						if (++lineCount > MAX_REPLY_LINES) {
							throw TOR_EXCEPTION("Tor control data block exceeded the line limit");
						}

						if (dataLine == ".") {
							break;
						}

						response.push_back(dataLine);
					}

					continue;
				}

				if (separator == '-') {
					// Intermediate success line, e.g. "250-ServiceID=...".
					response.push_back(line);
					continue;
				}

				// "250 <text>" is the final line of a successful reply.
				response.push_back(line);
				done = true;
				break;
			}

			// Surface the actual Tor error so desynchronization and rejected
			// commands are visible in the log instead of a generic message.
			throw TOR_EXCEPTION("Failed with error: " + line);
		}
	}
	catch (TorException&) {
		throw;
	}
	catch (std::exception& e) {
		throw TOR_EXCEPTION(e.what());
	}

	return response;
}

bool TorControlClient::Connect(const SocketAddress& address)
{
	try {
		Client::Connect(address, TOR_CONTROL_TIMEOUT);
		return true;
	}
	catch (asio::system_error& e) {
		LOG_ERROR_F("Connection to {} failed with error {}.", address, e.what());
		return false;
	}
}
