#include <Net/Tor/TorProcess.h>
#include <Net/Tor/TorException.h>
#include <Net/Tor/TorAddressParser.h>
#include <Net/Tor/TorConnection.h>
#include <Common/Util/ThreadUtil.h>
#include <Common/Logger.h>
#include <Crypto/ED25519.h>
#include <Core/Global.h>
#include <cstdlib>
#include <memory>

#include <Common/Util/FileUtil.h>

#include "TorControl.h"

namespace
{
	// How long the public AddListener waits for a usable Tor control connection
	// before it falls back to "queue now, publish later".
	constexpr auto LISTENER_PUBLISH_TIMEOUT = std::chrono::seconds(15);
	constexpr auto LISTENER_LOCK_POLL_INTERVAL = std::chrono::milliseconds(100);
}

TorProcess::~TorProcess()
{
	m_shutdown = true;
	LOG_INFO("Terminating tor process");
	ThreadUtil::Join(m_initThread);
	LOG_INFO("Terminated tor process");
}

TorProcess::Ptr TorProcess::Initialize(const fs::path& torDataPath, const uint16_t socksPort, const uint16_t controlPort) noexcept
{
	auto pProcess =  std::shared_ptr<TorProcess>(new TorProcess(torDataPath, socksPort, controlPort));

	pProcess->m_initThread = std::thread(TorProcess::Thread_Initialize, pProcess.get());
	return pProcess;
}

void TorProcess::Thread_Initialize(TorProcess* pProcess)
{
	while (!pProcess->m_shutdown)
	{
		try
		{
			// Steady state: a control connection exists -> heartbeat it, then
			// publish whatever was queued while Tor was unavailable.
			{
				std::unique_lock<std::timed_mutex> lock(pProcess->m_mutex);
				if (pProcess->m_pControl != nullptr) {
					if (!pProcess->m_pControl->CheckHeartbeat()) {
						LOG_WARNING("Tor heartbeat failed after retries. Killing process and reinitializing.");
						pProcess->m_pControl.reset();
						lock.unlock();
						ThreadUtil::SleepFor(std::chrono::seconds(1));
						continue;
					}

					pProcess->PublishPendingServices(lock);

					lock.unlock();
					ThreadUtil::SleepFor(std::chrono::seconds(60));
					continue;
				}
			}

			if(!IsTorPresent()) {
				ThreadUtil::SleepFor(std::chrono::seconds(10));
				continue;
			}

			if (!IsPortOpen(pProcess->m_socksPort) || !IsPortOpen(pProcess->m_controlPort)) {
				LOG_WARNING("Tor ports unavailable; waiting for them to become available.");
				ThreadUtil::SleepFor(std::chrono::seconds(5));
				continue;
			}

			LOG_INFO("Initializing Tor");

			// Starting Tor and waiting for bootstrap takes tens of seconds. Do it
			// without m_mutex: otherwise wallet AddListener calls are blocked
			// behind an initializing control connection for the whole bootstrap.
			std::shared_ptr<TorControl> pControl = TorControl::Create(
				pProcess->m_socksPort,
				pProcess->m_controlPort,
				pProcess->m_torDataPath
			);
			LOG_INFO_F("Tor Initialized: {}", pControl != nullptr);

			std::unique_lock<std::timed_mutex> lock(pProcess->m_mutex);
			pProcess->m_pControl = pControl;

			if (pControl != nullptr) {
				// Re-publish the services that were live before a Tor restart.
				auto addresses_to_add = pProcess->m_activeServices;
				for (auto iter = addresses_to_add.cbegin(); iter != addresses_to_add.cend(); iter++)
				{
					auto pTorAddress = pProcess->AddListener(lock, iter->second.first, iter->second.second);
					if (pTorAddress != nullptr) {
						LOG_INFO_F("Re-added onion address {}", iter->first);
					} else {
						LOG_INFO_F("Failed to re-add onion address {}", iter->first);
						pProcess->m_servicesToAdd.push_back(iter->second);
					}
				}

				// Publish the services that were requested while Tor was starting.
				pProcess->PublishPendingServices(lock);
			}

			lock.unlock();
			ThreadUtil::SleepFor(std::chrono::seconds(10));
		}
		catch (const std::exception& e)
		{
			LOG_ERROR_F("Exception thrown: {}", e);
			ThreadUtil::SleepFor(std::chrono::seconds(30));
		}
	}
}

fs::path TorProcess::GetTorCommand()
{
#ifdef _WIN32
	return fs::current_path() / "tor" / "tor.exe";
#else
	return fs::current_path() / "tor" / "tor";
#endif
}

bool TorProcess::IsTorPresent()
{
    return FileUtil::Exists(GetTorCommand());
}

bool TorProcess::IsPortOpen(const uint16_t port)
{
    asio::io_context svc;
    asio::ip::tcp::acceptor a(svc);

    std::error_code ec;
    a.open(asio::ip::tcp::v4(), ec) || a.bind(asio::ip::tcp::endpoint(asio::ip::make_address("127.0.0.1"), port), ec);

    return ec != asio::error::address_in_use;
}

bool TorProcess::RetryInit()
{
	std::unique_lock<std::timed_mutex> lock(m_mutex);
	m_pControl = nullptr;
	return m_pControl == nullptr;
}

TorAddress TorProcess::AddListener(const ed25519_secret_key_t& secretKey, const uint16_t portNumber)
{
	const TorAddress derivedAddress = TorAddressParser::FromPubKey(ED25519::CalculatePubKey(secretKey));

	// No tor binary in this deployment: keep the legacy contract. The address is
	// derived from the key and the service is published once Tor appears.
	if (!IsTorPresent()) {
		EnqueueListener(secretKey, portNumber);
		LOG_INFO_F("Tor is not present; onion {} queued for publication", derivedAddress.ToString());
		return derivedAddress;
	}

	// Tor is installed: wait (bounded) for a usable control connection and publish
	// the service *before* the address is handed to the caller. Otherwise the
	// wallet advertises an onion address that nobody can reach.
	const auto deadline = std::chrono::steady_clock::now() + LISTENER_PUBLISH_TIMEOUT;
	while (std::chrono::steady_clock::now() < deadline && Global::IsRunning() && !m_shutdown)
	{
		std::unique_lock<std::timed_mutex> lock(m_mutex, std::defer_lock);
		if (!lock.try_lock_for(LISTENER_LOCK_POLL_INTERVAL)) {
			// The Tor init thread is busy starting/stopping Tor; retry.
			continue;
		}

		if (m_pControl != nullptr) {
			std::unique_ptr<TorAddress> pPublished = AddListener(lock, secretKey, portNumber);
			lock.unlock();

			if (pPublished != nullptr) {
				return *pPublished;
			}

			throw TOR_EXCEPTION("Failed to publish onion service " + derivedAddress.ToString());
		}

		lock.unlock();
		ThreadUtil::SleepFor(LISTENER_LOCK_POLL_INTERVAL);
	}

	// The control connection did not become usable in time (Tor is still
	// bootstrapping or broken). Legacy behaviour: queue the service and return the
	// derived address; the init thread publishes it once control is available.
	EnqueueListener(secretKey, portNumber);
	LOG_WARNING_F(
		"Tor control not ready after {} s; onion {} queued for later publication",
		static_cast<int>(std::chrono::duration_cast<std::chrono::seconds>(LISTENER_PUBLISH_TIMEOUT).count()),
		derivedAddress.ToString()
	);
	return derivedAddress;
}

void TorProcess::EnqueueListener(const ed25519_secret_key_t& secretKey, const uint16_t portNumber)
{
	// ConcurrentQueue is internally synchronized: the init thread may pop while
	// an API thread pushes.
	m_servicesToAdd.push_back(std::make_pair(secretKey, portNumber));
}

void TorProcess::PublishPendingServices(const std::unique_lock<std::timed_mutex>& lock)
{
	const size_t size = m_servicesToAdd.size();
	if (size == 0) {
		return;
	}

	std::vector<std::pair<ed25519_secret_key_t, uint16_t>> services_to_add =
		m_servicesToAdd.copy_front(size);
	m_servicesToAdd.pop_front(size);

	for (const auto& service : services_to_add) {
		auto pAdded = AddListener(lock, service.first, service.second);
		if (pAdded == nullptr) {
			// Failed - Add it back to retry on the next cycle.
			m_servicesToAdd.push_back(service);
		}
	}
}

std::unique_ptr<TorAddress> TorProcess::AddListener(const std::unique_lock<std::timed_mutex>&, const ed25519_secret_key_t& secretKey, const uint16_t portNumber)
{
	try {
		if (m_pControl == nullptr) {
			return nullptr;
		}

		const std::string address = m_pControl->AddOnion(secretKey, 80, portNumber);
		if (address.empty()) {
			LOG_ERROR("ADD_ONION returned an empty service id");
			return nullptr;
		}

		std::optional<TorAddress> torAddress = TorAddressParser::Parse(address);
		if (!torAddress.has_value()) {
			LOG_ERROR_F("Failed to parse listener address: {}", address);
			return nullptr;
		}

		m_activeServices.insert({ address, { secretKey, portNumber } });
		LOG_INFO_F("Published onion service {} (port 80 -> {})", address, portNumber);
		return std::make_unique<TorAddress>(torAddress.value());
	}
	catch (const std::exception& e) {
		LOG_ERROR_F("Failed to add listener: {}", e.what());
	}

	return nullptr;
}

bool TorProcess::RemoveListener(const TorAddress& torAddress)
{
	// F-20: logout/destructor paths must not block forever if the Tor init thread
	// holds m_mutex (e.g. Tor is absent or still bootstrapping).
	std::unique_lock<std::timed_mutex> lock(m_mutex, std::defer_lock);
	if (!lock.try_lock_for(std::chrono::seconds(2))) {
		LOG_WARNING("Timed out waiting for Tor process lock during RemoveListener");
		return false;
	}

	try
	{
		auto iter = m_activeServices.find(torAddress.ToString());
		if (iter != m_activeServices.end()) {
			m_activeServices.erase(iter);
		}

		if (m_pControl != nullptr) {
			return m_pControl->DelOnion(torAddress);
		}
	}
	catch (const TorException& e)
	{
		LOG_ERROR_F("Failed to remove listener: {}", e.what());
	}

	return false;
}

std::shared_ptr<ITorConnection> TorProcess::Connect(const TorAddress& address)
{
	std::unique_lock<std::timed_mutex> lock(m_mutex);

	try
	{
		return std::make_shared<TorConnection>(address, SocketAddress{ "127.0.0.1", m_socksPort });
	}
	catch (std::exception& e)
	{
		LOG_ERROR_F("Failed to create TorConnection: {}", e.what());
		return nullptr;
	}
}