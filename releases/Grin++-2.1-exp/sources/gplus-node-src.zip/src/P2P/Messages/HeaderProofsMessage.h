#pragma once

#include "Message.h"

#include <Core/Exceptions/DeserializationException.h>
#include <Core/Models/BlockHeader.h>
#include <Crypto/Models/Hash.h>
#include <P2P/Common.h>

#include <cstdint>
#include <utility>
#include <vector>

// HEADER_PROOF_HIST response: type 32 (Grin PR #3963).
// Body: anchor Hash, u64 mmr_size, u16 count, count items of
// { BlockHeader, u8 path_len, path_len * Hash }.
//
// The parser enforces wire bounds only: count <= P2P::MAX_HEADER_PROOF_ITEMS,
// path_len <= P2P::MAX_HEADER_PROOF_PATH and the whole body within the
// documented 168170-byte maximum. Semantic validation (anchor echo, mmr_size,
// ordering, membership) is done by HeaderProof::VerifyMemberships.
class HeaderProofsMessage : public IMessage
{
public:
	struct Item
	{
		Item(BlockHeader header, std::vector<Hash> path)
			: header(std::move(header)), path(std::move(path))
		{
		}

		BlockHeader header;
		std::vector<Hash> path;
	};

	HeaderProofsMessage(Hash anchor, const uint64_t mmrSize, std::vector<Item> items)
		: m_anchor(std::move(anchor)), m_mmrSize(mmrSize), m_items(std::move(items))
	{
	}

	IMessagePtr Clone() const final { return IMessagePtr(new HeaderProofsMessage(*this)); }

	MessageTypes::EMessageType GetMessageType() const final
	{
		return MessageTypes::HeaderProofs;
	}

	const Hash& GetAnchor() const noexcept { return m_anchor; }
	uint64_t GetMmrSize() const noexcept { return m_mmrSize; }
	const std::vector<Item>& GetItems() const noexcept { return m_items; }

	static HeaderProofsMessage Deserialize(ByteBuffer& byteBuffer)
	{
		const size_t remainingBefore = byteBuffer.GetRemainingSize();

		const Hash anchor = byteBuffer.ReadBigInteger<32>();
		const uint64_t mmrSize = byteBuffer.ReadU64();
		const uint16_t count = byteBuffer.ReadU16();
		if (count > P2P::MAX_HEADER_PROOF_ITEMS) {
			throw DESERIALIZATION_EXCEPTION_F(
				"HeaderProofs declares {} items, limit is {}",
				count,
				P2P::MAX_HEADER_PROOF_ITEMS);
		}

		std::vector<Item> items;
		items.reserve(count);
		for (uint16_t i = 0; i < count; ++i) {
			BlockHeader header = BlockHeader::Deserialize(byteBuffer);
			const uint8_t pathLen = byteBuffer.ReadU8();
			if (pathLen > P2P::MAX_HEADER_PROOF_PATH) {
				throw DESERIALIZATION_EXCEPTION_F(
					"HeaderProofs item declares path length {}, limit is {}",
					pathLen,
					P2P::MAX_HEADER_PROOF_PATH);
			}

			std::vector<Hash> path;
			path.reserve(pathLen);
			for (uint8_t j = 0; j < pathLen; ++j) {
				path.push_back(byteBuffer.ReadBigInteger<32>());
			}

			items.emplace_back(std::move(header), std::move(path));
		}

		const size_t consumed = remainingBefore - byteBuffer.GetRemainingSize();
		if (consumed > MessageTypes::GetMaximumSize(MessageTypes::HeaderProofs)) {
			throw DESERIALIZATION_EXCEPTION_F(
				"HeaderProofs body is {} bytes, limit is {}",
				consumed,
				MessageTypes::GetMaximumSize(MessageTypes::HeaderProofs));
		}

		return HeaderProofsMessage(anchor, mmrSize, std::move(items));
	}

protected:
	void SerializeBody(Serializer& serializer) const final
	{
		serializer.AppendBigInteger<32>(m_anchor);
		serializer.Append<uint64_t>(m_mmrSize);
		serializer.Append<uint16_t>((uint16_t)m_items.size());
		for (const Item& item : m_items) {
			item.header.Serialize(serializer);
			serializer.Append<uint8_t>((uint8_t)item.path.size());
			for (const Hash& hash : item.path) {
				serializer.AppendBigInteger<32>(hash);
			}
		}
	}

private:
	Hash m_anchor;
	uint64_t m_mmrSize;
	std::vector<Item> m_items;
};
