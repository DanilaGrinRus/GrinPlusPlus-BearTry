#pragma once

#include "Message.h"

#include <Crypto/Models/Hash.h>
#include <Core/Exceptions/DeserializationException.h>
#include <P2P/Common.h>

#include <cstdint>
#include <vector>

// HEADER_PROOF_HIST request: type 31 (Grin PR #3963).
// Body: anchor Hash, u16 count, count u64 heights.
//
// The parser enforces wire bounds only: count must not exceed
// P2P::MAX_HEADER_PROOF_ITEMS and the heights array must be fully present.
// Semantic checks (non-empty, strictly increasing, below the anchor) are done
// by the server handler, which ignores an invalid request without banning.
class GetHeaderProofsMessage : public IMessage
{
public:
	GetHeaderProofsMessage(Hash anchor, std::vector<uint64_t> heights)
		: m_anchor(std::move(anchor)), m_heights(std::move(heights))
	{
	}

	IMessagePtr Clone() const final { return IMessagePtr(new GetHeaderProofsMessage(*this)); }

	MessageTypes::EMessageType GetMessageType() const final
	{
		return MessageTypes::GetHeaderProofs;
	}

	const Hash& GetAnchor() const noexcept { return m_anchor; }
	const std::vector<uint64_t>& GetHeights() const noexcept { return m_heights; }

	static GetHeaderProofsMessage Deserialize(ByteBuffer& byteBuffer)
	{
		const Hash anchor = byteBuffer.ReadBigInteger<32>();
		const uint16_t count = byteBuffer.ReadU16();
		if (count > P2P::MAX_HEADER_PROOF_ITEMS) {
			throw DESERIALIZATION_EXCEPTION_F(
				"GetHeaderProofs declares {} heights, limit is {}",
				count,
				P2P::MAX_HEADER_PROOF_ITEMS);
		}

		std::vector<uint64_t> heights;
		heights.reserve(count);
		for (uint16_t i = 0; i < count; ++i) {
			heights.push_back(byteBuffer.ReadU64());
		}

		return GetHeaderProofsMessage(anchor, std::move(heights));
	}

protected:
	void SerializeBody(Serializer& serializer) const final
	{
		serializer.AppendBigInteger<32>(m_anchor);
		serializer.Append<uint16_t>((uint16_t)m_heights.size());
		for (const uint64_t height : m_heights) {
			serializer.Append<uint64_t>(height);
		}
	}

private:
	Hash m_anchor;
	std::vector<uint64_t> m_heights;
};
