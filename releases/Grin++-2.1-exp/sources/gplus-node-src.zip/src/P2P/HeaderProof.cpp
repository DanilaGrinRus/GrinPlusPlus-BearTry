#include <P2P/HeaderProof.h>

#include "Messages/GetHeaderProofsMessage.h"
#include "Messages/HeaderProofsMessage.h"

#include <BlockChain/BlockChain.h>
#include <Common/Logger.h>
#include <Common/Util/StringUtil.h>
#include <Consensus.h>
#include <PMMR/HeaderMMR.h>
#include <PoW/PoWValidator.h>
#include "../PMMR/Common/MMRHashUtil.h"
#include "../PMMR/Common/MMRUtil.h"

#include <algorithm>
#include <exception>
#include <unordered_map>
#include <utility>

namespace
{
	bool Fail(std::string* pError, const std::string& message)
	{
		if (pError != nullptr) {
			*pError = message;
		}

		return false;
	}
}

Hash HeaderProof::ComputeRoot(const HashReader& readHash, const uint64_t mmrSize)
{
	if (mmrSize == 0) {
		return ZERO_HASH;
	}

	const std::vector<uint64_t> peaks = MMRUtil::GetPeakIndices(mmrSize);
	if (peaks.empty()) {
		throw std::runtime_error("MMR size does not describe a complete MMR");
	}

	Hash hash = ZERO_HASH;
	for (auto iter = peaks.crbegin(); iter != peaks.crend(); ++iter) {
		const std::optional<Hash> pPeakHash = readHash(*iter);
		if (!pPeakHash.has_value()) {
			throw std::runtime_error(StringUtil::Format("MMR peak hash at position {} is missing", *iter));
		}

		if (*pPeakHash == ZERO_HASH) {
			continue;
		}

		if (hash == ZERO_HASH) {
			hash = *pPeakHash;
		} else {
			hash = MMRHashUtil::HashParentWithIndex(*pPeakHash, hash, mmrSize);
		}
	}

	return hash;
}

std::vector<Hash> HeaderProof::BuildProof(
	const HashReader& readHash,
	const uint64_t mmrSize,
	const uint64_t position)
{
	if (!IsValidHistoricalMmrSize(mmrSize)) {
		throw std::runtime_error(StringUtil::Format("invalid historical MMR size {}", mmrSize));
	}

	if (position >= mmrSize) {
		throw std::runtime_error(StringUtil::Format("position {} outside MMR size {}", position, mmrSize));
	}

	if (!MMRUtil::IsLeaf(position)) {
		throw std::runtime_error(StringUtil::Format("position {} is not an MMR leaf", position));
	}

	if (!readHash(position).has_value()) {
		throw std::runtime_error(StringUtil::Format("no MMR element at position {}", position));
	}

	const std::vector<uint64_t> peaks = MMRUtil::GetPeakIndices(mmrSize);
	if (peaks.empty()) {
		throw std::runtime_error("MMR size does not describe a complete MMR");
	}

	const std::vector<std::pair<uint64_t, uint64_t>> familyBranch =
		MMRUtil::FamilyBranch(position, mmrSize);

	std::vector<Hash> path;
	path.reserve(familyBranch.size() + peaks.size());
	for (const std::pair<uint64_t, uint64_t>& branch : familyBranch) {
		const std::optional<Hash> pSiblingHash = readHash(branch.second);
		if (!pSiblingHash.has_value()) {
			throw std::runtime_error(
				StringUtil::Format("MMR sibling hash at position {} is missing", branch.second));
		}

		path.push_back(*pSiblingHash);
	}

	const uint64_t peakPosition = familyBranch.empty() ? position : familyBranch.back().first;

	// Bag the peaks to the right of our peak (highest first), exactly as
	// PMMR::bag_the_rhs in grin 5.5.2.
	std::optional<Hash> pRhs;
	for (auto iter = peaks.crbegin(); iter != peaks.crend(); ++iter) {
		if (*iter <= peakPosition) {
			break;
		}

		const std::optional<Hash> pPeakHash = readHash(*iter);
		if (!pPeakHash.has_value()) {
			throw std::runtime_error(StringUtil::Format("MMR peak hash at position {} is missing", *iter));
		}

		if (!pRhs.has_value()) {
			pRhs = *pPeakHash;
		} else {
			pRhs = MMRHashUtil::HashParentWithIndex(*pPeakHash, *pRhs, mmrSize);
		}
	}

	if (pRhs.has_value()) {
		path.push_back(*pRhs);
	}

	// Then the peaks to the left, highest first.
	for (auto iter = peaks.crbegin(); iter != peaks.crend(); ++iter) {
		if (*iter >= peakPosition) {
			continue;
		}

		const std::optional<Hash> pPeakHash = readHash(*iter);
		if (!pPeakHash.has_value()) {
			throw std::runtime_error(StringUtil::Format("MMR peak hash at position {} is missing", *iter));
		}

		path.push_back(*pPeakHash);
	}

	if (path.size() > P2P::MAX_HEADER_PROOF_PATH) {
		throw std::runtime_error(
			StringUtil::Format("MMR proof path length {} exceeds {}", path.size(), P2P::MAX_HEADER_PROOF_PATH));
	}

	return path;
}

bool HeaderProof::VerifyProof(
	const Hash& root,
	const uint64_t mmrSize,
	const uint64_t position,
	const Hash& leafHash,
	const std::vector<Hash>& path)
{
	if (mmrSize == 0 || position >= mmrSize || !MMRUtil::IsLeaf(position)) {
		return false;
	}

	if (path.size() > P2P::MAX_HEADER_PROOF_PATH) {
		return false;
	}

	const std::vector<uint64_t> peaks = MMRUtil::GetPeakIndices(mmrSize);
	if (peaks.empty()) {
		return false;
	}

	// Port of MerkleProof::verify_consume (grin core/src/core/merkle_proof.rs).
	Hash nodeHash = leafHash;
	uint64_t nodePosition = position;
	for (const Hash& sibling : path) {
		const std::pair<uint64_t, uint64_t> family = MMRUtil::Family(nodePosition);
		const uint64_t parentPosition = family.first;
		const bool isPeak = std::binary_search(peaks.cbegin(), peaks.cend(), nodePosition);

		Hash parentHash = ZERO_HASH;
		if (isPeak) {
			// Peak bagging (bag_the_rhs / left-peak fold) always hashes with the
			// historical MMR size as the virtual parent index, exactly like
			// ComputeRoot and BuildProof. Using the real parentPosition here
			// (a live MMR position) breaks every multi-peak anchor.
			if (nodePosition == peaks.back()) {
				parentHash = MMRHashUtil::HashParentWithIndex(sibling, nodeHash, mmrSize);
			} else {
				parentHash = MMRHashUtil::HashParentWithIndex(nodeHash, sibling, mmrSize);
			}
		} else if (parentPosition >= mmrSize) {
			parentHash = MMRHashUtil::HashParentWithIndex(sibling, nodeHash, mmrSize);
		} else if (MMRUtil::IsLeftSibling(family.second)) {
			parentHash = MMRHashUtil::HashParentWithIndex(sibling, nodeHash, parentPosition);
		} else {
			parentHash = MMRHashUtil::HashParentWithIndex(nodeHash, sibling, parentPosition);
		}

		nodeHash = parentHash;
		nodePosition = parentPosition;
	}

	return nodeHash == root;
}

Hash HeaderProof::ComputeLeafHash(const BlockHeader& header, const uint64_t position)
{
	Serializer serializer;
	header.GetProofOfWork().SerializeCycle(serializer);
	return MMRHashUtil::HashLeafWithIndex(serializer.GetBytes(), position);
}

bool HeaderProof::IsValidHistoricalMmrSize(const uint64_t mmrSize)
{
	if (mmrSize == 0) {
		return false;
	}

	return mmrSize == MMRUtil::InsertionToPmmrIndex(MMRUtil::GetNumLeaves(mmrSize));
}

bool HeaderProof::VerifyHeaderProofItem(
	const Hash& root,
	const uint64_t mmrSize,
	const uint64_t height,
	const BlockHeader& header,
	const std::vector<Hash>& path)
{
	if (header.GetHeight() != height) {
		return false;
	}

	if (path.size() > P2P::MAX_HEADER_PROOF_PATH) {
		return false;
	}

	const uint64_t position = MMRUtil::InsertionToPmmrIndex(height);
	if (position >= mmrSize) {
		return false;
	}

	if (!IsValidHistoricalMmrSize(mmrSize)) {
		return false;
	}

	return VerifyProof(root, mmrSize, position, ComputeLeafHash(header, position), path);
}

bool HeaderProof::VerifyMemberships(
	const BlockHeader& anchor,
	const HeaderProofsMessage& proofs)
{
	if (proofs.GetAnchor() != anchor.GetHash()) {
		return false;
	}

	const uint64_t expectedMmrSize = MMRUtil::InsertionToPmmrIndex(anchor.GetHeight());
	if (proofs.GetMmrSize() != expectedMmrSize) {
		return false;
	}

	const std::vector<HeaderProofsMessage::Item>& items = proofs.GetItems();
	if (items.empty() || items.size() > P2P::MAX_HEADER_PROOF_ITEMS) {
		return false;
	}

	bool hasPrevious = false;
	uint64_t previousHeight = 0;
	for (const HeaderProofsMessage::Item& item : items) {
		const uint64_t height = item.header.GetHeight();
		if (height >= anchor.GetHeight()) {
			return false;
		}

		if (hasPrevious && height <= previousHeight) {
			return false;
		}

		previousHeight = height;
		hasPrevious = true;

		if (!VerifyHeaderProofItem(
				anchor.GetPreviousRoot(),
				proofs.GetMmrSize(),
				height,
				item.header,
				item.path)) {
			return false;
		}
	}

	return true;
}

bool HeaderProof::VerifyHeaderProofsWithPoW(
	const BlockHeader& anchor,
	const HeaderProofsMessage& proofs,
	const std::vector<BlockHeader>& trustedTail,
	std::string* pError)
{
	if (!VerifyMemberships(anchor, proofs)) {
		return Fail(pError, "header proof membership verification failed");
	}

	std::unordered_map<uint64_t, const BlockHeader*> headersByHeight;
	headersByHeight.reserve(trustedTail.size() + proofs.GetItems().size());
	for (const BlockHeader& header : trustedTail) {
		headersByHeight[header.GetHeight()] = &header;
	}
	for (const HeaderProofsMessage::Item& item : proofs.GetItems()) {
		headersByHeight[item.header.GetHeight()] = &item.header;
	}

	for (const HeaderProofsMessage::Item& item : proofs.GetItems()) {
		const BlockHeader& header = item.header;
		const uint64_t height = header.GetHeight();

		if (header.GetVersion() != Consensus::GetHeaderVersion(height)) {
			return Fail(pError, StringUtil::Format(
				"invalid header version {} at height {}", header.GetVersion(), height));
		}

		if (header.GetVersion() < 5) {
			return Fail(pError, StringUtil::Format(
				"pre-HF4 header at height {} (version {}): WTEMA triple verification is not applied; "
				"use an explicit trusted checkpoint/window policy for pre-HF4 headers",
				height,
				header.GetVersion()));
		}

		if (height < 2) {
			return Fail(pError, StringUtil::Format(
				"sampled height {} cannot provide h-2/h-1 headers", height));
		}

		const auto iterPrev1 = headersByHeight.find(height - 1);
		if (iterPrev1 == headersByHeight.end()) {
			return Fail(pError, StringUtil::Format(
				"sampled height {} requires header h-1={} in the proof set or trusted tail",
				height,
				height - 1));
		}

		const auto iterPrev2 = headersByHeight.find(height - 2);
		if (iterPrev2 == headersByHeight.end()) {
			return Fail(pError, StringUtil::Format(
				"sampled height {} requires header h-2={} in the proof set or trusted tail",
				height,
				height - 2));
		}

		const BlockHeader& previous = *iterPrev1->second;
		const BlockHeader& previousPrevious = *iterPrev2->second;

		// Post-HF4 is primary Cuckoo only.
		if (header.IsSecondaryPoW()) {
			return Fail(pError, StringUtil::Format(
				"post-HF4 header at height {} carries secondary PoW", height));
		}

		if (!header.IsPrimaryPoW()) {
			return Fail(pError, StringUtil::Format(
				"invalid PoW edge bits {} at height {}", header.GetEdgeBits(), height));
		}

		if (!PoWValidator::VerifyProofOfWork(header)) {
			return Fail(pError, StringUtil::Format(
				"header PoW does not verify at height {} (fields are not bound by the membership proof)",
				height));
		}

		if (header.GetTimestamp() <= previous.GetTimestamp() ||
			previous.GetTimestamp() <= previousPrevious.GetTimestamp()) {
			return Fail(pError, StringUtil::Format(
				"header timestamps are not strictly increasing for the h-2/h-1/h triple below height {}",
				height));
		}

		if (header.GetTotalDifficulty() <= previous.GetTotalDifficulty() ||
			previous.GetTotalDifficulty() <= previousPrevious.GetTotalDifficulty()) {
			return Fail(pError, StringUtil::Format(
				"header total_difficulty is not strictly increasing for the h-2/h-1/h triple below height {}",
				height));
		}

		if (header.GetPreviousHash() != previous.GetHash()) {
			return Fail(pError, StringUtil::Format(
				"header prev_hash linkage mismatch at height {} (h-1)", height));
		}

		if (previous.GetPreviousHash() != previousPrevious.GetHash()) {
			return Fail(pError, StringUtil::Format(
				"header prev_hash linkage mismatch at height {} (h-2 -> h-1)", height));
		}

		if (header.GetTimestamp() >= anchor.GetTimestamp()) {
			return Fail(pError, StringUtil::Format(
				"header timestamp at height {} is not before the anchor timestamp", height));
		}

		if (header.GetTotalDifficulty() > anchor.GetTotalDifficulty()) {
			return Fail(pError, StringUtil::Format(
				"header total_difficulty at height {} exceeds the anchor total_difficulty", height));
		}

		// The chain derives the network difficulty of h-1 from h-2, then requires
		// h.total_difficulty - (h-1).total_difficulty to equal the WTEMA target
		// for h exactly.
		const uint64_t lastBlockTime =
			(uint64_t)(previous.GetTimestamp() - previousPrevious.GetTimestamp());
		const uint64_t lastDifficulty = previous.GetTotalDifficulty() - previousPrevious.GetTotalDifficulty();
		const uint64_t denominator =
			Consensus::WTEMA_HALF_LIFE - Consensus::BLOCK_TIME_SEC + lastBlockTime;
		if (denominator == 0) {
			return Fail(pError, StringUtil::Format(
				"invalid WTEMA time delta at height {}", height));
		}

		const uint64_t nextDifficulty = lastDifficulty * Consensus::WTEMA_HALF_LIFE / denominator;
		const uint64_t expectedDifficulty =
			(std::max)(Consensus::min_wtema_graph_weight(), nextDifficulty);
		const uint64_t claimedDifficulty =
			header.GetTotalDifficulty() - previous.GetTotalDifficulty();
		if (claimedDifficulty != expectedDifficulty) {
			return Fail(pError, StringUtil::Format(
				"claimed difficulty {} at height {} does not match expected WTEMA difficulty {}",
				claimedDifficulty,
				height,
				expectedDifficulty));
		}

		if (PoWValidator::GetMaximumDifficulty(header) < claimedDifficulty) {
			return Fail(pError, StringUtil::Format(
				"proof of work difficulty too low at height {}", height));
		}
	}

	return true;
}

std::shared_ptr<HeaderProofsMessage> HeaderProof::BuildResponse(
	const IBlockChain& blockChain,
	const GetHeaderProofsMessage& request)
{
	const std::shared_ptr<Locked<IHeaderMMR>> pHeaderMMR = blockChain.GetHeaderMMRShared();
	if (pHeaderMMR == nullptr) {
		return nullptr;
	}

	const BlockHeaderPtr pAnchor = blockChain.GetBlockHeaderByHash(request.GetAnchor());
	if (pAnchor == nullptr) {
		return nullptr;
	}

	const uint64_t anchorHeight = pAnchor->GetHeight();
	if (anchorHeight == 0) {
		return nullptr;
	}

	// The anchor must be the candidate header at its height (our main chain).
	const BlockHeaderPtr pMainChainHeader =
		blockChain.GetBlockHeaderByHeight(anchorHeight, EChainType::CANDIDATE);
	if (pMainChainHeader == nullptr || pMainChainHeader->GetHash() != pAnchor->GetHash()) {
		return nullptr;
	}

	const std::vector<uint64_t>& heights = request.GetHeights();
	if (heights.empty() || heights.size() > P2P::MAX_HEADER_PROOF_ITEMS) {
		return nullptr;
	}

	for (size_t i = 0; i < heights.size(); ++i) {
		if (heights[i] >= anchorHeight) {
			return nullptr;
		}

		if (i > 0 && heights[i] <= heights[i - 1]) {
			return nullptr;
		}
	}

	std::vector<BlockHeader> headers;
	headers.reserve(heights.size());
	for (const uint64_t height : heights) {
		const BlockHeaderPtr pHeader = blockChain.GetBlockHeaderByHeight(height, EChainType::CANDIDATE);
		if (pHeader == nullptr) {
			return nullptr;
		}

		headers.push_back(*pHeader);
	}

	// The historical size is insertion_to_pmmr_index(anchor.height): the size of
	// the MMR prefix the anchor committed to in prev_root. Never the tip size.
	const uint64_t mmrSize = MMRUtil::InsertionToPmmrIndex(anchorHeight);

	Reader<IHeaderMMR> headerReader;
	uint64_t nodeCount = 0;
	HashReader readHash;

	try {
		headerReader = pHeaderMMR->Read();
		nodeCount = headerReader->GetNodeCount();
		if (nodeCount < mmrSize) {
			return nullptr;
		}

		readHash = [&headerReader, nodeCount](const uint64_t position) -> std::optional<Hash> {
			if (position >= nodeCount) {
				return std::nullopt;
			}

			try {
				const std::unique_ptr<Hash> pHash = headerReader->GetHashAt(Index::At(position));
				if (pHash == nullptr) {
					return std::nullopt;
				}

				return *pHash;
			} catch (const std::exception&) {
				return std::nullopt;
			}
		};

		const Hash root = ComputeRoot(readHash, mmrSize);
		if (root != pAnchor->GetPreviousRoot()) {
			LOG_DEBUG_F(
				"Header proofs unavailable: historical MMR root at height {} does not match anchor prev_root",
				anchorHeight);
			return nullptr;
		}

		std::vector<HeaderProofsMessage::Item> items;
		items.reserve(heights.size());
		for (size_t i = 0; i < heights.size(); ++i) {
			const uint64_t position = MMRUtil::InsertionToPmmrIndex(heights[i]);
			const std::vector<Hash> path = BuildProof(readHash, mmrSize, position);

			// Fail closed: never send a proof we cannot verify ourselves.
			if (!VerifyProof(root, mmrSize, position, ComputeLeafHash(headers[i], position), path)) {
				LOG_DEBUG_F(
					"Header proofs unavailable: proof at height {} does not verify against anchor prev_root",
					heights[i]);
				return nullptr;
			}

			items.emplace_back(headers[i], path);
		}

		return std::make_shared<HeaderProofsMessage>(request.GetAnchor(), mmrSize, std::move(items));
	} catch (const std::exception& e) {
		LOG_DEBUG_F("Header proofs unavailable for anchor height {}: {}", anchorHeight, e.what());
		return nullptr;
	}
}
