#pragma once

#include <Common/Secure.h>
#include <Crypto/Models/SecretKey.h>
#include <Wallet/Models/Slate/Slate.h>
#include <Wallet/Wallet.h>

// Forward Declarations
class Wallet;
class INodeClient;

class FinalizeSlateBuilder
{
public:
	struct FinalizeResult
	{
		Slate slate;
		Transaction transaction;
		uint32_t walletTxId;
		bool alreadyFinalized;
	};

	FinalizeSlateBuilder(const std::shared_ptr<Wallet>& pWallet, const std::shared_ptr<const INodeClient>& pNode)
		: m_pWallet(pWallet), m_pNode(pNode) { }

	FinalizeResult Finalize(
		const Slate& rcvSlate
	) const;

private:
	void AddPartialSignature(
		const SlateContextEntity& context,
		Slate& finalizeSlate,
		const Hash& kernelMessage
	) const;

	std::unique_ptr<Transaction> BuildTransaction(
		Slate& finalizeSlate,
		const Hash& kernelMessage,
		const Commitment& finalExcess
	) const;

	bool VerifyPaymentProofs(
		const WalletTx& walletTx,
		const Slate& finalizeSlate,
		const Commitment& finalExcess
	) const;

	void UpdateDatabase(
		const WalletTx& walletTx,
		const Slate& finalizeSlate,
		const std::string& armored_slatepack
	) const;

	std::shared_ptr<Wallet> m_pWallet;
	std::shared_ptr<const INodeClient> m_pNode;
};