#pragma once

#include <Net/Tor/TorProcess.h>
#include <unordered_map>
#include <optional>
#include <string>
#include <mutex>

// Forward Declarations
class IWalletManager;
class SessionToken;
class KeyChain;

class ForeignController
{
public:
	ForeignController(IWalletManager& walletManager);
	~ForeignController();

	std::pair<uint16_t, std::optional<TorAddress>> StartListener(
		const TorProcess::Ptr& pTorProcess,
		const std::string& username,
		const SessionToken& token,
		const KeyChain& keyChain,
		const int currentAddressIndex
	);
	bool StopListener(const std::string& username);

	// F-03: drops the user's listener regardless of the reference count. Called
	// when the user has no sessions left (logout_all, session TTL expiry, LRU
	// eviction), where every reference is gone by definition. Without this the
	// listener outlives the sessions and keeps wallet.db open, so delete_wallet
	// fails with "User still logged in".
	bool StopAllListeners(const std::string& username);

	bool IsListening(const std::string& username);

private:
	struct Context;

	IWalletManager& m_walletManager;

	mutable std::mutex m_contextsMutex;
	std::unordered_map<std::string, std::unique_ptr<Context>> m_contextsByUsername;
};