#include "SessionManager.h"
#include "ForeignController.h"
#include "Keychain/SeedEncrypter.h"

#include <Common/Logger.h>
#include <Crypto/Hasher.h>
#include <Crypto/CSPRNG.h>
#include <Wallet/Exceptions/SessionTokenException.h>
#include <Wallet/WalletDB/WalletStore.h>
#include <algorithm>
#include <chrono>
#include <exception>
#include <string>
#include <vector>

SessionPolicy::SessionPolicy()
	: SessionPolicy(Limits(), &Clock::now)
{
}

SessionPolicy::SessionPolicy(const Limits& limits, NowFunction now)
	: m_limits(limits), m_now(std::move(now))
{
}

SessionPolicy::EExpiry SessionPolicy::CheckExpiry(
	const TimePoint createdAt,
	const TimePoint lastUsedAt,
	const TimePoint now) const
{
	if (now - createdAt >= m_limits.absoluteTtl) {
		return EExpiry::ABSOLUTE_EXPIRED;
	}

	if (now - lastUsedAt >= m_limits.idleTtl) {
		return EExpiry::IDLE_EXPIRED;
	}

	return EExpiry::VALID;
}

std::optional<uint64_t> SessionPolicy::SelectLruVictim(
	const std::vector<std::pair<uint64_t, TimePoint>>& sessions)
{
	if (sessions.empty()) {
		return std::nullopt;
	}

	auto victim = sessions.cbegin();
	for (auto iter = sessions.cbegin() + 1; iter != sessions.cend(); ++iter) {
		if (iter->second < victim->second ||
			(iter->second == victim->second && iter->first < victim->first)) {
			victim = iter;
		}
	}

	return victim->first;
}

SessionManager::SessionManager(
	const Config& config,
	const std::shared_ptr<const INodeClient>& pNodeClient,
	const std::shared_ptr<IWalletStore>& pWalletDB,
	std::unique_ptr<ForeignController>&& pForeignController)
	: m_config(config),
	m_pNodeClient(pNodeClient),
	m_pWalletDB(pWalletDB),
	m_pForeignController(std::move(pForeignController))
{
	m_nextSessionId = CSPRNG::GenerateRandom(0, UINT64_MAX);
}

SessionManager::~SessionManager()
{
	LOG_INFO("Shutting down session manager");

	// Collect usernames first: StopListener() may join a listener thread which
	// must never block behind m_sessionsMutex.
	std::vector<std::string> usernames;
	{
		std::lock_guard<std::mutex> lock(m_sessionsMutex);
		for (const auto& pair : m_sessionsById) {
			usernames.push_back(pair.second.username);
		}
	}

	for (const std::string& username : usernames) {
		m_pForeignController->StopListener(username);
	}
}

Locked<SessionManager> SessionManager::Create(
	const Config& config,
	const std::shared_ptr<const INodeClient>& pNodeClient,
	const std::shared_ptr<IWalletStore>& pWalletDB,
	IWalletManager& walletManager)
{
	auto pForeignController = std::make_unique<ForeignController>(walletManager);
	auto pSessionManager = std::make_shared<SessionManager>(
		config,
		pNodeClient,
		pWalletDB,
		std::move(pForeignController)
	);
	return Locked<SessionManager>(pSessionManager);
}

void SessionManager::Authenticate(const std::string& username, const SecureString& password) const
{
	std::unique_ptr<EncryptedSeed> pSeed = nullptr;

	try
	{
		pSeed = std::make_unique<EncryptedSeed>(m_pWalletDB->LoadWalletSeed(username));
	}
	catch (std::exception&)
	{
		WALLET_ERROR_F("User '{}' not found.", username);
		throw;
	}

	try
	{
		SecureVector decryptedSeed = SeedEncrypter().DecryptWalletSeed(*pSeed, password);
	}
	catch (std::exception&)
	{
		WALLET_ERROR_F("Invalid password provided for user '{}'", username);
		throw;
	}
}

SecureVector SessionManager::GetSeed(const std::string& username, const SecureString& password) const
{
	std::unique_ptr<EncryptedSeed> pSeed = nullptr;

	try
	{
		pSeed = std::make_unique<EncryptedSeed>(m_pWalletDB->LoadWalletSeed(username));
	}
	catch (std::exception&)
	{
		WALLET_ERROR_F("User '{}' not found.", username);
		throw;
	}

	try
	{
		return SeedEncrypter().DecryptWalletSeed(*pSeed, password);
	}
	catch (std::exception&)
	{
		WALLET_ERROR_F("Invalid password provided for user '{}'", username);
		throw;
	}
}

SessionToken SessionManager::Login(
	const TorProcess::Ptr& pTorProcess,
	const std::string& username,
	const SecureString& password)
{
	WALLET_DEBUG_F("Logging in with username: {}", username);

	// F-13: a failed login must not leave an opened wallet handle behind when
	// this was the first (and only) session of the user.
	const bool hadSessionsBefore = HasAnySessionForUser(username);

	try
	{
		EncryptedSeed seed = m_pWalletDB->LoadWalletSeed(username);

		SecureVector decryptedSeed = SeedEncrypter().DecryptWalletSeed(seed, password);

		WALLET_INFO("Valid password provided. Logging in now.");
		m_pWalletDB->OpenWallet(username, decryptedSeed);
		return Login(pTorProcess, username, decryptedSeed);
	}
	catch (std::exception&)
	{
		WALLET_ERROR("Wallet seed not decrypted. Wrong password?");
		if (!hadSessionsBefore) {
			ReleaseUserResourcesIfUnused(username);
		}
		throw;
	}
}

SessionToken SessionManager::Login(
	const TorProcess::Ptr& pTorProcess,
	const std::string& username,
	const SecureVector& seed)
{
	Hash hash = Hasher::SHA256((const std::vector<unsigned char>&)seed);
	std::vector<unsigned char> checksum(
		hash.GetData().cbegin(),
		hash.GetData().cbegin() + 4
	);
	SecureVector seedWithChecksum = seed;
	seedWithChecksum.insert(seedWithChecksum.end(), checksum.begin(), checksum.end());

	SecureVector tokenKey = CSPRNG::GenerateRandomBytes(seedWithChecksum.size());

	SecureVector encryptedSeedWithCS(seedWithChecksum.size());
	for (size_t i = 0; i < seedWithChecksum.size(); i++)
	{
		encryptedSeedWithCS[i] = seedWithChecksum[i] ^ tokenKey[i];
	}

	const uint64_t sessionId = m_nextSessionId++;
	SessionToken token(sessionId, tokenKey);

	// F-03: keep the per-user session count bounded *before* the new session is
	// registered, so the LRU entry is gone even if the login fails afterwards.
	EvictLruSessionIfAtLimit(username);

	const bool hadSessionsBefore = HasAnySessionForUser(username);

	try
	{
		auto pWalletDB = m_pWalletDB->OpenWallet(username, seed);
		Locked<WalletImpl> walletImpl = WalletImpl::LoadWallet(
			m_config,
			seed,
			m_pNodeClient,
			pWalletDB,
			username
		);

		Locked<Wallet> wallet = std::make_shared<Wallet>(
			pWalletDB,
			token,
			seed,
			username,
			KeyChainPath::FromString("m/0/0"),
			walletImpl.Read()->GetSlatepackAddress()
		);

		KeyChain keyChain = KeyChain::FromSeed(seed);
		int currentAddressIndex = pWalletDB.Read()->GetCurrentAddressIndex(KeyChainPath::FromString("m/0/0"));

		auto listenerInfo = m_pForeignController->StartListener(
			pTorProcess,
			username,
			token,
			keyChain,
			currentAddressIndex
		);
		wallet.Write()->SetListenerPort(listenerInfo.first);
		walletImpl.Write()->SetListenerPort(listenerInfo.first);
		if (listenerInfo.second.has_value()) {
			wallet.Write()->SetTorAddress(listenerInfo.second.value());
			walletImpl.Write()->SetTorAddress(listenerInfo.second.value());
		}

		const SessionPolicy::TimePoint now = m_sessionPolicy.Now();
		{
			std::lock_guard<std::mutex> lock(m_sessionsMutex);
			m_sessionsById.emplace(
				sessionId,
				SessionEntry(
					std::make_shared<LoggedInSession>(
						wallet,
						walletImpl,
						std::move(encryptedSeedWithCS),
						Hasher::SHA256(token.GetTokenKey())),
					username,
					now,
					now
				)
			);
		}

		return token;
	}
	catch (std::exception&)
	{
		// F-13: never keep a half-initialized session or an open wallet handle.
		// The session is not registered yet at any point of failure above.
		if (!hadSessionsBefore) {
			ReleaseUserResourcesIfUnused(username);
		}
		throw;
	}
}

void SessionManager::Logout(const SessionToken& token)
{
	std::string username;
	{
		std::lock_guard<std::mutex> lock(m_sessionsMutex);
		auto iter = m_sessionsById.find(token.GetSessionId());
		if (iter == m_sessionsById.end())
		{
			return;
		}

		if (token.GetTokenKey().size() != iter->second.pSession->m_encryptedSeedWithCS.size() ||
			Hasher::SHA256(token.GetTokenKey()) != iter->second.pSession->m_tokenHash)
		{
			throw SessionTokenException();
		}

		// F-20: use the username tracked next to the session instead of re-locking
		// the session wallet (re-locking it could block logout indefinitely).
		username = iter->second.username;
		m_sessionsById.erase(iter);
	}

	ReleaseUserResourcesIfUnused(username);
}

void SessionManager::LogoutAll(const std::string& username)
{
	std::size_t removed = 0;
	{
		std::lock_guard<std::mutex> lock(m_sessionsMutex);
		for (auto iter = m_sessionsById.begin(); iter != m_sessionsById.end();)
		{
			if (iter->second.username == username)
			{
				iter = m_sessionsById.erase(iter);
				++removed;
			}
			else
			{
				++iter;
			}
		}
	}

	ReleaseUserResourcesIfUnused(username);

	WALLET_INFO_F(
		"LogoutAll removed {} session(s) for user '{}'",
		removed,
		username
	);
}

void SessionManager::LogoutAll(const SessionToken& token)
{
	// Validate the token exactly like Logout()/RequireSession(): an attacker who
	// cannot present a valid token must not be able to drop somebody's sessions.
	std::string username;
	{
		std::lock_guard<std::mutex> lock(m_sessionsMutex);
		auto iter = m_sessionsById.find(token.GetSessionId());
		if (iter == m_sessionsById.end() ||
			token.GetTokenKey().size() != iter->second.pSession->m_encryptedSeedWithCS.size() ||
			Hasher::SHA256(token.GetTokenKey()) != iter->second.pSession->m_tokenHash)
		{
			throw SessionTokenException();
		}

		username = iter->second.username;
	}

	LogoutAll(username);
}

std::shared_ptr<LoggedInSession> SessionManager::RequireSession(const SessionToken& token) const
{
	const SessionPolicy::TimePoint now = m_sessionPolicy.Now();

	std::shared_ptr<LoggedInSession> pSession;
	std::string username;
	SessionPolicy::EExpiry expiry = SessionPolicy::EExpiry::VALID;

	{
		std::lock_guard<std::mutex> lock(m_sessionsMutex);
		auto iter = m_sessionsById.find(token.GetSessionId());
		if (iter == m_sessionsById.end() ||
			token.GetTokenKey().size() != iter->second.pSession->m_encryptedSeedWithCS.size() ||
			Hasher::SHA256(token.GetTokenKey()) != iter->second.pSession->m_tokenHash)
		{
			throw SessionTokenException();
		}

		expiry = m_sessionPolicy.CheckExpiry(
			iter->second.createdAt,
			iter->second.lastUsedAt,
			now
		);

		if (expiry == SessionPolicy::EExpiry::VALID)
		{
			iter->second.lastUsedAt = now;
			pSession = iter->second.pSession;
		}
		else
		{
			username = iter->second.username;
			m_sessionsById.erase(iter);
		}
	}

	if (expiry != SessionPolicy::EExpiry::VALID)
	{
		WALLET_INFO_F(
			"Session {} of user '{}' expired ({}); session removed",
			token.GetSessionId(),
			username,
			expiry == SessionPolicy::EExpiry::IDLE_EXPIRED ? "idle timeout" : "absolute lifetime"
		);
		ReleaseUserResourcesIfUnused(username);
		throw SessionTokenException();
	}

	return pSession;
}

bool SessionManager::HasAnySessionForUser(const std::string& username) const
{
	std::lock_guard<std::mutex> lock(m_sessionsMutex);
	for (const auto& pair : m_sessionsById)
	{
		if (pair.second.username == username) {
			return true;
		}
	}

	return false;
}

void SessionManager::ReleaseUserResourcesIfUnused(const std::string& username) const
{
	if (HasAnySessionForUser(username)) {
		return;
	}

	try
	{
		// F-03: no session of the user remains at this point, so drop the
		// listener wholesale. Each Login() took a listener reference, therefore
		// a single StopListener() left the listener (and wallet.db) alive and
		// delete_wallet reported "User still logged in".
		m_pForeignController->StopAllListeners(username);
		m_pWalletDB->CloseWallet(username);
	}
	catch (const std::exception& e)
	{
		WALLET_WARNING_F(
			"Failed to release wallet resources for user '{}': {}",
			username,
			e.what()
		);
	}
}

void SessionManager::RemoveSession(const uint64_t sessionId)
{
	std::string username;
	{
		std::lock_guard<std::mutex> lock(m_sessionsMutex);
		auto iter = m_sessionsById.find(sessionId);
		if (iter == m_sessionsById.end()) {
			return;
		}

		username = iter->second.username;
		m_sessionsById.erase(iter);
	}

	ReleaseUserResourcesIfUnused(username);
}

void SessionManager::EvictLruSessionIfAtLimit(const std::string& username)
{
	const std::size_t maxSessions = m_sessionPolicy.GetLimits().maxSessionsPerUser;
	if (maxSessions == 0) {
		return;
	}

	std::vector<std::pair<uint64_t, SessionPolicy::TimePoint>> candidates;
	{
		std::lock_guard<std::mutex> lock(m_sessionsMutex);
		for (const auto& pair : m_sessionsById)
		{
			if (pair.second.username == username) {
				candidates.emplace_back(pair.first, pair.second.lastUsedAt);
			}
		}
	}

	if (candidates.size() < maxSessions) {
		return;
	}

	const std::optional<uint64_t> victim = SessionPolicy::SelectLruVictim(candidates);
	if (!victim.has_value()) {
		return;
	}

	WALLET_INFO_F(
		"Session limit ({}) reached for user '{}'; evicting LRU session {}",
		maxSessions,
		username,
		victim.value()
	);
	RemoveSession(victim.value());
}

SecureVector SessionManager::GetSeed(const SessionToken& token) const
{
	const std::shared_ptr<LoggedInSession> pSession = RequireSession(token);
	const SecureVector& encryptedSeedWithCS = pSession->m_encryptedSeedWithCS;
	SecureVector seedWithCS(encryptedSeedWithCS.size());
	for (size_t i = 0; i < seedWithCS.size(); ++i) {
		seedWithCS[i] = encryptedSeedWithCS[i] ^ token.GetTokenKey()[i];
	}
	if (seedWithCS.size() < 4) {
		throw SessionTokenException();
	}
	SecureVector seed(seedWithCS.begin(), seedWithCS.end() - 4);
	const auto hash = Hasher::SHA256(seed.data(), seed.size());
	if (!std::equal(seedWithCS.end() - 4, seedWithCS.end(), hash.cbegin())) {
		throw SessionTokenException();
	}
	return seed;
}

Locked<Wallet> SessionManager::GetWallet(const SessionToken& token) const
{
	return RequireSession(token)->m_wallet;
}

Locked<WalletImpl> SessionManager::GetWalletImpl(const SessionToken& token) const
{
	return RequireSession(token)->m_walletImpl;
}
