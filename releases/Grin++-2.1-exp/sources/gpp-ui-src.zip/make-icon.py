from PIL import Image, ImageDraw, ImageFont
import os
out = r"C:\DHW\Gplus\work\gpp-ui-tauri-20261110\src-tauri\icons"
os.makedirs(out, exist_ok=True)
size = 256
img = Image.new("RGBA", (size, size), (20, 22, 26, 255))
d = ImageDraw.Draw(img)
d.ellipse((12, 12, size-12, size-12), fill=(245, 166, 35, 255))
try:
    font = ImageFont.truetype("C:/Windows/Fonts/segoeuib.ttf", 130)
except Exception:
    font = ImageFont.load_default()
text = "G++"
bbox = d.textbbox((0, 0), text, font=font)
w, h = bbox[2]-bbox[0], bbox[3]-bbox[1]
d.text(((size-w)/2 - bbox[0], (size-h)/2 - bbox[1]), text, font=font, fill=(23, 24, 28, 255))
img.save(os.path.join(out, "icon.ico"), sizes=[(16,16),(32,32),(48,48),(64,64),(128,128),(256,256)])
img.save(os.path.join(out, "icon.png"))
print("ok", os.path.getsize(os.path.join(out, "icon.ico")))
