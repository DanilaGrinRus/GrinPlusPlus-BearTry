// Ядро приложения: пути, окружение ноды, HTTP-клиенты и wallet-RPC.
//
// Модуль намеренно не зависит от Tauri: команды в lib.rs — тонкие обёртки, а тот же
// код можно прогнать против живой ноды из отдельного бинаря (src/bin/live_cycle.rs).

use serde::Serialize;
use serde_json::{json, Value};
use std::ffi::OsString;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Child, Command};
use std::time::Duration;

pub const DEFAULT_NET: &str = "FLOONET";
pub const DEFAULT_REST_PORT: u16 = 13413; // подтверждено live: /v1/health отвечает на 13413 при пустом конфиге
pub const DEFAULT_WALLET_PORT: u16 = 3421;
pub const MOAT_BASE: &str = "https://bridges.torproject.org";
const MAX_BRIDGE_LEN: usize = 512;

#[derive(Clone, Serialize)]
pub struct AppPaths {
    pub node_exe: String,
    pub data_dir: String,
    pub net_dir: String,
    pub rest_port: u16,
    pub wallet_port: u16,
}

pub fn default_node_exe() -> PathBuf {
    if let Ok(p) = std::env::var("GRINPP_NODE_EXE") {
        let p = PathBuf::from(p);
        if p.is_file() {
            return p;
        }
    }

    if let Ok(exe) = std::env::current_exe() {
        if let Some(dir) = exe.parent() {
            // Поставка: нода лежит рядом с приложением или в подкаталоге node/.
            for candidate in [dir.join("GrinNode.exe"), dir.join("node").join("GrinNode.exe")] {
                if candidate.is_file() {
                    return candidate;
                }
            }
        }
    }

    // Путь разработчика: используется только пока каталог существует (в поставку не входит).
    let dev = PathBuf::from(
        r"C:\DHW\Gplus\work\wallet-node-20261110\src\bin\Release\Release\GrinNode.exe",
    );
    if dev.is_file() {
        return dev;
    }

    // Нода не найдена: возвращаем имя, чтобы ошибка запуска была понятной.
    PathBuf::from("GrinNode.exe")
}

/// Данные всегда лежат рядом с нодой: <папка ноды>\.GrinPP (portable-правило).
pub fn data_root_for(node_exe: &Path) -> PathBuf {
    node_exe
        .parent()
        .map(Path::to_path_buf)
        .unwrap_or_else(|| PathBuf::from("."))
}

pub fn read_json(path: &Path) -> Option<Value> {
    let text = fs::read_to_string(path).ok()?;
    serde_json::from_str(&text).ok()
}

pub fn net_dir(data_root: &Path, net: &str) -> PathBuf {
    data_root.join(".GrinPP").join(net)
}

pub fn config_path(data_root: &Path, net: &str) -> PathBuf {
    net_dir(data_root, net).join("server_config.json")
}

pub fn port_from(config: &Option<Value>, path: &[&str], fallback: u16) -> u16 {
    fn lookup(config: &Option<Value>, path: &[&str]) -> Option<u16> {
        let mut cur = config.as_ref()?;
        for key in path {
            cur = cur.get(*key)?;
        }
        cur.as_u64().map(|v| v as u16)
    }

    lookup(config, path).unwrap_or(fallback)
}

pub fn resolve_paths(net: &str) -> AppPaths {
    let node_exe = default_node_exe();
    let data_root = data_root_for(&node_exe);
    let config = read_json(&config_path(&data_root, net));

    AppPaths {
        node_exe: node_exe.to_string_lossy().to_string(),
        data_dir: data_root.to_string_lossy().to_string(),
        net_dir: net_dir(&data_root, net).to_string_lossy().to_string(),
        rest_port: port_from(&config, &["SERVER", "REST_API_PORT"], DEFAULT_REST_PORT),
        wallet_port: port_from(
        &config,
        &["SERVER", "OWNER_API_PORT"],
        port_from(&config, &["WALLET", "API_PORT"], DEFAULT_WALLET_PORT),
    ),
    }
}

/// Окружение дочернего процесса: home переводится на папку ноды.
///
/// На Windows `FileUtil::GetHomeDirectory()` читает `HOMEDRIVE` + `HOMEPATH`,
/// а не `USERPROFILE`/`HOME`; без этих двух переменных нода уходит в реальный профиль.
pub fn child_env(data_root: &Path) -> Vec<(OsString, OsString)> {
    let full = data_root.to_string_lossy().to_string();
    let (drive, path) = if full.len() >= 2 && full.as_bytes()[1] == b':' {
        (full[..2].to_string(), full[2..].to_string())
    } else {
        ("C:".to_string(), full.clone())
    };

    let env: Vec<(OsString, OsString)> = vec![
        ("HOMEDRIVE".into(), drive.into()),
        ("HOMEPATH".into(), path.into()),
        ("USERPROFILE".into(), full.clone().into()),
        ("HOME".into(), full.clone().into()),
        (
            "APPDATA".into(),
            data_root.join("AppData").join("Roaming").into_os_string(),
        ),
        (
            "LOCALAPPDATA".into(),
            data_root.join("AppData").join("Local").into_os_string(),
        ),
        ("TMP".into(), data_root.join("tmp").into_os_string()),
        ("TEMP".into(), data_root.join("tmp").into_os_string()),
    ];
    env.into_iter().filter(|(_, v)| !v.is_empty()).collect()
}

pub async fn http_get(url: &str) -> Result<Value, String> {
    let resp = reqwest::Client::new()
        .get(url)
        .timeout(Duration::from_secs(5))
        .send()
        .await
        .map_err(|e| format!("request failed: {e}"))?;
    let status = resp.status();
    let text = resp.text().await.map_err(|e| e.to_string())?;
    if !status.is_success() {
        return Err(format!("HTTP {status}: {text}"));
    }
    serde_json::from_str(&text).map_err(|e| format!("bad json: {e}"))
}

pub fn start_node(floonet: bool, no_wallet: bool) -> Result<Child, String> {
    let paths = resolve_paths(if floonet { "FLOONET" } else { "MAINNET" });
    let node_exe = PathBuf::from(&paths.node_exe);
    let data_root = PathBuf::from(&paths.data_dir);

    fs::create_dir_all(data_root.join("tmp")).map_err(|e| format!("cannot create tmp dir: {e}"))?;

    let mut cmd = Command::new(&node_exe);
    if floonet {
        cmd.arg("--floonet");
    }
    if no_wallet {
        cmd.arg("--no-wallet");
    }
    cmd.arg("--headless");
    cmd.current_dir(&data_root);
    for (k, v) in child_env(&data_root) {
        cmd.env(k, v);
    }

    cmd.spawn().map_err(|e| format!("spawn failed: {e}"))
}

pub async fn node_health(net: &str) -> Result<Value, String> {
    let paths = resolve_paths(net);
    http_get(&format!("http://127.0.0.1:{}/v1/health", paths.rest_port)).await
}

pub async fn node_status(net: &str) -> Result<Value, String> {
    let paths = resolve_paths(net);
    http_get(&format!("http://127.0.0.1:{}/v1/status", paths.rest_port)).await
}

/// Чтение файла, который держит другой процесс (нода пишет лог с эксклюзивной
/// блокировкой; обычный fs::read на Windows получает sharing violation).
fn read_shared(path: &Path) -> Result<Vec<u8>, String> {
    use std::io::Read;

    let mut opts = fs::OpenOptions::new();
    opts.read(true);
    #[cfg(windows)]
    {
        use std::os::windows::fs::OpenOptionsExt;
        const FILE_SHARE_READ: u32 = 0x1;
        const FILE_SHARE_WRITE: u32 = 0x2;
        const FILE_SHARE_DELETE: u32 = 0x4;
        opts.share_mode(FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE);
    }

    let mut file = opts
        .open(path)
        .map_err(|e| format!("cannot open {}: {e}", path.display()))?;
    let mut buffer = Vec::new();
    file.read_to_end(&mut buffer)
        .map_err(|e| format!("cannot read {}: {e}", path.display()))?;
    Ok(buffer)
}

pub fn read_log_tail_named(net: &str, name: &str, lines: usize) -> Result<Vec<String>, String> {
    let paths = resolve_paths(net);
    let log = std::path::Path::new(&paths.net_dir).join("LOGS").join(name);
    if !log.exists() {
        return Err(format!("log not found: {}", log.display()));
    }
    let bytes = read_shared(&log)?;
    let text = String::from_utf8_lossy(&bytes).to_string();
    let all: Vec<&str> = text.lines().collect();
    let take = lines.clamp(1, 5000).min(all.len());
    Ok(all[all.len() - take..].iter().map(|s| s.to_string()).collect())
}


/// Best-effort Tor liveness probe: the node starts tor with SocksPort from
/// TOR.SOCKS_PORT; if that is absent we try the historic Grin++ ports.
/// POST /v1/resync on the node REST API (admin, requires .api_secret).
pub async fn resync_node(net: &str) -> Result<bool, String> {
    let paths = resolve_paths(net);
    let secret_path = std::path::Path::new(&paths.net_dir).join(".api_secret");
    let secret = std::fs::read_to_string(&secret_path).map_err(|e| e.to_string())?;
    let client = reqwest::Client::builder()
        .timeout(std::time::Duration::from_secs(60))
        .build()
        .map_err(|e| e.to_string())?;
    let response = client
        .post(format!("http://127.0.0.1:{}/v1/resync", paths.rest_port))
        .header("Authorization", format!("Bearer {}", secret.trim()))
        .send()
        .await
        .map_err(|e| e.to_string())?;
    Ok(response.status().is_success())
}

pub fn tor_running(net: &str) -> bool {
    let cfg = read_net_config(net).ok();
    let mut ports: Vec<u16> = Vec::new();
    let torPort = port_from(&cfg, &["TOR", "SOCKS_PORT"], 0);
    if torPort != 0 { ports.push(torPort); }
    ports.push(3422);
    ports.push(3421);
    ports.dedup();
    for port in ports {
        if let Ok(addr) = format!("127.0.0.1:{}", port).parse() {
            if std::net::TcpStream::connect_timeout(&addr, std::time::Duration::from_millis(350)).is_ok() {
                return true;
            }
        }
    }
    false
}

pub fn append_ui_log(net: &str, level: &str, message: &str) -> Result<(), String> {
    let paths = resolve_paths(net);
    let dir = std::path::Path::new(&paths.net_dir).join("LOGS");
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let path = dir.join("ui.log");
    use std::io::Write;
    let mut file = std::fs::OpenOptions::new().create(true).append(true).open(&path).map_err(|e| e.to_string())?;
    let stamp = chrono_lite_now();
    writeln!(file, "[{}] [{}] {}", stamp, level, message).map_err(|e| e.to_string())
}

fn chrono_lite_now() -> String {
    use std::time::{SystemTime, UNIX_EPOCH};
    let secs = SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0);
    format!("{}", secs)
}

pub fn read_log_tail(net: &str, lines: usize) -> Result<Vec<String>, String> {
    let paths = resolve_paths(net);
    let log = PathBuf::from(&paths.net_dir).join("LOGS").join("Node.log");
    let bytes = read_shared(&log)?;
    // Логи ноды могут содержать байты системных сообщений Windows (cp1251), поэтому декодируем lossy.
    let text = String::from_utf8_lossy(&bytes).to_string();
    let all: Vec<&str> = text.lines().collect();
    let take = lines.clamp(1, 5000).min(all.len());
    Ok(all[all.len() - take..].iter().map(|s| s.to_string()).collect())
}

pub fn read_net_config(net: &str) -> Result<Value, String> {
    let paths = resolve_paths(net);
    let path = config_path(Path::new(&paths.data_dir), net);
    Ok(read_json(&path).unwrap_or_else(|| json!({})))
}

pub fn save_net_config(net: &str, config: &Value) -> Result<(), String> {
    let paths = resolve_paths(net);
    let dir = net_dir(Path::new(&paths.data_dir), net);
    fs::create_dir_all(&dir).map_err(|e| format!("cannot create {}: {e}", dir.display()))?;
    let path = dir.join("server_config.json");
    let text = serde_json::to_string_pretty(config).map_err(|e| e.to_string())?;
    fs::write(&path, text).map_err(|e| format!("cannot write {}: {e}", path.display()))
}

pub fn api_secret_present(net: &str) -> bool {
    let paths = resolve_paths(net);
    net_dir(Path::new(&paths.data_dir), net)
        .join(".api_secret")
        .is_file()
}

pub fn read_api_secret(net: &str) -> Result<String, String> {
    let paths = resolve_paths(net);
    let path = net_dir(Path::new(&paths.data_dir), net).join(".api_secret");
    let secret = fs::read_to_string(&path).map_err(|e| format!("cannot read api secret: {e}"))?;
    Ok(secret.trim().to_string())
}

/// Прокси owner-wallet API: секрет остаётся в ядре и не попадает в webview.
pub async fn wallet_rpc(net: &str, method: &str, params: Value) -> Result<Value, String> {
    let paths = resolve_paths(net);
    let secret = read_api_secret(net)?;
    let body = json!({ "jsonrpc": "2.0", "id": 1, "method": method, "params": params });

    let resp = reqwest::Client::new()
        .post(format!("http://127.0.0.1:{}/v2", paths.wallet_port))
        .header("Authorization", format!("Bearer {secret}"))
        .json(&body)
        .timeout(Duration::from_secs(120))
        .send()
        .await
        .map_err(|e| format!("request failed: {e}"))?;
    let status = resp.status();
    let text = resp.text().await.map_err(|e| e.to_string())?;
    if !status.is_success() {
        return Err(format!("HTTP {status}: {text}"));
    }
    let value: Value = serde_json::from_str(&text).map_err(|e| format!("bad json: {e}"))?;
    // Кошелёк отвечает 200 и JSON-RPC-ошибкой: без этой проверки UI молча
    // ничего не делает, потому что session_token отсутствует.
    if let Some(error) = value.get("error") {
        return Err(format!("wallet error: {error}"));
    }
    Ok(value)
}

pub fn printable_ascii(value: &str) -> bool {
    !value.is_empty()
        && value.len() <= MAX_BRIDGE_LEN
        && value.bytes().all(|b| (0x20..=0x7e).contains(&b))
}

pub fn is_valid_obfs4(bridge: &str) -> bool {
    printable_ascii(bridge) && bridge.starts_with("obfs4 ")
}

pub fn is_valid_snowflake(bridge: &str) -> bool {
    printable_ascii(bridge) && bridge.starts_with("snowflake ")
}

async fn moat_request(builder: reqwest::RequestBuilder) -> Result<Value, String> {
    let resp = builder
        .timeout(Duration::from_secs(20))
        .send()
        .await
        .map_err(|e| format!("moat request failed: {e}"))?;
    let status = resp.status();
    let text = resp.text().await.map_err(|e| e.to_string())?;
    if !status.is_success() {
        return Err(format!("moat HTTP {status}: {text}"));
    }
    serde_json::from_str(&text).map_err(|e| format!("moat bad json: {e}"))
}

pub fn parse_snowflake_line(line: &str) -> Option<Value> {
    let parts: Vec<&str> = line.split_whitespace().collect();
    if parts.len() < 3 || parts[0] != "snowflake" {
        return None;
    }
    let bridge = parts[..3].join(" ");
    let mut url = String::new();
    let mut fronts = String::new();
    let mut ice = String::new();
    let mut index = 3;
    while index + 1 < parts.len() {
        match parts[index] {
            "-url" => url = parts[index + 1].to_string(),
            "-front" | "-fronts" => fronts = parts[index + 1].to_string(),
            "-ice" => ice = parts[index + 1].to_string(),
            _ => {}
        }
        index += 2;
    }
    Some(json!({ "bridge": bridge, "url": url, "fronts": fronts, "ice": ice }))
}

pub async fn moat_map() -> Result<Value, String> {
    let map = moat_request(reqwest::Client::new().get(format!("{MOAT_BASE}/moat/circumvention/map"))).await?;
    let mut obfs4: Vec<String> = Vec::new();
    let mut snowflake: Option<Value> = None;

    if let Some(countries) = map.as_object() {
        for country in countries.values() {
            let Some(settings) = country.get("settings").and_then(Value::as_array) else {
                continue;
            };
            for setting in settings {
                let Some(bridges) = setting.get("bridges") else { continue };
                let kind = bridges.get("type").and_then(Value::as_str).unwrap_or("");
                let Some(list) = bridges.get("bridge_strings").and_then(Value::as_array) else {
                    continue;
                };
                for entry in list {
                    let Some(line) = entry.as_str() else { continue };
                    if kind == "obfs4" && is_valid_obfs4(line) && !obfs4.iter().any(|b| b == line) {
                        obfs4.push(line.to_string());
                    } else if kind == "snowflake" && snowflake.is_none() && is_valid_snowflake(line) {
                        snowflake = parse_snowflake_line(line);
                    }
                }
            }
        }
    }

    Ok(json!({ "obfs4": obfs4, "snowflake": snowflake }))
}

pub async fn moat_fetch() -> Result<Value, String> {
    let body = json!({
        "data": [{ "version": "0.1.0", "type": "client-transports", "supported": ["obfs4"] }]
    });
    let parsed = moat_request(
        reqwest::Client::new()
            .post(format!("{MOAT_BASE}/moat/fetch"))
            .json(&body),
    )
    .await?;

    let first = parsed
        .get("data")
        .and_then(Value::as_array)
        .and_then(|items| items.first())
        .cloned()
        .ok_or_else(|| "moat: empty response".to_string())?;

    if first.get("type").and_then(Value::as_str) != Some("moat-challenge") {
        return Err("moat: unexpected CAPTCHA response".into());
    }

    let image_b64 = first.get("image").and_then(Value::as_str).unwrap_or("");
    Ok(json!({
        "id": first.get("id").and_then(Value::as_str).unwrap_or(""),
        "challenge": first.get("challenge").and_then(Value::as_str).unwrap_or(""),
        "image": if image_b64.is_empty() { String::new() } else { format!("data:image/jpeg;base64,{image_b64}") }
    }))
}

pub async fn moat_check(id: &str, challenge: &str, solution: &str) -> Result<Vec<String>, String> {
    let body = json!({
        "data": [{
            "id": id,
            "type": "moat-solution",
            "version": "0.1.0",
            "transport": "obfs4",
            "challenge": challenge,
            "solution": solution,
            "qrcode": false
        }]
    });
    let parsed = moat_request(
        reqwest::Client::new()
            .post(format!("{MOAT_BASE}/moat/check"))
            .json(&body),
    )
    .await?;

    if parsed.get("errors").is_some() {
        return Err("CAPTCHA отклонена".into());
    }

    let first = parsed
        .get("data")
        .and_then(Value::as_array)
        .and_then(|items| items.first())
        .cloned()
        .unwrap_or(Value::Null);

    if first.get("type").and_then(Value::as_str) == Some("moat-challenge") {
        return Err("CAPTCHA отклонена, попробуйте снова".into());
    }

    let bridges: Vec<String> = first
        .get("bridges")
        .and_then(Value::as_array)
        .map(|items| {
            items
                .iter()
                .filter_map(Value::as_str)
                .filter(|line| is_valid_obfs4(line))
                .map(str::to_string)
                .collect()
        })
        .unwrap_or_default();

    if bridges.is_empty() {
        return Err("BridgeDB не выдал obfs4-мосты".into());
    }

    Ok(bridges)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn child_env_pins_homedrive_and_homepath_to_the_node_folder() {
        let root = Path::new(r"C:\DHW\Gplus\work\stand\node");
        let env: std::collections::HashMap<String, String> = child_env(root)
            .into_iter()
            .map(|(k, v)| (k.to_string_lossy().to_string(), v.to_string_lossy().to_string()))
            .collect();

        assert_eq!(env.get("HOMEDRIVE").map(String::as_str), Some("C:"));
        assert_eq!(
            env.get("HOMEPATH").map(String::as_str),
            Some(r"\DHW\Gplus\work\stand\node")
        );
        assert_eq!(
            env.get("TMP").map(String::as_str),
            Some(r"C:\DHW\Gplus\work\stand\node\tmp")
        );
    }

    #[test]
    fn port_lookup_uses_config_then_fallback() {
        let cfg = json!({ "SERVER": { "REST_API_PORT": 13413 } });
        assert_eq!(port_from(&Some(cfg), &["SERVER", "REST_API_PORT"], 3413), 13413);
        assert_eq!(port_from(&None, &["SERVER", "REST_API_PORT"], 3413), 3413);
    }

    #[test]
    fn data_root_is_the_node_directory() {
        assert_eq!(
            data_root_for(Path::new(r"C:\x\y\GrinNode.exe")),
            PathBuf::from(r"C:\x\y")
        );
    }
}
