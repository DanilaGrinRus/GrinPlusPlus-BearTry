// Минимальный CDP-клиент для старого Chromium (Electron 6): без Playwright.
const http = require("http");

const port = Number(process.argv[2] || 9333);
const expr = process.argv[3] || "document.body.innerText.slice(0,500)";

function getJson(url) {
  return new Promise((resolve, reject) => {
    http
      .get(url, (res) => {
        let data = "";
        res.on("data", (c) => (data += c));
        res.on("end", () => {
          try {
            resolve(JSON.parse(data));
          } catch (e) {
            reject(e);
          }
        });
      })
      .on("error", reject);
  });
}

(async () => {
  const targets = await getJson(`http://127.0.0.1:${port}/json/list`);
  const pages = targets.filter((t) => t.type === "page");
const page = pages.find((t) => (t.url || "").startsWith("http")) || pages[0];
  if (!page) throw new Error("no page target");

  const ws = new WebSocket(page.webSocketDebuggerUrl);
  let id = 0;
  const pending = new Map();
  const events = [];

  ws.onmessage = (ev) => {
    const msg = JSON.parse(ev.data);
    if (msg.id && pending.has(msg.id)) {
      pending.get(msg.id)(msg);
      pending.delete(msg.id);
    } else if (msg.method) {
      events.push(msg);
    }
  };

  const send = (method, params = {}) =>
    new Promise((resolve) => {
      const msgId = ++id;
      pending.set(msgId, resolve);
      ws.send(JSON.stringify({ id: msgId, method, params }));
    });

  await new Promise((r) => (ws.onopen = r));
  await send("Runtime.enable");
  await send("Log.enable");
  await new Promise((r) => setTimeout(r, 4000));

  const result = await send("Runtime.evaluate", {
    expression: expr,
    returnByValue: true,
    awaitPromise: true,
  });

  const consoleEvents = events
    .filter((e) => e.method === "Runtime.consoleAPICalled" || e.method === "Log.entryAdded" || e.method === "Runtime.exceptionThrown")
    .map((e) =>
      JSON.stringify(e.params).slice(0, 400),
    )
    .slice(-20);

  console.log(
    JSON.stringify(
      {
        value: result.result?.result?.value ?? result.result?.exceptionDetails ?? null,
        consoleEvents,
      },
      null,
      2,
    ),
  );
  ws.close();
})();
