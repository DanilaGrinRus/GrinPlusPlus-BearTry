// Полный платёжный цикл через Tauri UI: coin9 (funded) -> rcv1 (new), S1/S2/S3.
import { chromium } from "playwright-core";
import { writeFileSync, mkdirSync } from "node:fs";

const ev = process.argv[2] ?? "C:\\DHW\\Gplus\\evidence\\gplus-2.0.0-20261111\\wallet-cycle";
mkdirSync(ev, { recursive: true });
const result = { steps: [], startedAt: new Date().toISOString() };
const browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
const page = browser.contexts()[0].pages()[0];
await page.waitForSelector(".app .toolbar", { timeout: 30000 });

async function shot(name) { try { await page.screenshot({ path: `${ev}\\${name}.png` }); } catch {} }
function step(name, data) { result.steps.push({ step: name, ...data }); console.log(`[${name}]`, JSON.stringify(data).slice(0, 300)); }

const selects = page.locator(".toolbar select");
await selects.nth(0).selectOption("en").catch(() => {});
await selects.nth(1).selectOption("FLOONET").catch(() => {});
await page.waitForTimeout(1500);

async function goTo(title) { await page.locator(`.icon-btn[title="${title}"]`).click(); await page.waitForTimeout(600); }
async function logoutIfNeeded() {
  const logout = page.locator('.icon-btn[title="Log out"]');
  if (await logout.count()) { await logout.first().click(); await page.waitForTimeout(1000); }
}
async function login(user) {
  await goTo("Wallet");
  await page.waitForTimeout(600);
  if (await page.locator(".spendable").count() === 0) {
    const loginLink = page.getByRole("button", { name: /^login$/i });
    if (await loginLink.count()) { await loginLink.first().click(); await page.waitForTimeout(400); }
    await page.fill('input[placeholder="username"]', user);
    await page.fill('input[placeholder="password"]', "TestnetOnly!2026");
    await page.getByRole("button", { name: /^login$/i }).last().click();
    await page.waitForSelector(".spendable", { timeout: 600000 });
  }
  return (await page.locator(".spendable").innerText()).trim();
}
async function ensureReceiver(user) {
  try { return await login(user); } catch { }
  await logoutIfNeeded();
  await goTo("Wallet");
  await page.getByRole("button", { name: /^create wallet$/i }).click();
  await page.waitForTimeout(500);
  await page.fill('input[placeholder="username"]', user);
  await page.fill('input[placeholder="password"]', "TestnetOnly!2026");
  await page.getByRole("button", { name: /^create wallet$/i }).last().click();
  await page.waitForSelector(".spendable", { timeout: 600000 });
  return (await page.locator(".spendable").innerText()).trim();
}

try {
  await logoutIfNeeded();
  let bal = await login("coin9");
  step("login_coin9", { spendable: bal });
  await shot("01-coin9-balance");
  await logoutIfNeeded();

  await ensureReceiver("rcv1");
  step("rcv1_ready", { ok: true });
  await shot("02-rcv1");
  await goTo("Receive");
  await page.waitForSelector("code", { timeout: 30000 });
  const rcvAddress = (await page.locator("code").first().innerText()).trim();
  step("rcv1_address", { address: rcvAddress });
  await shot("03-rcv1-address");
  await logoutIfNeeded();

  await login("coin9");
  await goTo("Send");
  const addrInput = page.locator('input[placeholder="recipient slatepack address"]').first();
  await addrInput.fill(rcvAddress);
  await page.locator('input[placeholder="amount, GRIN"]').first().fill("1");
  await page.locator('button.primary', { hasText: "Send" }).first().click();
  await page.waitForSelector('h2:has-text("S1")', { timeout: 180000 });
  const s1 = (await page.locator("textarea").first().inputValue()).trim();
  step("send_s1", { slatepack_len: s1.length, start: s1.slice(0, 24) });
  await shot("04-s1");
  await logoutIfNeeded();

  await login("rcv1");
  await goTo("Receive");
  await page.locator(".panel textarea").first().fill(s1);
  await page.locator('.panel button.primary', { hasText: "Receive" }).first().click();
  await page.waitForTimeout(4000);
  const s2 = (await page.locator("textarea").last().inputValue()).trim();
  step("receive_s2", { slatepack_len: s2.length, start: s2.slice(0, 24) });
  await shot("05-s2");
  await logoutIfNeeded();

  await login("coin9");
  await goTo("Send");
  await page.locator(".panel textarea").last().fill(s2);
  await page.locator('.panel button.primary', { hasText: "Finalize" }).first().click();
  await page.waitForTimeout(12000);
  const content = (await page.locator(".content").innerText()).replace(/\s+/g, " ");
  step("finalize_s3", { message: content.slice(0, 500) });
  await shot("06-finalize");
  const senderFinal = (await page.locator(".spendable").innerText()).trim();
  step("coin9_after", { spendable: senderFinal });
  await logoutIfNeeded();

  const rcvBal = await login("rcv1");
  step("rcv1_after", { spendable: rcvBal });
  await shot("07-rcv1-after");

  await goTo("History");
  await page.waitForTimeout(3000);
  const history = (await page.locator(".content").innerText()).replace(/\s+/g, " ");
  step("history", { text: history.slice(0, 600) });
  await shot("08-history");
} catch (e) {
  step("error", { message: String(e).slice(0, 600) });
  await shot("99-error");
} finally {
  result.finishedAt = new Date().toISOString();
  writeFileSync(`${ev}\\wallet-cycle.json`, JSON.stringify(result, null, 2), "utf8");
  await browser.close();
}
