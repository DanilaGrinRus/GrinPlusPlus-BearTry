// Вход в кошелёк через UI и скриншот дашборда: node login-shot.mjs <out.png> [user] [pass]
import { chromium } from "playwright-core";

const out = process.argv[2];
const user = process.argv[3] ?? "seed-1";
const pass = process.argv[4] ?? "TestnetOnly!2026";
const browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
const page = browser.contexts()[0].pages()[0];
await page.waitForSelector(".app .chrome", { timeout: 20000 });
await page.locator('.nav-item:has-text("Кошелёк")').click();
await page.waitForSelector(".welcome-logo", { timeout: 15000 });
await page.getByRole("button", { name: /^login$/i }).click();
await page.fill('input[placeholder="username"]', user);
await page.fill('input[placeholder="password"]', pass);
await page.getByRole("button", { name: /^login$/i }).last().click();
await page.waitForSelector(".spendable", { timeout: 240000 });
await page.waitForTimeout(1500);
await page.screenshot({ path: out });
console.log("saved", out);
await browser.close();
