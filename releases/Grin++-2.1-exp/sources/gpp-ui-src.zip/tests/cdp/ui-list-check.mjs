import { chromium } from "playwright-core";
const browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
const page = browser.contexts()[0].pages()[0];
await page.waitForSelector(".app .toolbar", { timeout: 20000 });
const out = "C:\\DHW\\Gplus\\evidence\\ui-tauri-20261110\\cdp";
const selects = page.locator(".toolbar select");
await selects.nth(1).selectOption("FLOONET").catch(() => {});
await page.waitForTimeout(2000);
// login
await page.locator('.icon-btn[title="Кошелёк"]').click();
await page.waitForTimeout(1500);
if (await page.locator(".spendable").count() === 0) {
  const link = page.getByRole("button", { name: /войти|login/i });
  if (await link.count()) { await link.first().click(); await page.waitForTimeout(500); }
  await page.fill('input[placeholder="username"]', "coin9");
  await page.fill('input[placeholder="password"]', "TestnetOnly!2026");
  await page.getByRole("button", { name: /войти|login/i }).last().click();
  await page.waitForSelector(".spendable", { timeout: 600000 });
}
await page.waitForTimeout(2500);
const bal = await page.locator(".spendable").innerText();
await page.screenshot({ path: out + "\\ui-list-wallet.png" });
// hide balance
await page.getByRole("button", { name: /скрыть баланс/i }).first().click();
await page.waitForTimeout(800);
const hidden = await page.locator(".spendable").innerText();
await page.screenshot({ path: out + "\\ui-list-wallet-hidden.png" });
console.log("balance:", bal.trim(), "| hidden:", hidden.trim());
// restore balance
await page.getByRole("button", { name: /показать баланс/i }).first().click();
await page.waitForTimeout(500);
// history select
await page.locator('.icon-btn[title="История"]').click();
await page.waitForTimeout(1500);
const filterCount = await page.locator("select").count();
await page.screenshot({ path: out + "\\ui-list-history.png" });
console.log("history selects:", filterCount, "| text:", (await page.locator(".content").innerText()).replace(/\n+/g," | ").slice(0,180));
// receive QR
await page.locator('.icon-btn[title="Получение"]').click();
await page.waitForTimeout(2000);
const qr = await page.locator("img.qr").count();
await page.screenshot({ path: out + "\\ui-list-receive.png" });
console.log("qr images:", qr);
// logs stages
await page.locator('.icon-btn[title="Логи"]').click();
await page.waitForTimeout(1200);
await page.getByRole("button", { name: /^Этапы$/ }).click();
await page.waitForTimeout(1200);
const rows = await page.locator(".stage-table tbody tr").count();
await page.screenshot({ path: out + "\\ui-list-stages.png" });
console.log("stage rows:", rows);
// status
await page.locator('.icon-btn[title="Статус"]').click();
await page.waitForTimeout(1200);
const details = await page.locator("details").count();
await page.screenshot({ path: out + "\\ui-list-status.png" });
console.log("status details:", details);
await browser.close();
