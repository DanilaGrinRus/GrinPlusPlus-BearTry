import { chromium } from "playwright-core";
import { writeFileSync } from "node:fs";
const browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
const page = browser.contexts()[0].pages()[0];
await page.waitForSelector(".app .toolbar", { timeout: 20000 });
const out = "C:\\DHW\\Gplus\\evidence\\ui-tauri-20261110\\cdp\\audit";
const report = [];
const shot = async (name) => { await page.screenshot({ path: `${out}-${name}.png` }); };
const go = async (title) => { await page.locator(`.icon-btn[title="${title}"]`).click(); await page.waitForTimeout(900); };
// Floonet
const selects = page.locator(".toolbar select");
await selects.nth(1).selectOption("FLOONET").catch(() => {});
await page.waitForTimeout(1500);
// login coin9
await go("Кошелёк");
await page.waitForTimeout(1200);
if (await page.locator(".spendable").count() === 0) {
  const link = page.getByRole("button", { name: /^login$/i });
  if (await link.count()) { await link.first().click(); await page.waitForTimeout(400); }
  await page.fill('input[placeholder="username"]', "coin9");
  await page.fill('input[placeholder="password"]', "TestnetOnly!2026");
  await page.getByRole("button", { name: /^login$/i }).last().click();
  await page.waitForSelector(".spendable", { timeout: 120000 });
}
await page.waitForTimeout(1500);
for (const [title, name] of [["Статус","status"],["Кошелёк","wallet"],["Отправка","send"],["Получение","receive"],["История","history"],["Tor","tor"],["Логи","logs"],["Настройки","settings"]]) {
  await go(title);
  await page.waitForTimeout(1200);
  const text = (await page.locator(".content").innerText()).replace(/\n{2,}/g, "\n").slice(0, 3500);
  report.push({ page: title, text });
  await shot(name);
}
writeFileSync("C:\\DHW\\Gplus\\evidence\\ui-tauri-20261110\\cdp\\audit-pages.json", JSON.stringify(report, null, 2), "utf8");
console.log("pages:", report.map(r => r.page).join(", "));
await browser.close();
