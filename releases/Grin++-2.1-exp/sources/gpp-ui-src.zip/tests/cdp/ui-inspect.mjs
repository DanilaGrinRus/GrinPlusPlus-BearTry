import { chromium } from "playwright-core";
const browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
const page = browser.contexts()[0].pages()[0];
await page.waitForSelector(".app .toolbar", { timeout: 20000 });
const titles = await page.$$eval(".icon-btn", els => els.map(e => e.getAttribute("title")));
console.log(JSON.stringify(titles));
const text = (await page.locator(".app").innerText()).slice(0, 300);
console.log(JSON.stringify(text));
await browser.close();
