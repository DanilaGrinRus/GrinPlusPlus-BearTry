// Извлечение картинок (логотип) из app.asar официального Grin++.
const fs = require("fs");
const path = require("path");

const asar = process.argv[2];
const outDir = process.argv[3];
const pattern = new RegExp(process.argv[4] || "logo|grin", "i");

const fd = fs.openSync(asar, "r");
const sizeBuf = Buffer.alloc(8);
fs.readSync(fd, sizeBuf, 0, 8, 0);
// формат: uint32 headerSize pickle -> JSON header
const headerSize = sizeBuf.readUInt32LE(4);
const headerBuf = Buffer.alloc(headerSize);
fs.readSync(fd, headerBuf, 0, headerSize, 8);
// pickle: 4 байта длины + payload
let offset = 4;
const payloadSize = headerBuf.readUInt32LE(offset - 4);
const header = JSON.parse(headerBuf.slice(8, 8 + payloadSize - 4).toString("utf8"));
const baseOffset = 8 + headerSize;

function walk(node, prefix) {
  for (const [name, entry] of Object.entries(node.files || {})) {
    const rel = prefix ? `${prefix}/${name}` : name;
    if (entry.files) {
      walk(entry, rel);
    } else if (/\.(png|svg|ico|webp)$/i.test(name) && pattern.test(name)) {
      const start = baseOffset + Number(entry.offset);
      const buf = Buffer.alloc(entry.size);
      fs.readSync(fd, buf, 0, entry.size, start);
      const dest = path.join(outDir, name);
      fs.writeFileSync(dest, buf);
      console.log(`${rel} -> ${dest} (${entry.size} bytes)`);
    }
  }
}

walk(header, "");
fs.closeSync(fd);
