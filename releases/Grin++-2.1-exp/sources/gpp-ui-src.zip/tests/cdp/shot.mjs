// Скриншот произвольного экрана: node shot.mjs <out.png> [navText]
import { chromium } from "playwright-core";

const out = process.argv[2];
const nav = process.argv[3] ?? "";
const browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
const page = browser.contexts()[0].pages()[0];
await page.waitForSelector(".app .toolbar", { timeout: 20000 });
if (nav) {
  await page.locator(`.nav-item:has-text("${nav}")`).click();
}
await page.waitForTimeout(1500);
await page.screenshot({ path: out });
console.log("saved", out);
await browser.close();
