import { chromium } from "playwright-core";
const b = await chromium.connectOverCDP("http://127.0.0.1:9222");
const p = b.contexts()[0].pages()[0];
await p.waitForSelector(".app .toolbar", { timeout: 20000 });
const brand = await p.locator(".brand").innerText();
const title = await p.title();
console.log("brand:", brand, "| title:", title);
await p.screenshot({ path: "C:\\DHW\\Gplus\\evidence\\gplus-hp-exp-20261112\\ui-2.1.0-exp.png" });
await b.close();
