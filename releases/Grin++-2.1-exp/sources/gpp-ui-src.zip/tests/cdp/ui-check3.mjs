import { chromium } from "playwright-core";
const browser = await chromium.connectOverCDP("http://127.0.0.1:9222");
const page = browser.contexts()[0].pages()[0];
await page.waitForSelector(".app .toolbar", { timeout: 20000 });
await page.locator('.icon-btn[title="Настройки"]').click();
await page.waitForTimeout(1200);
await page.screenshot({ path: "C:\\DHW\\Gplus\\evidence\\ui-tauri-20261110\\cdp\\ui-check-settings-hud.png" });
console.log("saved");
await browser.close();
