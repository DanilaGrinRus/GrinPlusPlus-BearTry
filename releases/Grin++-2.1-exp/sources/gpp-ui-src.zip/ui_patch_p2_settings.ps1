$ErrorActionPreference = 'Stop'
$nl = "`r`n"

# ---------------- ConsoleSettings.tsx ----------------
$f = 'C:\DHW\Gplus\work\gpp-ui-tauri-20261110\src\ConsoleSettings.tsx'
$t = [System.IO.File]::ReadAllText($f)

# 1) Logs page: drop node stats grid (duplicates Status page)
$startMarker = '      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32, marginBottom: 18 }}>'
$start = $t.IndexOf($startMarker)
if ($start -lt 0) { throw 'console stats start missing' }
$endMarker = '      <div className="k">Logs</div>'
$end = $t.IndexOf($endMarker)
if ($end -lt 0) { throw 'console logs heading missing' }
$t = $t.Substring(0, $start) + $t.Substring($end)

# 2) Logs page: drop "Connected Peers" footer (duplicates Status)
$startMarker = '      <div className="k" style={{ marginTop: 18 }}>Connected Peers</div>'
$start = $t.IndexOf($startMarker)
if ($start -lt 0) { throw 'peers block start missing' }
$hintMarker = '      <div className="hint" style={{ marginTop: 6 }}>'
$hintStart = $t.IndexOf($hintMarker, $start)
$hintClose = $t.IndexOf('      </div>', $hintStart)
$end = $hintClose + '      </div>'.Length
$t = $t.Substring(0, $start).TrimEnd() + $nl + '    </div>' + $t.Substring($end)
# close the component div that we may have duplicated
$t = $t.Replace('    </div>' + $nl + '    </div>' + $nl + '  );' + $nl + '}', '    </div>' + $nl + '  );' + $nl + '}')

# 3) Settings: wrap P2P panel into <details>
$startMarker = '        <div className="panel">' + $nl + '          <div className="k">P2P settings</div>'
$start = $t.IndexOf($startMarker)
if ($start -lt 0) { throw 'p2p panel start missing' }
$endMarker = '        </div>' + $nl + '      </div>' + $nl + $nl + '      <div className="panel">' + $nl + '        <div className="k">Tor settings</div>'
$end = $t.IndexOf($endMarker)
if ($end -lt 0) { throw 'p2p panel end missing' }
$p2pPanel = $t.Substring($start, $end - $start)
$wrapped = '        <details>' + $nl +
'          <summary className="hint" style={{ cursor: "pointer", padding: "4px 0" }}>Дополнительно: P2P-пиры</summary>' + $nl +
$p2pPanel + $nl +
'        </details>'
$t = $t.Substring(0, $start) + $wrapped + $t.Substring($end)

# 4) Drop the dead Tor settings panel (not wired; real Tor lives on the Tor page)
$startMarker = '      <div className="panel">' + $nl + '        <div className="k">Tor settings</div>'
$start = $t.IndexOf($startMarker)
if ($start -lt 0) { throw 'tor settings panel start missing' }
$endMarker = '      </div>' + $nl + $nl + '      <div className="panel" id="raw-config">'
$end = $t.IndexOf($endMarker)
if ($end -lt 0) { throw 'tor settings panel end missing' }
$t = $t.Substring(0, $start) + $t.Substring($end + '      </div>'.Length)

# 5) Wrap raw config into <details>
$startMarker = '      <div className="panel" id="raw-config">'
$start = $t.IndexOf($startMarker)
if ($start -lt 0) { throw 'raw panel start missing' }
$endMarker = '      </div>' + $nl + '    </div>' + $nl + '  );' + $nl + '}'
$end = $t.IndexOf($endMarker)
if ($end -lt 0) { throw 'raw panel end missing' }
$rawPanel = $t.Substring($start, $end - $start + '      </div>'.Length)
$wrapped = '      <details>' + $nl +
'        <summary className="hint" style={{ cursor: "pointer", padding: "4px 0" }}>Дополнительно: raw server_config.json</summary>' + $nl +
$rawPanel + $nl +
'      </details>'
$t = $t.Substring(0, $start) + $wrapped + $t.Substring($end + '      </div>'.Length)

[System.IO.File]::WriteAllText($f, $t, (New-Object System.Text.UTF8Encoding($false)))
Write-Output ('ConsoleSettings P2 patched: details=' + $t.Contains('Дополнительно: P2P-пиры') + ' torDeadGone=' + (-not $t.Contains('Tor settings')) + ' rawDetails=' + $t.Contains('raw server_config.json'))
