$ErrorActionPreference = 'Stop'
$nl = "`r`n"
$f = 'C:\DHW\Gplus\work\gpp-ui-tauri-20261110\src\ConsoleSettings.tsx'
$t = [System.IO.File]::ReadAllText($f)

# label
$t = $t.Replace('["stage", "Stage Sync"],', '["stage", "Этапы"],')

# stage timeline parsing after filtered useMemo
$anchor = '  const filtered = useMemo(() => {' + $nl + '    const errors = /error|failed|exception|critical|fatal/i;' + $nl + '    const stage = /(sync|pibd|header|block height|progress|stage|activation)/i;' + $nl + '    if (filter === "errors") return lines.filter((line) => errors.test(line));' + $nl + '    if (filter === "stage") return lines.filter((line) => stage.test(line));' + $nl + '    return lines;' + $nl + '  }, [lines, filter]);'
if (-not $t.Contains($anchor)) { throw 'filtered anchor missing' }
$add = $anchor + $nl + $nl + '  type StageRow = { ts: string; name: string; ms: number; outcome: string };' + $nl + '  const stageRows = useMemo<StageRow[]>(() => {' + $nl + '    if (filter !== "stage") return [];' + $nl + '    const re = /startup_timing name=(\\S+) duration_ms=(\\d+) outcome=(\\S+)/;' + $nl + '    const rows: StageRow[] = [];' + $nl + '    for (const line of lines) {' + $nl + '      const m = line.match(re);' + $nl + '      if (!m) continue;' + $nl + '      const ts = line.match(/^\\[([^\\]]+)\\]/)?.[1] ?? "";' + $nl + '      rows.push({ ts, name: m[1], ms: Number(m[2]), outcome: m[3] });' + $nl + '    }' + $nl + '    return rows.slice(-count);' + $nl + '  }, [lines, filter, count]);' + $nl
$t = $t.Replace($anchor, $add)

# render: stage table instead of raw lines
$old = '      <div className="logs">{filtered.slice(-count).join("\\n") || "—"}</div>'
$new = '      {filter === "stage" ? (' + $nl + '        stageRows.length === 0 ? (' + $nl + '          <div className="hint">В выбранных строках нет записей startup_timing.</div>' + $nl + '        ) : (' + $nl + '          <table className="stage-table">' + $nl + '            <thead><tr><th>время</th><th>этап</th><th>длительность</th><th>итог</th></tr></thead>' + $nl + '            <tbody>' + $nl + '              {stageRows.map((row, index) => (' + $nl + '                <tr key={`${row.ts}-${row.name}-${index}`}>' + $nl + '                  <td>{row.ts}</td>' + $nl + '                  <td>{row.name}</td>' + $nl + '                  <td>{(row.ms / 1000).toFixed(1)} с</td>' + $nl + '                  <td className={row.outcome === "success" ? "ok-text" : "bad-text"}>{row.outcome}</td>' + $nl + '                </tr>' + $nl + '              ))}' + $nl + '            </tbody>' + $nl + '          </table>' + $nl + '        )' + $nl + '      ) : (' + $nl + '        <div className="logs">{filtered.slice(-count).join("\\n") || "—"}</div>' + $nl + '      )}'
if (-not $t.Contains($old)) { throw 'logs render anchor missing' }
$t = $t.Replace($old, $new)

[System.IO.File]::WriteAllText($f, $t, (New-Object System.Text.UTF8Encoding($false)))
Write-Output 'ConsoleSettings stage timeline patched'
