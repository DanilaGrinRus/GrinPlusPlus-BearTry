from PIL import Image
import os
src = r"C:\DHW\Gplus\work\gpp-ui-tauri-20261110\src-tauri\icons\icon.png"
out = os.path.dirname(src)
img = Image.open(src).convert("RGBA")
for size, name in [(32, "32x32.png"), (128, "128x128.png"), (256, "128x128@2x.png")]:
    img.resize((size if name != "128x128@2x.png" else 256, size if name != "128x128@2x.png" else 256), Image.LANCZOS).save(os.path.join(out, name))
print("icons written")
