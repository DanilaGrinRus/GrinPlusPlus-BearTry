# build-installer.ps1 — сборка NSIS-установщика Tauri.
#
# Причина обвязки: в C:\DHW\.cargo\config.toml crates.io перенаправлен на локальный
# vendor и включён offline. Для Tauri нужен настоящий crates.io, поэтому конфиг
# временно переименовывается и гарантированно возвращается в finally.

$ErrorActionPreference = 'Stop'
$project = 'C:\DHW\Gplus\work\gpp-ui-tauri-hp-exp'
$cargoConfig = 'C:\DHW\.cargo\config.toml'
$cargoConfigOff = 'C:\DHW\.cargo\config.toml.off'
$log = Join-Path $project 'tauri-build.log'

Get-Process grinpp-desktop -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.Id -Force }; Start-Sleep 2
$moved = $false
try {
    if (Test-Path $cargoConfig) {
        Move-Item -LiteralPath $cargoConfig -Destination $cargoConfigOff -Force
        $moved = $true
    }

    $env:CARGO_NET_OFFLINE = 'false'
    Push-Location $project
    "=== tauri build $(Get-Date -Format o) ===" | Out-File $log -Encoding utf8
    & "$project\node_modules\.bin\tauri.CMD" build 2>&1 | Tee-Object -FilePath $log -Append | Out-Null
    "TAURI_EXIT=$LASTEXITCODE" | Out-File $log -Append -Encoding utf8
    Pop-Location
} finally {
    if ($moved -and (Test-Path $cargoConfigOff)) {
        Move-Item -LiteralPath $cargoConfigOff -Destination $cargoConfig -Force
    }
}

Write-Output "cargo config restored: $((Test-Path $cargoConfig)), backup left: $((Test-Path $cargoConfigOff))"
Get-Content $log -Tail 12
