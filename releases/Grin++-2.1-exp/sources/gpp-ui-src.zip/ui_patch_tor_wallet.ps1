$ErrorActionPreference = 'Stop'
$nl = "`r`n"
$u = 'C:\DHW\Gplus\work\gpp-ui-tauri-20261110'
$f = Join-Path $u 'src\App.tsx'
$t = [System.IO.File]::ReadAllText($f)

# 1) import torRunning
$anchor = '  startNode,'
if (-not $t.Contains($anchor)) { throw 'import startNode anchor missing' }
$t = $t.Replace($anchor, $anchor + $nl + '  torRunning,')

# 2) wallet switcher: clickable list + handler
$anchor = '  const onLogin = async () => {'
$handler = '  const onSwitchWallet = async (name: string) => {' + $nl +
'    if (!session || name === session.username) return;' + $nl +
'    try {' + $nl +
'      await call("logout", { session_token: session.token });' + $nl +
'    } catch {' + $nl +
'      /* ignore */' + $nl +
'    }' + $nl +
'    onSession(null);' + $nl +
'    setUsername(name);' + $nl +
'    setPassword("");' + $nl +
'    setMessage(null);' + $nl +
'    setMode("login");' + $nl +
'  };' + $nl + $nl
if (-not $t.Contains($anchor)) { throw 'onLogin anchor missing' }
$t = $t.Replace($anchor, $handler + $anchor)

$oldList = '        <div className="row">' + $nl +
'          {wallets.map((w) => (' + $nl +
'            <span key={w} className={`tab ${w === session.username ? "active" : ""}`}>{w}</span>' + $nl +
'          ))}' + $nl +
'        </div>'
$newList = '        <div className="row" style={{ flexWrap: "wrap" }}>' + $nl +
'          {wallets.map((w) => (' + $nl +
'            <button' + $nl +
'              key={w}' + $nl +
'              className={`tab ${w === session.username ? "active" : ""}`}' + $nl +
'              title={w === session.username ? "текущий кошелёк" : "переключиться на этот кошелёк"}' + $nl +
'              onClick={() => onSwitchWallet(w)}' + $nl +
'            >' + $nl +
'              {w}' + $nl +
'            </button>' + $nl +
'          ))}' + $nl +
'        </div>'
if (-not $t.Contains($oldList)) { throw 'wallet list anchor missing' }
$t = $t.Replace($oldList, $newList)

# 3) Tor page: accept net prop, add status polling
$t = $t.Replace('{page === "tor" && <TorPage enabled={nodeUp} call={call} session={session} />}',
                '{page === "tor" && <TorPage enabled={nodeUp} call={call} session={session} net={net} />}')
$anchor = 'function TorPage(props: {' + $nl + '  enabled: boolean;' + $nl + '  call: Call;' + $nl + '  session: Session | null;' + $nl + '}) {' + $nl + '  const { enabled, call, session } = props;'
$repl = 'function TorPage(props: {' + $nl + '  enabled: boolean;' + $nl + '  call: Call;' + $nl + '  session: Session | null;' + $nl + '  net: Net;' + $nl + '}) {' + $nl + '  const { enabled, call, session, net } = props;' + $nl + '  const [torUp, setTorUp] = useState<boolean | null>(null);'
if (-not $t.Contains($anchor)) { throw 'TorPage signature anchor missing' }
$t = $t.Replace($anchor, $repl)

$anchor = '  useEffect(() => {' + $nl + '    if (enabled) loadTor();' + $nl + '    // eslint-disable-next-line react-hooks/exhaustive-deps' + $nl + '  }, [enabled]);'
$add = $anchor + $nl + $nl + '  useEffect(() => {' + $nl +
'    if (!enabled) {' + $nl +
'      setTorUp(null);' + $nl +
'      return;' + $nl +
'    }' + $nl +
'    let alive = true;' + $nl +
'    const tick = async () => {' + $nl +
'      try {' + $nl +
'        const up = await torRunning(net);' + $nl +
'        if (alive) setTorUp(up);' + $nl +
'      } catch {' + $nl +
'        /* ignore */' + $nl +
'      }' + $nl +
'    };' + $nl +
'    tick();' + $nl +
'    const timer = window.setInterval(tick, 5000);' + $nl +
'    return () => {' + $nl +
'      alive = false;' + $nl +
'      window.clearInterval(timer);' + $nl +
'    };' + $nl +
'  }, [enabled, net]);'
if (-not $t.Contains($anchor)) { throw 'loadTor effect anchor missing' }
$t = $t.Replace($anchor, $add)

# 4) Tor page: status badge + "try bridges" hint in the main panel
$anchor = '          <h2 style={{ margin: 0 }}>{t("tor.title")}</h2>' + $nl + '          <button className="ghost" onClick={loadTor} disabled={!enabled}>{t("receive.refresh")}</button>'
$add = '          <h2 style={{ margin: 0 }}>{t("tor.title")}</h2>' + $nl +
'          <span className={`badge ${torUp === null ? "wait" : torUp ? "ok" : "bad"}`}>' + $nl +
'            {!enabled ? "нода не запущена" : torUp === null ? "Tor: проверяю…" : torUp ? "Tor работает" : "Tor не работает"}' + $nl +
'          </span>' + $nl +
'          <button className="ghost" onClick={loadTor} disabled={!enabled}>{t("receive.refresh")}</button>'
if (-not $t.Contains($anchor)) { throw 'tor title row anchor missing' }
$t = $t.Replace($anchor, $add)

$anchor = '        {message && <div className="hint">{message}</div>}' + $nl + '        {snowflake && <div className="hint" style={{ marginTop: 6 }}>{t("tor.snowflakeFromMap")}: {snowflake}</div>}' + $nl + '      </div>'
$add = '        {message && <div className="hint">{message}</div>}' + $nl +
'        {snowflake && <div className="hint" style={{ marginTop: 6 }}>{t("tor.snowflakeFromMap")}: {snowflake}</div>}' + $nl +
'        {enabled && torUp === false && (' + $nl +
'          <div className="panel" style={{ marginTop: 12, borderColor: "#a33" }}>' + $nl +
'            <h2 style={{ marginTop: 0 }}>Tor не работает</h2>' + $nl +
'            <div className="hint">Похоже, Tor недоступен или заблокирован. Попробуйте мосты — это обычно решает проблему.</div>' + $nl +
'            <div className="row" style={{ marginTop: 8, flexWrap: "wrap" }}>' + $nl +
'              <button className="primary" onClick={onAuto}>Получить мосты автоматически</button>' + $nl +
'              <button className="ghost" onClick={enableSnowflake}>Включить snowflake</button>' + $nl +
'              <button className="ghost" onClick={retryTor} disabled={!session}>Перезапустить Tor</button>' + $nl +
'            </div>' + $nl +
'          </div>' + $nl +
'        )}' + $nl +
'      </div>'
if (-not $t.Contains($anchor)) { throw 'tor main panel end anchor missing' }
$t = $t.Replace($anchor, $add)

[System.IO.File]::WriteAllText($f, $t, (New-Object System.Text.UTF8Encoding($false)))
Write-Output ('App.tsx patched: switch=' + $t.Contains('onSwitchWallet') + ' torBadge=' + $t.Contains('Tor не работает') + ' netProp=' + $t.Contains('net: Net;'))
