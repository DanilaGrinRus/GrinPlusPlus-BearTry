$ErrorActionPreference = 'Stop'
$nl = "`r`n"
$f = 'C:\DHW\Gplus\work\gpp-ui-tauri-20261110\src\App.tsx'
$t = [System.IO.File]::ReadAllText($f)

# ---------- 1) SendPage: mode prop ----------
$old = 'function SendPage({ enabled, call, session }: { enabled: boolean; call: Call; session: Session | null }) {'
$new = 'function SendPage({ enabled, call, session, mode }: { enabled: boolean; call: Call; session: Session | null; mode: "create" | "finalize" }) {'
if (-not $t.Contains($old)) { throw 'SendPage signature anchor missing' }
$t = $t.Replace($old, $new)

# wrap create panel + slatepack panel
$startMarker = '      <div className="panel">' + $nl + '        <h2>{t("send.title")}</h2>'
$start = $t.IndexOf($startMarker)
if ($start -lt 0) { throw 'send create panel start missing' }
$endMarker = '      )}' + $nl + $nl + '      <div className="panel">' + $nl + '        <h2>{t("send.finalizeBlock")}</h2>'
$endIdx = $t.IndexOf($endMarker, $start)
if ($endIdx -lt 0) { throw 'send create panel end missing' }
$createBlock = $t.Substring($start, $endIdx - $start)
$wrapped = '      {mode === "create" && (' + $nl + '        <>' + $nl + $createBlock + '        </>' + $nl + '      )}' + $nl + $nl
$t = $t.Substring(0, $start) + $wrapped + $t.Substring($endIdx + '      )}'.Length)

# wrap finalize panel
$startMarker = '      <div className="panel">' + $nl + '        <h2>{t("send.finalizeBlock")}</h2>'
$start = $t.IndexOf($startMarker)
if ($start -lt 0) { throw 'finalize panel start missing' }
$endMarker = '      </div>' + $nl + '    </>' + $nl + '  );' + $nl + '}'
$endIdx = $t.IndexOf($endMarker, $start)
if ($endIdx -lt 0) { throw 'finalize panel end missing' }
$finBlock = $t.Substring($start, $endIdx - $start + '      </div>'.Length)
$wrapped = '      {mode === "finalize" && (' + $nl + $finBlock + $nl + '      )}'
$t = $t.Substring(0, $start) + $wrapped + $t.Substring($endIdx + '      </div>'.Length)

# ---------- 2) PaymentsPage component ----------
$anchor = 'function ReceivePage(props: {'
$payments = 'function PaymentsPage({' + $nl +
'  enabled,' + $nl +
'  call,' + $nl +
'  session,' + $nl +
'  onSession,' + $nl +
'  initialTab,' + $nl +
'}: {' + $nl +
'  enabled: boolean;' + $nl +
'  call: Call;' + $nl +
'  session: Session | null;' + $nl +
'  onSession: (s: Session | null) => void;' + $nl +
'  initialTab: "create" | "receive" | "finalize";' + $nl +
'}) {' + $nl +
'  const [tab, setTab] = useState<"create" | "receive" | "finalize">(initialTab);' + $nl +
'  useEffect(() => setTab(initialTab), [initialTab]);' + $nl +
'  return (' + $nl +
'    <>' + $nl +
'      <div className="tabs" style={{ marginBottom: 14 }}>' + $nl +
'        {[["create", "1. Создать (S1)"], ["receive", "2. Принять (S2)"], ["finalize", "3. Завершить (S3)"]].map(([id, label]) => (' + $nl +
'          <button key={id} className={`tab ${tab === id ? "active" : ""}`} onClick={() => setTab(id as "create" | "receive" | "finalize")}>' + $nl +
'            {label}' + $nl +
'          </button>' + $nl +
'        ))}' + $nl +
'      </div>' + $nl +
'      <div style={{ display: tab === "create" ? "block" : "none" }}>' + $nl +
'        <SendPage enabled={enabled} call={call} session={session} mode="create" />' + $nl +
'      </div>' + $nl +
'      <div style={{ display: tab === "receive" ? "block" : "none" }}>' + $nl +
'        <ReceivePage enabled={enabled} call={call} session={session} onSession={onSession} />' + $nl +
'      </div>' + $nl +
'      <div style={{ display: tab === "finalize" ? "block" : "none" }}>' + $nl +
'        <SendPage enabled={enabled} call={call} session={session} mode="finalize" />' + $nl +
'      </div>' + $nl +
'    </>' + $nl +
'  );' + $nl +
'}' + $nl + $nl
if (-not $t.Contains($anchor)) { throw 'ReceivePage anchor missing' }
$t = $t.Replace($anchor, $payments + $anchor)

# ---------- 3) routing ----------
$t = $t.Replace('{page === "send" && <SendPage enabled={nodeUp} call={call} session={session} />}',
                '{page === "send" && <PaymentsPage enabled={nodeUp} call={call} session={session} onSession={setSession} initialTab="create" />}')
$t = $t.Replace('{page === "receive" && <ReceivePage enabled={nodeUp} call={call} session={session} onSession={setSession} />}',
                '{page === "receive" && <PaymentsPage enabled={nodeUp} call={call} session={session} onSession={setSession} initialTab="receive" />}')

# ---------- 4) wallet page: drop duplicate history, wallet switcher select ----------
$t = $t.Replace('      <HistoryPage enabled={enabled} call={call} session={session} />' + $nl + $nl, '')

$startMarker = '      <div className="panel">' + $nl + '        <h2>{t("wallet.wallets")}</h2>'
$start = $t.IndexOf($startMarker)
if ($start -lt 0) { throw 'wallet panel start missing' }
$endMarker = '        {message && <div className="hint" style={{ marginTop: 8 }}>{message}</div>}' + $nl + '      </div>'
$endIdx = $t.IndexOf($endMarker, $start)
if ($endIdx -lt 0) { throw 'wallet panel end missing' }
$end = $endIdx + $endMarker.Length
$walletPanel = '      <div className="panel">' + $nl +
'        <h2>{t("wallet.wallets")}</h2>' + $nl +
'        <div className="row" style={{ alignItems: "center" }}>' + $nl +
'          <span className="hint">Текущий кошелёк:</span>' + $nl +
'          <select value={session.username} onChange={(e) => onSwitchWallet(e.target.value)}>' + $nl +
'            {wallets.map((w) => (' + $nl +
'              <option key={w} value={w}>{w}</option>' + $nl +
'            ))}' + $nl +
'          </select>' + $nl +
'          <button className="ghost" onClick={onLogoutAll}>{t("node.logoutAll")}</button>' + $nl +
'        </div>' + $nl +
'        <details style={{ marginTop: 10 }}>' + $nl +
'          <summary className="hint" style={{ cursor: "pointer" }}>Управление кошельком</summary>' + $nl +
'          <div className="row" style={{ marginTop: 8 }}>' + $nl +
'            <input placeholder="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />' + $nl +
'            <input placeholder={t("wallet.newPassword")} type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />' + $nl +
'            <button className="ghost" onClick={onChangePassword} disabled={!newPassword}>{t("wallet.changePassword")}</button>' + $nl +
'            <button className="ghost danger" onClick={onDeleteWallet}>{t("wallet.deleteWallet")}</button>' + $nl +
'          </div>' + $nl +
'        </details>' + $nl +
'        {message && <div className="hint" style={{ marginTop: 8 }}>{message}</div>}' + $nl +
'      </div>'
$t = $t.Substring(0, $start) + $walletPanel + $t.Substring($end)

[System.IO.File]::WriteAllText($f, $t, (New-Object System.Text.UTF8Encoding($false)))
Write-Output ('P1 patched: payments=' + $t.Contains('function PaymentsPage') + ' switcher=' + $t.Contains('onSwitchWallet(e.target.value)') + ' historyDupGone=' + (-not $t.Contains('      <HistoryPage enabled={enabled} call={call} session={session} />')))
