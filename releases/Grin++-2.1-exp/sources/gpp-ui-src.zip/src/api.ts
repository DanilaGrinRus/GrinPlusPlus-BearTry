import { invoke } from "@tauri-apps/api/core";

export type Net = "FLOONET" | "MAINNET";

export interface AppPaths {
  node_exe: string;
  data_dir: string;
  net_dir: string;
  rest_port: number;
  wallet_port: number;
}

export interface RpcResponse {
  result?: Record<string, unknown>;
  error?: { code: number; message: string; data?: unknown };
}

export const paths = (net: Net) => invoke<AppPaths>("app_paths", { net });

export const nodeRunning = () => invoke<boolean>("node_running");

export const startNode = (floonet: boolean, noWallet: boolean) =>
  invoke<number>("start_node", { floonet, noWallet });

export const stopNode = () => invoke<void>("stop_node");

export const nodeHealth = (net: Net) => invoke<Record<string, unknown>>("node_health", { net });

export const nodeStatus = (net: Net) => invoke<Record<string, unknown>>("node_status", { net });

export const logTail = (net: Net, lines = 200) =>
  invoke<string[]>("read_log_tail", { net, lines });

export const readConfig = (net: Net) => invoke<Record<string, unknown>>("read_net_config", { net });

export const saveConfig = (net: Net, config: unknown) =>
  invoke<void>("save_net_config", { net, config });

export const apiSecretPresent = (net: Net) => invoke<boolean>("api_secret_present", { net });

export const walletRpc = (net: Net, method: string, params: Record<string, unknown> = {}) =>
  invoke<RpcResponse>("wallet_rpc", { net, method, params });

export interface MoatMap {
  obfs4: string[];
  snowflake: { bridge: string; url: string; fronts: string; ice: string } | null;
}

export interface MoatChallenge {
  id: string;
  challenge: string;
  image: string;
}

export const moatMap = () => invoke<MoatMap>("moat_map");
export const moatFetch = () => invoke<MoatChallenge>("moat_fetch");
export const moatCheck = (id: string, challenge: string, solution: string) =>
  invoke<string[]>("moat_check", { id, challenge, solution });

export const openDataDir = (net: Net) => invoke<void>("open_data_dir", { net });
export const openLogFile = (net: Net) => invoke<void>("open_log_file", { net });

export const logTailNamed = (net: Net, name: string, lines = 200) =>
  invoke<string[]>("log_tail_named", { net, name, lines });

export const uiLog = (net: Net, level: string, message: string) =>
  invoke<void>("ui_log", { net, level, message });

export const torRunning = (net: Net) => invoke<boolean>("tor_running", { net });

export const resyncNode = (net: Net) => invoke<boolean>("resync_node", { net });
