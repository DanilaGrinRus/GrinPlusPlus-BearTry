import { describe, expect, it } from "vitest";
import { grinToNanos, nanosToApiAmount, nanosToGrin } from "./amount";

describe("amount precision", () => {
  it("parses the audit value exactly", () => {
    expect(grinToNanos("9007199.254740993")).toBe(9007199254740993n);
  });

  it("serializes above Number.MAX_SAFE_INTEGER without rounding", () => {
    expect(nanosToApiAmount(9007199254740993n)).toBe("9007199254740993");
    expect(Number(nanosToApiAmount(9007199254740993n))).toBe(9007199254740992); // Number would round
  });

  it("supports uint64 maximum and rejects overflow", () => {
    expect(grinToNanos("18446744073.709551615")).toBe(18446744073709551615n);
    expect(nanosToApiAmount(18446744073709551615n)).toBe("18446744073709551615");
    expect(() => nanosToApiAmount(18446744073709551616n)).toThrow(/uint64/);
  });

  it("keeps existing decimal formatting", () => {
    expect(nanosToGrin(9007199254740993n)).toBe("9007199.254740993");
    expect(nanosToGrin("60000000000")).toBe("60");
  });
});
