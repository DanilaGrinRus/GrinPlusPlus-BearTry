// Иконки в стиле оригинального Grin++ (тонкие линейные, 16-18px).
type P = { size?: number; className?: string };

const base = (size = 17) => ({
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.6,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
});

export const IconConsole = ({ size, className }: P) => (
  <svg {...base(size)} className={className}>
    <rect x="3" y="5" width="18" height="14" rx="1.5" />
    <path d="M7 10l3 2.5L7 15" />
    <path d="M12.5 15h4" />
  </svg>
);

export const IconTor = ({ size, className }: P) => (
  <svg {...base(size)} className={className}>
    <path d="M12 3v18M3 12h18M5.6 5.6l12.8 12.8M18.4 5.6L5.6 18.4" />
    <circle cx="12" cy="12" r="3.2" />
  </svg>
);

export const IconSettings = ({ size, className }: P) => (
  <svg {...base(size)} className={className}>
    <path d="M4 7h10M18 7h2M4 12h4M12 12h8M4 17h8M16 17h4" />
    <circle cx="16" cy="7" r="1.6" />
    <circle cx="10" cy="12" r="1.6" />
    <circle cx="14" cy="17" r="1.6" />
  </svg>
);

export const IconSeed = ({ size, className }: P) => (
  <svg {...base(size)} className={className}>
    <circle cx="8.5" cy="15.5" r="3.5" />
    <path d="M11 13l7-7M15 9l2 2M18 6l2 2" />
  </svg>
);

export const IconLogout = ({ size, className }: P) => (
  <svg {...base(size)} className={className}>
    <path d="M15 4h4v16h-4" />
    <path d="M10 8l-4 4 4 4M6 12h9" />
  </svg>
);

export const IconBack = ({ size, className }: P) => (
  <svg {...base(size)} className={className}>
    <path d="M20 12H5M11 6l-6 6 6 6" />
  </svg>
);

export const IconCopy = ({ size, className }: P) => (
  <svg {...base(size)} className={className}>
    <rect x="9" y="9" width="11" height="11" rx="1.5" />
    <path d="M5 15V5a1 1 0 011-1h9" />
  </svg>
);

export const IconRefresh = ({ size, className }: P) => (
  <svg {...base(size)} className={className}>
    <path d="M20 12a8 8 0 10-2.6 5.9" />
    <path d="M20 5v6h-6" />
  </svg>
);

export const IconCreate = ({ size, className }: P) => (
  <svg {...base(size)} className={className}>
    <path d="M20 12H5M11 6l-6 6 6 6" />
    <path d="M18 6l3 3M18 18l3-3" />
  </svg>
);

export const IconRestore = ({ size, className }: P) => (
  <svg {...base(size)} className={className}>
    <path d="M3 6l9-3 9 3v5c0 4.5-3.6 7.7-9 9-5.4-1.3-9-4.5-9-9V6z" />
    <path d="M9 12l2.2 2.2L15 10" />
  </svg>
);

export const IconShield = ({ size, className }: P) => (
  <svg {...base(size)} className={className}>
    <path d="M12 3l7 3v5c0 4.4-2.9 7.6-7 9-4.1-1.4-7-4.6-7-9V6l7-3z" />
  </svg>
);

export const IconNode = ({ size, className }: P) => (
  <svg {...base(size)} className={className}>
    <rect x="4" y="4" width="7" height="7" rx="1" />
    <rect x="13" y="13" width="7" height="7" rx="1" />
    <path d="M11 7.5h4.5V13" />
  </svg>
);

export const IconSend = ({ size, className }: P) => (
  <svg {...base(size)} className={className}>
    <path d="M4 12l16-8-6 16-2.6-6.4L4 12z" />
  </svg>
);

export const IconReceive = ({ size, className }: P) => (
  <svg {...base(size)} className={className}>
    <path d="M12 4v12M7.5 11.5L12 16l4.5-4.5" />
    <path d="M4 20h16" />
  </svg>
);

export const IconWindowMin = ({ size = 12 }: P) => (
  <svg width={size} height={size} viewBox="0 0 12 12">
    <path d="M2 6h8" stroke="currentColor" strokeWidth="1.2" />
  </svg>
);

export const IconWindowMax = ({ size = 12 }: P) => (
  <svg width={size} height={size} viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.2">
    <rect x="2" y="2" width="8" height="8" />
  </svg>
);

export const IconWindowClose = ({ size = 12 }: P) => (
  <svg width={size} height={size} viewBox="0 0 12 12" stroke="currentColor" strokeWidth="1.2">
    <path d="M2 2l8 8M10 2l-8 8" />
  </svg>
);
