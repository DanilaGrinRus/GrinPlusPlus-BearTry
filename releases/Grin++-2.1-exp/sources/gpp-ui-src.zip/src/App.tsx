import { useCallback, useEffect, useMemo, useRef, useState, type ReactElement } from "react";
import {
  apiSecretPresent,
  moatCheck,
  moatFetch,
  moatMap,
  nodeHealth,
  nodeRunning,
  nodeStatus,
  readConfig,
  saveConfig,
  uiLog,
  paths as loadPaths,
  startNode,
  torRunning,
  stopNode,
  walletRpc,
  type AppPaths,
  type Net,
} from "./api";
import type { MoatChallenge } from "./api";
import { grinToNanos, nanosToApiAmount, nanosToGrin } from "./amount";
import { writeText } from "@tauri-apps/plugin-clipboard-manager";
import QRCode from "qrcode";
import { getLang, setLang, t, type Lang } from "./i18n";
import { ConsolePage, SettingsPage } from "./ConsoleSettings";
import logo from "./assets/grinpp.png";
import banner from "./assets/grin-banner.png";
import {
  IconConsole,
  IconLogout,
  IconNode,
  IconReceive,
  IconRefresh,
  IconSeed,
  IconSend,
  IconSettings,
  IconTor,
} from "./icons";

type Page = "status" | "wallet" | "send" | "receive" | "history" | "tor" | "logs" | "settings";

interface Session {
  token: string;
  username: string;
  address: string;
}

type Call = (
  method: string,
  params: Record<string, unknown>,
) => Promise<Record<string, unknown> | null>;

const PAGES: { id: Page; key: string }[] = [
  { id: "status", key: "nav.status" },
  { id: "wallet", key: "nav.wallet" },
  { id: "send", key: "nav.payments" },
  { id: "history", key: "nav.history" },
  { id: "tor", key: "nav.tor" },
  { id: "logs", key: "nav.logs" },
  { id: "settings", key: "nav.settings" },
];

const PAGE_ICONS: Record<Page, ReactElement> = {
  status: <IconNode />,
  wallet: <IconSeed />,
  send: <IconSend />,
  receive: <IconReceive />,
  history: <IconRefresh />,
  tor: <IconTor />,
  logs: <IconConsole />,
  settings: <IconSettings />,
};

const pick = (obj: Record<string, unknown> | null | undefined, key: string): string => {
  const value = obj?.[key];
  if (value === null || value === undefined) return "—";
  if (typeof value === "object") return JSON.stringify(value);
  return String(value);
};

const FEE_BASE = 1_000_000; // нано-GRIN, как в контракте и live-прогонах
const SELECTION = { strategy: "SMALLEST", inputs: [] as string[] };

export default function App() {
  const [net, setNet] = useState<Net>("MAINNET");

  // UI-логи: ошибки окна и console.error пишутся в ui.log и видны на странице логов.
  useEffect(() => {
    const logError = (level: string, message: string) => {
      uiLog(net, level, message).catch(() => undefined);
    };
    const onError = (e: ErrorEvent) => logError("error", `${e.message} @ ${e.filename}:${e.lineno}`);
    const onRejection = (e: PromiseRejectionEvent) => logError("error", `unhandledrejection: ${String(e.reason)}`);
    const originalConsoleError = console.error;
    console.error = (...args: unknown[]) => {
      logError("error", args.map((a) => String(a)).join(" "));
      originalConsoleError(...args);
    };
    window.addEventListener("error", onError);
    window.addEventListener("unhandledrejection", onRejection);
    return () => {
      window.removeEventListener("error", onError);
      window.removeEventListener("unhandledrejection", onRejection);
      console.error = originalConsoleError;
    };
  }, [net]);
  const [page, setPage] = useState<Page>("wallet");
  const [lang, setLangState] = useState<Lang>(getLang());
  const [paths, setPaths] = useState<AppPaths | null>(null);
  const [running, setRunning] = useState(false);
  const [health, setHealth] = useState<Record<string, unknown> | null>(null);
  const [status, setStatus] = useState<Record<string, unknown> | null>(null);
  const [, setSecretPresent] = useState(false);
  const [session, setSession] = useState<Session | null>(null);
  const [hudBalance, setHudBalance] = useState<Record<string, unknown> | null>(null);
  const [hideBalance, setHideBalance] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const refreshNode = useCallback(async () => {
    try {
      const [isRunning, h, s, secret] = await Promise.all([
        nodeRunning(),
        nodeHealth(net).catch(() => null),
        nodeStatus(net).catch(() => null),
        apiSecretPresent(net).catch(() => false),
      ]);
      setRunning(isRunning);
      setHealth(h);
      setStatus(s);
      setSecretPresent(secret);
    } catch (e) {
      setError(String(e));
    }
  }, [net]);

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(null), 5000);
    return () => clearTimeout(timer);
  }, [toast]);

  useEffect(() => {
    loadPaths(net).then(setPaths).catch((e) => setError(String(e)));
  }, [net]);

  useEffect(() => {
    refreshNode();
    const timer = window.setInterval(refreshNode, 5000);
    return () => window.clearInterval(timer);
  }, [refreshNode]);

  // Кошелёк блокируется, пока нода обрабатывает state/PIBD: ограничиваем ожидание,
  // иначе кнопки «висят» без всякой обратной связи.
  const withTimeout = <T,>(promise: Promise<T>, ms = 600000): Promise<T> =>
    Promise.race([
      promise,
      new Promise<T>((_, reject) =>
        setTimeout(
          () => reject(new Error(`timeout ${Math.round(ms / 1000)}s: node is busy (syncing state)`)),
          ms,
        ),
      ),
    ]);

  const call = useCallback<Call>(
    async (method, params) => {
      setError(null);
      try {
        const resp = await withTimeout(walletRpc(net, method, params));
        if (resp.error) {
          setError(`${resp.error.code}: ${resp.error.message}`);
          setToast(`${resp.error.code}: ${resp.error.message}`);
          return null;
        }
        return resp.result ?? {};
      } catch (e) {
        setError(String(e));
        return null;
      }
    },
    [net],
  );

  // Нода может быть поднята не этим окном (внешний процесс): считаем её живой, если отвечает health.
  const nodeUp = running || health !== null;

  const syncState = useMemo(() => {
    if (!nodeUp) return { text: t("top.notRunning"), cls: "warn" };
    if (!health) return { text: t("top.noApi"), cls: "err" };
    const sync = pick(status, "sync_status");
    return { text: sync, cls: sync.includes("FULLY") ? "ok" : "warn" };
  }, [nodeUp, running, health, status]);

  const onStart = async () => {
    try {
      await startNode(net === "FLOONET", false);
      await refreshNode();
    } catch (e) {
      setError(String(e));
    }
  };

  const onStop = async () => {
    try {
      await stopNode();
      await refreshNode();
    } catch (e) {
      setError(String(e));
    }
  };

  // Переключение сети должно реально переключать ноду, а не только подпись:
  // останавливаем свой процесс, меняем сеть, поднимаем ноду для неё и обновляем
  // health/status. Внешний процесс (запущенный не этим окном) не трогаем.
  const switchNet = async (next: Net) => {
    if (next === net) return;
    try {
      if (running) {
        await stopNode();
      }
      setNet(next);
      setSession(null);
      setHealth(null);
      setStatus(null);
      await startNode(next === "FLOONET", false);
      await refreshNode();
    } catch (e) {
      setError(String(e));
    }
  };

  return (
    <div className="app">
      <header className="titlebar">
        <span className="brand">Grin++ v2.1.0-exp</span>
        <span className="chrome-spacer" />
      </header>

      <nav className="toolbar">
        {session && <span className="username">{session.username}</span>}
        <div className="iconbar">
          {PAGES.map((p) => (
            <button
              key={p.id}
              className={`icon-btn${page === p.id ? " active" : ""}`}
              title={t(p.key)}
              onClick={() => setPage(p.id)}
            >
              {PAGE_ICONS[p.id]}
            </button>
          ))}
        </div>
        <span className="chrome-spacer" />
        <div className="iconbar">
          <select value={lang} onChange={(e) => { const next = e.target.value as Lang; setLang(next); setLangState(next); }}>
            <option value="ru">Русский</option>
            <option value="en">English</option>
          </select>
          <select value={net} onChange={(e) => { void switchNet(e.target.value as Net); }} title={t("node.netHint")}>
            <option value="FLOONET">Floonet</option>
            <option value="MAINNET">Mainnet</option>
          </select>
          {session && (
            <button className="icon-btn" title={t("node.logout")} onClick={() => setSession(null)}>
              <IconLogout />
            </button>
          )}
        </div>
      </nav>

      <main className="main">

        <div className="content">
          {error && <div className="panel"><div className="err-text">{error}</div></div>}
          {page === "status" && <StatusPage paths={paths} running={nodeUp} health={health} status={status} ownRunning={running} net={net} onStart={onStart} onStop={onStop} />}
          {page === "wallet" && <WalletPage net={net} enabled={nodeUp} call={call} session={session} onSession={setSession} onNavigate={setPage} onBalance={setHudBalance} hideBalance={hideBalance} onToggleHideBalance={() => setHideBalance((v) => !v)} />}
          {page === "send" && <PaymentsPage enabled={nodeUp} call={call} session={session} onSession={setSession} initialTab="create" net={net} />}
          {page === "receive" && <PaymentsPage enabled={nodeUp} call={call} session={session} onSession={setSession} initialTab="receive" net={net} />}
          {page === "history" && <HistoryPage enabled={nodeUp} call={call} session={session} />}
          {page === "tor" && <TorPage enabled={nodeUp} call={call} session={session} net={net} />}
          {page === "logs" && <ConsolePage net={net} />}
          {page === "settings" && <SettingsPage net={net} nodeUp={nodeUp} />}
        </div>
        <footer className="statusbar">
          <span className={`dot ${syncState.text.includes("FULLY_SYNCED") ? "ok" : ""}`} />
          <span>STATUS: {syncState.text}</span>
          {session && (
            <span className="hint" style={{ marginLeft: 8 }}>
              · {session.username} · {hideBalance ? "••••••" : pick(hudBalance, "fmt_spendable")} GRIN
            </span>
          )}
          <span className="chrome-spacer" />
          <button className="ghost" style={{ padding: "0 6px" }} onClick={() => setHideBalance((v) => !v)}>
            {hideBalance ? "показать баланс" : "скрыть баланс"}
          </button>
          <span>{pick(status, "connections")} ↑ 0 ↓</span>
          <img className="status-logo" src={logo} alt="Grin" />
        </footer>
      </main>
      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}


function StatusPage(props: {
  paths: AppPaths | null;
  running: boolean;
  health: Record<string, unknown> | null;
  status: Record<string, unknown> | null;
  ownRunning: boolean;
  net: Net;
  onStart: () => void;
  onStop: () => void;
}) {
  const { paths, running, health, status, ownRunning, net, onStart, onStop } = props;
  const [torEnabled, setTorEnabled] = useState<boolean | null>(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const loadTorEnabled = useCallback(async () => {
    try {
      const cfg = await readConfig(net);
      const tor = cfg?.TOR as Record<string, unknown> | undefined;
      setTorEnabled(tor?.ENABLE_TOR !== false);
    } catch {
      setTorEnabled(true);
    }
  }, [net]);

  useEffect(() => {
    loadTorEnabled();
  }, [loadTorEnabled]);

  const toggleTor = async (value: boolean) => {
    setBusy(true);
    setMsg(null);
    try {
      const cfg = (await readConfig(net)) ?? {};
      const tor = { ...(cfg.TOR as Record<string, unknown> | undefined), ENABLE_TOR: value };
      await saveConfig(net, { ...cfg, TOR: tor });
      setTorEnabled(value);
      setMsg(t("node.torSaved"));
    } catch (e) {
      setMsg(String(e));
    } finally {
      setBusy(false);
    }
  };

  const restart = async () => {
    if (!ownRunning) {
      setMsg(t("node.external"));
      return;
    }
    setBusy(true);
    try {
      onStop();
      window.setTimeout(() => { onStart(); setBusy(false); }, 1500);
    } catch {
      setBusy(false);
    }
  };
  const chain = Number((status?.chain as Record<string, unknown> | undefined)?.height ?? NaN);
  const netHeight = Number((status?.network as Record<string, unknown> | undefined)?.height ?? NaN);
  const sync = String(pick(status, "sync_status"));
  const lastSample = useRef<{ h: number; t: number } | null>(null);
  let percent: number | null = null;
  let eta = "";
  if (Number.isFinite(chain) && Number.isFinite(netHeight) && netHeight > 0) {
    percent = Math.max(0, Math.min(100, Math.round((chain / netHeight) * 100)));
  }
  if (lastSample.current && chain > lastSample.current.h) {
    const minutes = (Date.now() - lastSample.current.t) / 60000;
    if (minutes > 0.2) {
      const rate = (chain - lastSample.current.h) / minutes;
      if (rate > 0 && Number.isFinite(netHeight) && netHeight > chain) {
        const left = Math.round((netHeight - chain) / rate);
        eta = left <= 1 ? "<1 мин" : left < 60 ? `${left} мин` : `${Math.floor(left / 60)} ч ${left % 60} мин`;
      }
    }
  }
  lastSample.current = { h: chain, t: Date.now() };
  return (
    <>
      <div className="panel">
        <h2>{t("status.node")}</h2>
        <div className="grid">
          <div className="kv"><div className="k">{t("status.process")}</div><div className="v">{running ? t("status.running") : t("status.stopped")}</div></div>
          <div className="kv"><div className="k">{t("status.headers")}</div><div className="v">{pick(status, "header_height")}</div></div>
          <div className="kv"><div className="k">{t("status.blocks")}</div><div className="v">{String((status?.chain as Record<string, unknown> | undefined)?.height ?? pick(status, "chain_height"))}</div></div>
        </div>
        <div className="row" style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", marginTop: 12 }}>
          <button className="ghost" onClick={onStart} disabled={running}>{t("node.start")}</button>
          <button className="ghost" onClick={onStop} disabled={!ownRunning}>{t("node.stop")}</button>
          <button className="ghost" onClick={restart} disabled={busy}>{t("node.restart")}</button>
          <label style={{ display: "flex", gap: 6, alignItems: "center", marginLeft: 8 }}>
            <input
              type="checkbox"
              checked={torEnabled ?? true}
              disabled={busy || torEnabled === null}
              onChange={(e) => void toggleTor(e.target.checked)}
            />
            {t("node.tor")}
          </label>
        </div>
        <div className="hint" style={{ marginTop: 6 }}>
          {ownRunning ? t("node.ownHint") : t("node.external")}
          {torEnabled === false ? ` ${t("node.torDisabled")}` : ""}
          {msg ? ` · ${msg}` : ""}
        </div>
        <details style={{ marginTop: 8 }}>
          <summary className="hint" style={{ cursor: "pointer" }}>Подробнее</summary>
          <div className="grid" style={{ marginTop: 8 }}>
            <div className="kv"><div className="k">health</div><div className="v">{health ? pick(health, "status") : "—"}</div></div>
            <div className="kv"><div className="k">tip</div><div className="v">{String((status?.tip as Record<string, unknown> | undefined)?.height ?? pick(status, "tip"))}</div></div>
            <div className="kv"><div className="k">sync</div><div className="v">{pick(status, "sync_status")}</div></div>
          </div>
        </details>
        {sync !== "FULLY_SYNCED" && percent !== null && (
          <div style={{ marginTop: 14 }}>
            <div className="progress"><div style={{ width: `${percent}%` }} /></div>
            <div className="hint" style={{ marginTop: 4 }}>
              {sync} · {percent}%{eta ? ` · осталось ~${eta}` : ""}
            </div>
          </div>
        )}
      </div>
      <details>
        <summary className="hint" style={{ cursor: "pointer", padding: "4px 0" }}>Для отладки: расположение данных</summary>
      <div className="panel">
        <h2>{t("status.paths")}</h2>
        <div className="hint">
          {t("status.dataHint")} <code>{paths?.data_dir ?? "…"}</code>
        </div>
        <div className="grid" style={{ marginTop: 10 }}>
          <div className="kv"><div className="k">node exe</div><div className="v">{paths?.node_exe ?? "…"}</div></div>
          <div className="kv"><div className="k">{t("status.netDir")}</div><div className="v">{paths?.net_dir ?? "…"}</div></div>
          <div className="kv"><div className="k">{t("status.restPort")}</div><div className="v">{paths?.rest_port ?? "—"}</div></div>
          <div className="kv"><div className="k">{t("status.walletPort")}</div><div className="v">{paths?.wallet_port ?? "—"}</div></div>
        </div>
      </div>
      </details>
    </>
  );
}

function WalletPage(props: {
  net: Net;
  enabled: boolean;
  call: Call;
  session: Session | null;
  onSession: (s: Session | null) => void;
  onNavigate: (page: Page) => void;
  onBalance?: (b: Record<string, unknown> | null) => void;
  hideBalance?: boolean;
  onToggleHideBalance?: () => void;
}) {
  const { enabled, call, session, onSession, onNavigate, onBalance, hideBalance, onToggleHideBalance } = props;
  const [mode, setMode] = useState<"create" | "restore" | "login" | null>(null);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [wallets, setWallets] = useState<string[]>([]);
  const [balance, setBalance] = useState<Record<string, unknown> | null>(null);
  const [seed, setSeed] = useState<string | null>(null);
  const [seedVisible, setSeedVisible] = useState(false);
  const [seedWords, setSeedWords] = useState(24);
  const [newPassword, setNewPassword] = useState("");
  const [pendingAction, setPendingAction] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [address, setAddress] = useState("");

  const refreshWallets = async () => {
    const result = await call("list_wallets", {});
    const list = result?.wallets;
    setWallets(Array.isArray(list) ? list.map(String) : []);
  };

  const refreshDashboard = async () => {
    if (!session) return;
    const bal = await call("get_balance", { session_token: session.token });
    if (bal) {
      setBalance(bal);
      onBalance?.(bal);
    }
    const addr = await call("get_slatepack_address", { session_token: session.token });
    if (addr?.slatepack) setAddress(String(addr.slatepack));
  };

  useEffect(() => {
    if (enabled) refreshWallets();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled]);

  useEffect(() => {
    if (session) refreshDashboard();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session]);

  const onCreate = async () => {
    const result = await call("create_wallet", { username, password, num_seed_words: seedWords });
    if (result?.session_token) {
      onSession({
        token: String(result.session_token),
        username,
        address: String(result.slatepack_address ?? ""),
      });
      setSeed(result.wallet_seed ? String(result.wallet_seed) : null);
      setSeedVisible(false);
      setMessage(t("wallet.created"));
      setMode(null);
      await refreshWallets();
    }
  };

  const onRestore = async () => {
    const words = (seed ?? "").trim().split(/\s+/).filter(Boolean);
    if (words.length !== seedWords) {
      setMessage(`В сиде должно быть ${seedWords} слов, вставлено ${words.length}`);
      return;
    }
    const result = await call("restore_wallet", { username, password, wallet_seed: seed ?? "" });
    if (result?.session_token) {
      onSession({
        token: String(result.session_token),
        username,
        address: String(result.slatepack_address ?? ""),
      });
      setSeed(null);
      setMessage(t("wallet.restored"));
      setMode(null);
      await refreshWallets();
    }
  };

  const onSwitchWallet = async (name: string) => {
    if (!session || name === session.username) return;
    try {
      await call("logout", { session_token: session.token });
    } catch {
      /* ignore */
    }
    onSession(null);
    setUsername(name);
    setPassword("");
    setMessage(null);
    setMode("login");
  };

  const onLogin = async () => {
    const result = await call("login", { username, password });
    if (result?.session_token) {
      onSession({
        token: String(result.session_token),
        username,
        address: String(result.slatepack_address ?? ""),
      });
      setMessage(t("wallet.loggedIn"));
      setMode(null);
      await refreshDashboard();
    }
  };

  const onChangePassword = async () => {
    if (!session) return;
    const result = await call("change_password", {
      session_token: session.token,
      username: session.username,
      old_password: password,
      new_password: newPassword,
    });
    if (result) setMessage(t("wallet.passwordChanged"));
  };

  const onDeleteWallet = async () => {
    if (!session) return;
    if (pendingAction !== "delete") {
      setPendingAction("delete");
      setMessage(t("wallet.confirmDelete"));
      return;
    }
    setPendingAction(null);
    const result = await call("delete_wallet", { username: session.username, password });
    if (result) {
      setMessage(t("wallet.deleted"));
      onSession(null);
      await refreshWallets();
    }
  };

  const onLogoutAll = async () => {
    if (!session) return;
    if (pendingAction !== "logout") {
      setPendingAction("logout");
      setMessage(t("wallet.confirmLogout"));
      return;
    }
    setPendingAction(null);
    const result = await call("logout_all", { session_token: session.token });
    if (result) {
      setMessage(t("wallet.sessionsClosed"));
      onSession(null);
    }
  };

  const onCopy = async (value: string) => {
    try {
      await writeText(value);
      setMessage(t("common.copied"));
    } catch (e) {
      setMessage(`${t("common.copyUnavailable")}: ${String(e)}`);
    }
  };

  // Экран входа как в оригинале: логотип и два действия, формы — по клику.
  if (!session) {
    return (
      <div className="welcome">
        <img className="welcome-banner" src={banner} alt="Grin++" />
        <div className="welcome-actions">
          <button className="primary" onClick={() => setMode("create")}>
            {t("wallet.create")}
          </button>
          <button className="welcome-link" onClick={() => setMode("restore")}>
            {t("wallet.restore")}
          </button>
          {wallets.length > 0 && (
            <button className="welcome-link" onClick={() => setMode("login")}>
              {t("wallet.login")}
            </button>
          )}
        </div>
        {!enabled && <div className="hint">Нода не запущена: создать/восстановить кошелёк можно, но синхронизация и операции потребуют запущенной ноды.</div>}
        {mode && (
          <div className="panel" style={{ width: 360, borderBottom: 0 }}>
            <div className="row" style={{ marginBottom: 8 }}>
              <input
                placeholder="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
            </div>
            <div className="row" style={{ marginBottom: 8 }}>
              <input
                placeholder="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            {(mode === "create" || mode === "restore") && (
              <div className="row" style={{ marginBottom: 8 }}>
                <span className="hint">Слов в сиде</span>
                <select value={seedWords} onChange={(e) => setSeedWords(Number(e.target.value))}>
                  <option value={12}>12</option>
                  <option value={18}>18</option>
                  <option value={24}>24</option>
                </select>
              </div>
            )}
            {mode === "restore" && (
              <textarea
                placeholder={`seed (${seedWords} слов)`}
                style={{ minHeight: 90, marginBottom: 8 }}
                value={seed ?? ""}
                onChange={(e) => setSeed(e.target.value)}
              />
            )}
            <div className="row">
              <button
                className="primary"
                onClick={mode === "create" ? onCreate : mode === "restore" ? onRestore : onLogin}
              >
                {mode === "create" ? t("wallet.create") : mode === "restore" ? t("wallet.restore") : t("wallet.login")}
              </button>
              <button className="ghost" onClick={() => setMode(null)}>
                {t("tor.cancel")}
              </button>
            </div>
            {message && <div className="hint" style={{ marginTop: 8 }}>{message}</div>}
          </div>
        )}
      </div>
    );
  }

  const shownAddress = address || session.address;
  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24, marginBottom: 22 }}>
        <div>
          <div className="k">{t("wallet.spendable")}</div>
          <div className="spendable">{hideBalance ? "••••••" : pick(balance, "fmt_spendable")}</div>
          <div className="subbalance">
            immature: {pick(balance, "fmt_awaiting_confirmation")} · locked: {pick(balance, "fmt_locked")}
          </div>
        </div>
        <div>
          <div className="k">address</div>
          <div className="row" style={{ marginTop: 6 }}>
            <span className="address">{shownAddress || "—"}</span>
            <button className="ghost" onClick={() => onCopy(shownAddress)} disabled={!shownAddress}>
              {t("common.copy")}
            </button>
            <button className="ghost" onClick={refreshDashboard}>
              {t("receive.refresh")}
            </button>
            <button className="ghost" onClick={onToggleHideBalance}>
              {hideBalance ? "показать баланс" : "скрыть баланс"}
            </button>
          </div>
          <div className="row" style={{ marginTop: 14 }}>
            <button className="primary" onClick={() => onNavigate("send")}>
              Отправить ↗
            </button>
            <button className="receive" onClick={() => onNavigate("receive")}>
              Получить ↙
            </button>
          </div>
        </div>
      </div>

      {seed && (
        <div className="panel">
          <h2>{t("wallet.seedOnce")}</h2>
          <div className="row">
            <span className="hint" style={{ flex: 1 }}>
              {seedVisible ? "Сид-фраза показана на экране. Убедитесь, что рядом никого нет." : "Сид-фраза скрыта. Покажите её только чтобы записать, затем скройте."}
            </span>
            <button className="primary" onClick={() => setSeedVisible((v) => !v)}>
              {seedVisible ? "Скрыть" : "Показать"}
            </button>
            <button className="ghost" onClick={() => onCopy(seed)}>
              {t("common.copy")}
            </button>
            <button className="ghost" onClick={() => { setSeed(null); setSeedVisible(false); }}>
              {t("wallet.hide")}
            </button>
          </div>
          {seedVisible && (
            <div className="row" style={{ marginTop: 8 }}>
              <code className="address" style={{ wordBreak: "break-all" }}>{seed}</code>
            </div>
          )}
          <div className="hint">{t("wallet.seedSavedHint")}</div>
        </div>
      )}

      <div className="panel">
        <h2>{t("wallet.wallets")}</h2>
        <div className="row" style={{ alignItems: "center" }}>
          <span className="hint">Текущий кошелёк:</span>
          <select value={session.username} onChange={(e) => onSwitchWallet(e.target.value)}>
            {wallets.map((w) => (
              <option key={w} value={w}>{w}</option>
            ))}
          </select>
          <button className="ghost" onClick={onLogoutAll}>{t("node.logoutAll")}</button>
        </div>
        <details style={{ marginTop: 10 }}>
          <summary className="hint" style={{ cursor: "pointer" }}>Управление кошельком</summary>
          <div className="row" style={{ marginTop: 8 }}>
            <input placeholder="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
            <input placeholder={t("wallet.newPassword")} type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
            <button className="ghost" onClick={onChangePassword} disabled={!newPassword}>{t("wallet.changePassword")}</button>
            <button className="ghost danger" onClick={onDeleteWallet}>{t("wallet.deleteWallet")}</button>
          </div>
        </details>
        {message && <div className="hint" style={{ marginTop: 8 }}>{message}</div>}
      </div>
    </div>
  );
}


function SendPage({ enabled, call, session, mode }: { enabled: boolean; call: Call; session: Session | null; mode: "create" | "finalize" }) {
  const [address, setAddress] = useState("");
  const [amount, setAmount] = useState("");
  const [fee, setFee] = useState<string | null>(null);
  const [slatepack, setSlatepack] = useState<string | null>(null);
  const [txId, setTxId] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [response, setResponse] = useState("");

  const onEstimate = async () => {
    if (!session) return;
    try {
      const nanos = grinToNanos(amount);
      const result = await call("estimate_fee", {
        session_token: session.token,
        fee_base: FEE_BASE,
        selection_strategy: SELECTION,
        amount: nanosToApiAmount(nanos),
        change_outputs: 1,
      });
      if (result) setFee(nanosToGrin(result.fee as number));
    } catch (e) {
      setMessage(String(e));
    }
  };

  const onSend = async () => {
    if (!session) return;
    try {
      const nanos = grinToNanos(amount);
      const result = await call("send", {
        session_token: session.token,
        fee_base: FEE_BASE,
        selection_strategy: SELECTION,
        amount: nanosToApiAmount(nanos),
        change_outputs: 1,
        // address не передаём: иначе кошелёк пытается доставить slatepack через Tor;
        // S1 передаётся получателю вручную (как в slatepack-потоке UI).
      });
      if (result?.slatepack) {
        setSlatepack(String(result.slatepack));
        setTxId(result.tx_slate_id ? String(result.tx_slate_id) : null);
        setMessage(`${t("common.status")}: ${pick(result, "status")}`);
      }
    } catch (e) {
      setMessage(String(e));
    }
  };

  const onFinalize = async () => {
    if (!session) return;
    const result = await call("finalize", {
      session_token: session.token,
      slatepack: response,
      post_tx: { method: "FLUFF" },
    });
    if (result) {
      const broadcast = pick(result, "broadcast");
      const lifecycle = pick(result, "lifecycle");
      setMessage(
        broadcast === "POSTED"
          ? `${t("send.finalize")}: ${pick(result, "status")} · broadcast: POSTED (${lifecycle})`
          : `${t("send.finalize")}: ${pick(result, "status")} · broadcast: ${broadcast} — транзакция НЕ отправлена (${lifecycle})`,
      );
    }
  };

  const copy = async (text: string) => {
    try {
      await writeText(text);
      setMessage(t("common.copied"));
    } catch (e) {
      setMessage(`${t("common.copyUnavailable")}: ${String(e)}`);
    }
  };

  return (
    <>
      {mode === "create" && (
        <>
      <div className="panel">
        <h2>Создать платёж (S1)</h2>
        {!session && <div className="hint">{t("wallet.loginFirst")}</div>}
        <div className="row">
          <input placeholder={t("send.addressPlaceholder")} style={{ minWidth: 380 }} value={address} onChange={(e) => setAddress(e.target.value)} />
          <input placeholder={t("send.amountPlaceholder")} style={{ width: 140 }} value={amount} onChange={(e) => setAmount(e.target.value)} />
          <button className="ghost" onClick={onEstimate} disabled={!enabled || !session}>{t("send.estimate")}</button>
          <button className="primary" onClick={onSend} disabled={!enabled || !session || !address}>{t("send.send")}</button>
        </div>
        {fee && <div className="hint" style={{ marginTop: 8 }}>{t("send.fee")}: {fee} GRIN</div>}
        {message && <div className="hint" style={{ marginTop: 8 }}>{message}</div>}
        {txId && <div className="hint" style={{ marginTop: 8 }}>tx_slate_id: {txId}</div>}
      </div>

      {slatepack && (
        <div className="panel">
          <div className="row" style={{ marginBottom: 8 }}>
            <h2 style={{ margin: 0 }}>{t("send.slatepackOut")}</h2>
            <button className="ghost" onClick={() => copy(slatepack)}>{t("common.copy")}</button>
          </div>
          <textarea value={slatepack} readOnly />
        </div>
      )}
        </>
      )}



      {mode === "finalize" && (
      <div className="panel">
        <h2>{t("send.finalizeBlock")}</h2>
        <textarea placeholder={t("send.responsePlaceholder")} value={response} onChange={(e) => setResponse(e.target.value)} />
        <div className="row" style={{ marginTop: 8 }}>
          <button className="primary" onClick={onFinalize} disabled={!enabled || !session || !response}>{t("send.finalize")}</button>
        </div>
      </div>
      )}
    </>
  );
}

function PaymentsPage({
  enabled,
  call,
  session,
  onSession,
  initialTab,
  net,
}: {
  enabled: boolean;
  call: Call;
  session: Session | null;
  onSession: (s: Session | null) => void;
  initialTab: "create" | "receive" | "finalize";
  net: Net;
}) {
  const [tab, setTab] = useState<"create" | "receive" | "finalize">(initialTab);
  const [torUp, setTorUp] = useState<boolean | null>(null);
  useEffect(() => setTab(initialTab), [initialTab]);
  useEffect(() => {
    if (!enabled) {
      setTorUp(null);
      return;
    }
    let alive = true;
    const tick = async () => {
      try {
        const up = await torRunning(net);
        if (alive) setTorUp(up);
      } catch {
        /* ignore */
      }
    };
    tick();
    const timer = window.setInterval(tick, 5000);
    return () => {
      alive = false;
      window.clearInterval(timer);
    };
  }, [enabled, net]);
  return (
    <>
      <div className="row" style={{ marginBottom: 10, alignItems: "center" }}>
        <span className={`badge ${torUp === null ? "wait" : torUp ? "ok" : "bad"}`}>
          {!enabled ? "Tor: нода не запущена" : torUp === null ? "Tor: проверяю…" : torUp ? "Tor работает" : "Tor не работает"}
        </span>
        {enabled && torUp === false && (
          <span className="hint">Tor недоступен: slatepack можно передавать вручную (скопировать S1/S2). Для прямой доставки включите мосты на странице Tor.</span>
        )}
      </div>
      <div className="tabs" style={{ marginBottom: 14 }}>
        {[["create", "1. Создать (S1)"], ["receive", "2. Принять (S2)"], ["finalize", "3. Завершить (S3)"]].map(([id, label]) => (
          <button key={id} className={`tab ${tab === id ? "active" : ""}`} onClick={() => setTab(id as "create" | "receive" | "finalize")}>
            {label}
          </button>
        ))}
      </div>
      <div style={{ display: tab === "create" ? "block" : "none" }}>
        <SendPage enabled={enabled} call={call} session={session} mode="create" />
      </div>
      <div style={{ display: tab === "receive" ? "block" : "none" }}>
        <ReceivePage enabled={enabled} call={call} session={session} onSession={onSession} />
      </div>
      <div style={{ display: tab === "finalize" ? "block" : "none" }}>
        <SendPage enabled={enabled} call={call} session={session} mode="finalize" />
      </div>
    </>
  );
}

function ReceivePage(props: {
  enabled: boolean;
  call: Call;
  session: Session | null;
  onSession: (s: Session | null) => void;
}) {
  const { enabled, call, session, onSession } = props;
  const [incoming, setIncoming] = useState("");
  const [outgoing, setOutgoing] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [qr, setQr] = useState("");

  useEffect(() => {
    const address = session?.address;
    if (!address) {
      setQr("");
      return;
    }
    QRCode.toDataURL(address, { margin: 1, width: 180 }).then(setQr).catch(() => setQr(""));
  }, [session?.address]);

  const loadAddress = async () => {
    if (!session) return;
    const result = await call("get_slatepack_address", { session_token: session.token });
    if (result?.slatepack) onSession({ ...session, address: String(result.slatepack) });
  };

  const newAddress = async () => {
    if (!session) return;
    const result = await call("get_new_slatepack_address", { session_token: session.token });
    if (result?.slatepack) onSession({ ...session, address: String(result.slatepack) });
  };

  const onReceive = async () => {
    if (!session) return;
    const result = await call("receive", { session_token: session.token, slatepack: incoming });
    if (result?.slatepack) {
      setOutgoing(String(result.slatepack));
      setMessage(`${t("common.status")}: ${pick(result, "status")}`);
    }
  };

  const copy = async (text: string) => {
    try {
      await writeText(text);
      setMessage(t("common.copied"));
    } catch (e) {
      setMessage(`${t("common.copyUnavailable")}: ${String(e)}`);
    }
  };

  return (
    <>
      <div className="panel">
        <h2>{t("receive.myAddress")}</h2>
        {!session && <div className="hint">{t("wallet.loginFirst")}</div>}
        <div className="row">
          <code style={{ wordBreak: "break-all" }}>{session?.address || "—"}</code>
          <button className="ghost" onClick={loadAddress} disabled={!enabled || !session}>{t("receive.refresh")}</button>
          <button className="ghost" onClick={() => session?.address && copy(session.address)} disabled={!session?.address}>
            {t("common.copy")}
          </button>
        </div>
        {qr && (
          <div className="row" style={{ marginTop: 12, alignItems: "flex-start" }}>
            <img className="qr" src={qr} alt="QR адреса" />
            <span className="hint">QR для получателя: тот же slatepack-адрес.</span>
          </div>
        )}
        <details style={{ marginTop: 12 }}>
          <summary className="hint" style={{ cursor: "pointer" }}>Дополнительно</summary>
          <div className="hint" style={{ marginTop: 6 }}>Новый адрес нужен редко: старый останется рабочим, но перестанет показываться.</div>
          <button className="ghost" style={{ marginTop: 6 }} onClick={newAddress} disabled={!enabled || !session}>{t("receive.newAddress")}</button>
        </details>
      </div>

      <div className="panel">
        <h2>{t("receive.incoming")}</h2>
        <textarea placeholder={t("receive.incomingPlaceholder")} value={incoming} onChange={(e) => setIncoming(e.target.value)} />
        <div className="row" style={{ marginTop: 8 }}>
          <button className="primary" onClick={onReceive} disabled={!enabled || !session || !incoming}>{t("receive.accept")}</button>
        </div>
        {message && <div className="hint" style={{ marginTop: 8 }}>{message}</div>}
      </div>

      {outgoing && (
        <div className="panel">
          <div className="row" style={{ marginBottom: 8 }}>
            <h2 style={{ margin: 0 }}>{t("receive.responseOut")}</h2>
            <button className="ghost" onClick={() => copy(outgoing)}>{t("common.copy")}</button>
          </div>
          <textarea value={outgoing} readOnly />
        </div>
      )}
    </>
  );
}

function HistoryPage({ enabled, call, session }: { enabled: boolean; call: Call; session: Session | null }) {
  const [txs, setTxs] = useState<Record<string, unknown>[]>([]);
  const [filter, setFilter] = useState("all");
  const [message, setMessage] = useState<string | null>(null);

  const refresh = async () => {
    if (!session) return;
    const result = await call("list_txs", { session_token: session.token });
    const list = result?.txs;
    setTxs(Array.isArray(list) ? (list as Record<string, unknown>[]) : []);
  };

  useEffect(() => {
    if (enabled && session) refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, session]);

  const typeOf = (tx: Record<string, unknown>) => String(tx.tx_type ?? tx.type ?? "").toLowerCase();
  const stateOf = (tx: Record<string, unknown>) => String(tx.status ?? tx.state ?? "").toLowerCase();
  const visible = txs.filter((tx) => {
    if (filter === "all") return true;
    if (filter === "in_progress") return !/confirm|final|complete/.test(stateOf(tx));
    if (filter === "received") return /receiv/.test(typeOf(tx));
    if (filter === "sent") return /sent|send/.test(typeOf(tx));
    if (filter === "canceled") return /cancel/.test(stateOf(tx)) || /cancel/.test(typeOf(tx));
    if (filter === "coinbase") return /coinbase/.test(typeOf(tx));
    return true;
  });
  const tabs: { id: string; label: string }[] = [
    { id: "all", label: "all" },
    { id: "in_progress", label: "in_progress" },
    { id: "received", label: "received" },
    { id: "sent", label: "sent" },
    { id: "canceled", label: "canceled" },
    { id: "coinbase", label: "coinbase" },
  ];

  const exportCsv = () => {
    const header = "id,type,state,amount";
    const rows = visible.map((tx) =>
      [tx.id ?? tx.tx_id ?? "", tx.tx_type ?? tx.type ?? "", tx.status ?? tx.state ?? "", tx.amount ?? tx.fee ?? ""]
        .map((v) => `"${String(v).replace(/"/g, '""')}"`)
        .join(","),
    );
    const blob = new Blob([[header, ...rows].join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "transactions.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  const onCancel = async (id: unknown) => {
    if (!session) return;
    const result = await call("cancel_tx", { session_token: session.token, tx_id: id });
    if (result) {
      setMessage(`${t("history.cancel")}: ${pick(result, "status")}`);
      await refresh();
    }
  };

  const onRepost = async (id: unknown) => {
    if (!session) return;
    const result = await call("repost_tx", { session_token: session.token, tx_id: id, method: "STEM" });
    if (result) {
      setMessage(`${t("history.repost")}: ${pick(result, "status")}`);
      await refresh();
    }
  };

  return (
    <div className="panel">
      <div className="row" style={{ marginBottom: 10 }}>
        <h2 style={{ margin: 0 }}>{t("history.title")}</h2>
        <button className="ghost" onClick={refresh} disabled={!session}>{t("receive.refresh")}</button>
        {message && <span className="hint">{message}</span>}
      </div>
      <div className="row" style={{ marginBottom: 12 }}>
        <span className="hint">фильтр:</span>
        <select value={filter} onChange={(e) => setFilter(e.target.value)}>
          {tabs.map((tab) => (
            <option key={tab.id} value={tab.id}>{tab.label}</option>
          ))}
        </select>
        <button className="ghost" onClick={exportCsv} disabled={!session}>Экспорт</button>
      </div>
      {!session ? (
        <div className="hint">{t("wallet.loginFirst")}</div>
      ) : txs.length === 0 ? (
        <div className="hint">{t("common.empty")}</div>
      ) : (
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr style={{ textAlign: "left", color: "var(--text-dim)" }}>
              <th style={{ padding: 6 }}>{t("history.id")}</th>
              <th style={{ padding: 6 }}>{t("history.type")}</th>
              <th style={{ padding: 6 }}>{t("history.state")}</th>
              <th style={{ padding: 6 }}>{t("history.amount")}</th>
              <th style={{ padding: 6 }}>{t("history.actions")}</th>
            </tr>
          </thead>
          <tbody>
            {visible.map((tx, idx) => {
              const id = tx.id ?? tx.tx_id ?? idx;
              const firstOf = (keys: string[]) => {
                for (const key of keys) {
                  const value = tx[key];
                  if (value !== undefined && value !== null && value !== "") return String(value);
                }
                return "—";
              };
              const txAmount = tx.amount_credited ?? tx.amount_debited ?? tx.amount;
              const txTypeLabel = String(tx.tx_type ?? tx.type ?? "");
              const txState = tx.confirmed_height ? `confirmed @${tx.confirmed_height}` : (txTypeLabel === "Canceled" ? "canceled" : (tx.status ?? tx.state ?? "pending"));
              const txType = firstOf(["tx_type", "type"]);
              const txActive = !tx.confirmed_height && txType !== "Canceled" && txType !== "Received";
              return (
                <tr key={String(id)} style={{ borderTop: "1px solid var(--border)" }}>
                  <td style={{ padding: 6 }}>{String(id)}</td>
                  <td style={{ padding: 6 }}>{firstOf(["tx_type", "type"])}</td>
                  <td style={{ padding: 6 }}>{String(txState)}</td>
                  <td style={{ padding: 6 }}>{txAmount === undefined ? "—" : nanosToGrin(txAmount as number)}</td>
                  <td style={{ padding: 6 }}>
                    {txActive ? (
                      <>
                        <button className="ghost" onClick={() => onCancel(id)}>{t("history.cancel")}</button>{" "}
                        <button className="ghost" onClick={() => onRepost(id)}>{t("history.repost")}</button>
                      </>
                    ) : (
                      <span className="hint">—</span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
    </div>
  );
}

function TorPage(props: {
  enabled: boolean;
  call: Call;
  session: Session | null;
  net: Net;
}) {
  const { enabled, call, session, net } = props;
  const [torUp, setTorUp] = useState<boolean | null>(null);
  const [torrc, setTorrc] = useState("");
  const [bridges, setBridges] = useState<string[]>([]);
  const [bridgesType, setBridgesType] = useState("");
  const [offered, setOffered] = useState<string[]>([]);
  const [snowflake, setSnowflake] = useState<string | null>(null);
  const [challenge, setChallenge] = useState<MoatChallenge | null>(null);
  const [solution, setSolution] = useState("");
  const [message, setMessage] = useState<string | null>(null);

  const loadTor = async () => {
    const result = await call("get_tor_config", {});
    if (result) {
      setTorrc(String(result.torrc ?? ""));
      const list = result.bridges;
      setBridges(Array.isArray(list) ? list.map(String) : []);
      setBridgesType(String(result.bridges_type ?? ""));
    }
  };

  useEffect(() => {
    if (enabled) loadTor();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled]);

  useEffect(() => {
    if (!enabled) {
      setTorUp(null);
      return;
    }
    let alive = true;
    const tick = async () => {
      try {
        const up = await torRunning(net);
        if (alive) setTorUp(up);
      } catch {
        /* ignore */
      }
    };
    tick();
    const timer = window.setInterval(tick, 5000);
    return () => {
      alive = false;
      window.clearInterval(timer);
    };
  }, [enabled, net]);

  const onAuto = async () => {
    setMessage(null);
    try {
      const map = await moatMap();
      setSnowflake(map.snowflake ? map.snowflake.bridge : null);
      if (map.obfs4.length > 0) {
        setOffered(map.obfs4);
        setMessage(`${t("tor.gotBridges")} ${map.obfs4.length}`);
      } else {
        const task = await moatFetch();
        setChallenge(task);
        setMessage(t("tor.needCaptcha"));
      }
    } catch (e) {
      setMessage(String(e));
    }
  };

  const onSolve = async () => {
    if (!challenge) return;
    try {
      const list = await moatCheck(challenge.id, challenge.challenge, solution);
      setOffered(list);
      setChallenge(null);
      setSolution("");
      setMessage(`${t("tor.received")} ${list.length}`);
    } catch (e) {
      setMessage(String(e));
    }
  };

  const applyBridges = async () => {
    const result = await call("set_tor_config", { bridges_list: offered, enable_snowflake: false });
    if (result) {
      setMessage(`${t("tor.applied")}: ${pick(result, "status")}, ${t("common.type")} ${pick(result, "bridges_type")}`);
      await loadTor();
    }
  };

  const enableSnowflake = async () => {
    const result = await call("set_tor_config", { bridges_list: [], enable_snowflake: true });
    if (result) {
      setMessage(`snowflake: ${pick(result, "status")}`);
      await loadTor();
    }
  };

  const retryTor = async () => {
    if (!session) return;
    const result = await call("retry_tor", { session_token: session.token });
    if (result) setMessage(`retry_tor: ${pick(result, "status")}, ${t("wallet.address")} ${pick(result, "tor_address")}`);
  };

  return (
    <>
      <div className="panel">
        <div className="row" style={{ marginBottom: 10 }}>
          <h2 style={{ margin: 0 }}>{t("tor.title")}</h2>
          <span className={`badge ${torUp === null ? "wait" : torUp ? "ok" : "bad"}`}>
            {!enabled ? "Tor: нода не запущена" : torUp === null ? "Tor: проверяю…" : torUp ? "Tor работает" : "Tor не работает"}
          </span>
          <button className="ghost" onClick={loadTor} disabled={!enabled}>{t("receive.refresh")}</button>
          <button className="primary" onClick={onAuto} disabled={!enabled}>{t("tor.auto")}</button>
          <button className="ghost" onClick={enableSnowflake} disabled={!enabled}>{t("tor.snowflake")}</button>
          <button className="ghost" onClick={retryTor} disabled={!session}>{t("tor.retry")}</button>
        </div>
        {message && <div className="hint">{message}</div>}
        {snowflake && <div className="hint" style={{ marginTop: 6 }}>{t("tor.snowflakeFromMap")}: {snowflake}</div>}
        {enabled && torUp === false && (
          <div className="panel" style={{ marginTop: 12, borderColor: "#a33" }}>
            <h2 style={{ marginTop: 0 }}>Tor не работает</h2>
            <div className="hint">Похоже, Tor недоступен или заблокирован. Попробуйте мосты — это обычно решает проблему.</div>
            <div className="row" style={{ marginTop: 8, flexWrap: "wrap" }}>
              <button className="primary" onClick={onAuto}>Получить мосты автоматически</button>
              <button className="ghost" onClick={enableSnowflake}>Включить snowflake</button>
              <button className="ghost" onClick={retryTor} disabled={!session}>Перезапустить Tor</button>
            </div>
          </div>
        )}
      </div>

      {challenge && (
        <div className="panel">
          <h2>{t("tor.captcha")}</h2>
          {challenge.image && <img src={challenge.image} alt="captcha" style={{ maxWidth: 320, borderRadius: 8 }} />}
          <div className="row" style={{ marginTop: 10 }}>
            <input placeholder={t("tor.captchaAnswer")} value={solution} onChange={(e) => setSolution(e.target.value)} />
            <button className="primary" onClick={onSolve} disabled={!solution}>{t("tor.check")}</button>
            <button className="ghost" onClick={() => setChallenge(null)}>{t("tor.cancel")}</button>
          </div>
        </div>
      )}

      {offered.length > 0 && (
        <div className="panel">
          <div className="row" style={{ marginBottom: 8 }}>
            <h2 style={{ margin: 0 }}>{t("tor.offered")}</h2>
            <button className="primary" onClick={applyBridges}>{t("tor.apply")}</button>
          </div>
          {offered.map((b) => <div key={b} style={{ fontSize: 12, wordBreak: "break-all", marginBottom: 4 }}>{b}</div>)}
        </div>
      )}

      <div className="panel">
        <h2>{t("tor.current")}</h2>
        <div className="hint">{t("common.type")}: {bridgesType || "—"}; {t("tor.bridgesCount")}: {bridges.length}</div>
        <pre className="logs" style={{ maxHeight: "30vh" }}>{torrc || "—"}</pre>
      </div>
    </>
  );
}
